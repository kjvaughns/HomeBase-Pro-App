
export interface Job {
  id: string;
  clientName: string;
  clientId?: string;
  clientAvatar?: string;
  service: string;
  time: string;
  date: Date; // standardizing on Date object for logic
  duration: number; // minutes
  status: 'scheduled' | 'on-the-way' | 'in-progress' | 'completed' | 'invoiced';
  price: number;
  address: string;
  notes?: string;
  lineItems?: { name: string; price: number }[];
}

export interface Client {
  id: string;
  name: string;
  status: 'active' | 'lead' | 'inactive';
  ltv: number;
  lastService: string;
  image: string;
  address?: string;
  phone?: string;
  email?: string;
}

export interface Service {
  id: string;
  name: string;
  price: number;
  duration: number; // minutes
  isActive: boolean;
  category: string;
}

export type Tab = 'dashboard' | 'schedule' | 'clients' | 'services' | 'money' | 'profile' | 'more' | 'ai' | 'onboarding' | 'team' | 'settings' | 'support';

export interface ViewProps {
  isActive: boolean;
}
