
import React, { useState } from 'react';
import { Home, Calendar, Users, DollarSign, Plus, Menu, Briefcase, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Screens
import Dashboard from './screens/Dashboard';
import Schedule from './screens/Schedule';
import Clients from './screens/Clients';
import MoneyHub from './screens/MoneyHub';
import Profile from './screens/Profile';
import More from './screens/More';
import Services from './screens/Services';
import AskAI from './screens/AskAI';
import BookingPreview from './screens/BookingPreview';
import Onboarding from './screens/Onboarding';
import Team from './screens/Team';
import Settings from './screens/Settings';
import Support from './screens/Support';

// Types
import { Tab } from './types';
import { useTheme } from './components/ThemeContext';

// Bottom Navigation Component
const BottomNav = ({ activeTab, onTabChange, onAddPress }: { activeTab: Tab, onTabChange: (t: Tab) => void, onAddPress: () => void }) => {
  const tabs = [
    { id: 'dashboard', icon: Home, label: 'Home' },
    { id: 'schedule', icon: Calendar, label: 'Schedule' },
    // Middle Spacer handled manually
    { id: 'money', icon: DollarSign, label: 'Money' },
    { id: 'more', icon: Menu, label: 'More' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 h-24 bg-white/80 dark:bg-black/80 backdrop-blur-xl border-t border-gray-200 dark:border-white/10 flex justify-between items-end px-4 pb-6 z-30 safe-bottom">
      
      {/* Left Group */}
      <div className="flex-1 flex justify-around">
        {tabs.slice(0, 2).map((tab) => {
            const isActive = activeTab === tab.id;
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id as Tab)}
                className="flex flex-col items-center justify-center p-2 relative w-16"
              >
                {isActive && (
                  <motion.div 
                    layoutId="nav-glow"
                    className="absolute inset-0 bg-homebase/10 blur-xl rounded-full"
                    transition={{ duration: 0.3 }}
                  />
                )}
                <Icon 
                  size={24} 
                  className={`mb-1 transition-colors duration-200 z-10 ${isActive ? 'text-homebase' : 'text-gray-400 dark:text-gray-500'}`} 
                  strokeWidth={isActive ? 2.5 : 2}
                />
                <span className={`text-[10px] font-medium z-10 ${isActive ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'}`}>
                  {tab.label}
                </span>
              </button>
            );
        })}
      </div>

      {/* Center Button Area */}
      <div className="relative -top-6 mx-2">
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={onAddPress}
          className="h-16 w-16 rounded-full bg-homebase flex items-center justify-center shadow-[0_0_20px_rgba(15,175,110,0.5)] border-4 border-white dark:border-black z-50 hover:bg-homebase-light transition-colors"
        >
          <Plus size={32} className="text-white" strokeWidth={3} />
        </motion.button>
      </div>

      {/* Right Group */}
      <div className="flex-1 flex justify-around">
         {tabs.slice(2, 4).map((tab) => {
            // Highlight 'More' if active tab is a sub-page of More
            const isActive = activeTab === tab.id || (tab.id === 'more' && ['clients', 'profile', 'services', 'team', 'settings', 'support'].includes(activeTab));
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => onTabChange(tab.id as Tab)}
                className="flex flex-col items-center justify-center p-2 relative w-16"
              >
                {isActive && (
                  <motion.div 
                    layoutId="nav-glow"
                    className="absolute inset-0 bg-homebase/10 blur-xl rounded-full"
                    transition={{ duration: 0.3 }}
                  />
                )}
                <Icon 
                  size={24} 
                  className={`mb-1 transition-colors duration-200 z-10 ${isActive ? 'text-homebase' : 'text-gray-400 dark:text-gray-500'}`} 
                  strokeWidth={isActive ? 2.5 : 2}
                />
                <span className={`text-[10px] font-medium z-10 ${isActive ? 'text-gray-900 dark:text-white' : 'text-gray-400 dark:text-gray-500'}`}>
                  {tab.label}
                </span>
              </button>
            );
        })}
      </div>

    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [isAddMenuOpen, setIsAddMenuOpen] = useState(false);
  const [isCreatingJob, setIsCreatingJob] = useState(false);
  const [isCreatingService, setIsCreatingService] = useState(false);
  const [isBookingPreviewOpen, setIsBookingPreviewOpen] = useState(false);
  const { theme } = useTheme();

  const handleAddAction = (action: 'client' | 'job' | 'invoice' | 'service' | 'ai') => {
    setIsAddMenuOpen(false);
    switch(action) {
      case 'client': setActiveTab('clients'); break;
      case 'job': setActiveTab('schedule'); setIsCreatingJob(true); break;
      case 'invoice': setActiveTab('money'); break;
      case 'service': setActiveTab('services'); setIsCreatingService(true); break;
      case 'ai': setActiveTab('ai'); break;
    }
  };

  const renderScreen = () => {
    switch(activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'schedule': return <Schedule isCreatingJob={isCreatingJob} setIsCreatingJob={setIsCreatingJob} />;
      case 'clients': return <Clients />;
      case 'money': return <MoneyHub />;
      case 'profile': return <Profile onPreviewBooking={() => setIsBookingPreviewOpen(true)} />;
      case 'services': return <Services onBack={() => setActiveTab('more')} isCreating={isCreatingService} onCreationClose={() => setIsCreatingService(false)} />;
      case 'ai': return <AskAI onBack={() => setActiveTab('dashboard')} />;
      case 'more': return <More onNavigate={setActiveTab} />;
      case 'team': return <Team onBack={() => setActiveTab('more')} />;
      case 'settings': return <Settings onBack={() => setActiveTab('more')} />;
      case 'support': return <Support onBack={() => setActiveTab('more')} />;
      case 'onboarding': return <Onboarding onComplete={() => setActiveTab('dashboard')} />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-black text-gray-900 dark:text-white relative font-sans overflow-hidden safe-top">
      {/* Background Ambience */}
      <div className="fixed top-[-20%] left-[-20%] w-[140%] h-[140%] bg-[radial-gradient(circle_at_50%_50%,rgba(15,175,110,0.1),transparent_60%)] pointer-events-none z-0" />
      
      {/* Content Area */}
      <main className={`h-screen overflow-y-auto scrollbar-hide relative z-10 ${activeTab !== 'onboarding' ? 'pb-24' : ''}`}>
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="min-h-full"
          >
            {renderScreen()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Booking Preview Modal */}
      <AnimatePresence>
        {isBookingPreviewOpen && (
           <BookingPreview onClose={() => setIsBookingPreviewOpen(false)} />
        )}
      </AnimatePresence>

      {/* Global Add Menu Overlay */}
      <AnimatePresence>
        {isAddMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }}
              onClick={() => setIsAddMenuOpen(false)}
              className="fixed inset-0 bg-black/40 dark:bg-black/60 backdrop-blur-sm z-40"
            />
            <div className="fixed bottom-28 left-0 right-0 z-50 flex flex-col-reverse items-center gap-4 pointer-events-none pb-4">
               {[
                 { id: 'ai', icon: Sparkles, label: 'Ask AI', delay: 0, color: 'text-homebase' },
                 { id: 'client', icon: Users, label: 'Client', delay: 0.05 },
                 { id: 'job', icon: Calendar, label: 'Job', delay: 0.1 },
                 { id: 'invoice', icon: DollarSign, label: 'Invoice', delay: 0.15 },
                 { id: 'service', icon: Briefcase, label: 'Service', delay: 0.2 },
               ].map((item) => (
                 <motion.button
                   key={item.id}
                   initial={{ opacity: 0, y: 20, scale: 0.8 }}
                   animate={{ opacity: 1, y: 0, scale: 1 }}
                   exit={{ opacity: 0, y: 10, scale: 0.8 }}
                   transition={{ delay: item.delay }}
                   onClick={() => handleAddAction(item.id as any)}
                   className="flex items-center gap-4 group pointer-events-auto"
                 >
                    <span className="text-xs font-bold text-gray-900 dark:text-white bg-white/50 dark:bg-black/50 px-3 py-1.5 rounded-lg backdrop-blur-md border border-gray-200 dark:border-white/10 shadow-lg">
                      {item.label}
                    </span>
                    <div className={`h-14 w-14 rounded-full bg-white/80 dark:bg-glass-200 border border-gray-200 dark:border-white/20 flex items-center justify-center text-gray-900 dark:text-white shadow-lg backdrop-blur-xl group-hover:bg-homebase group-hover:text-white transition-colors ${item.id === 'ai' ? 'ring-2 ring-homebase ring-offset-2 ring-offset-white dark:ring-offset-black' : ''}`}>
                       <item.icon size={24} className={item.color} />
                    </div>
                 </motion.button>
               ))}
            </div>
          </>
        )}
      </AnimatePresence>

      {/* Bottom Nav - Hidden on Onboarding */}
      {activeTab !== 'onboarding' && (
          <BottomNav 
            activeTab={activeTab} 
            onTabChange={setActiveTab} 
            onAddPress={() => setIsAddMenuOpen(!isAddMenuOpen)} 
          />
      )}
    </div>
  );
}
