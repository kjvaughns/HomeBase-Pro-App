
import React from 'react';
import { GlassCard, GlassHeader, StatusChip } from '../components/LiquidComponents';
import { Briefcase, Users, DollarSign, Calendar, Clock, ArrowRight, Bell, Moon, Sun } from 'lucide-react';
import { motion } from 'framer-motion';
import { Job } from '../types';
import { useTheme } from '../components/ThemeContext';

const KPICard = ({ title, value, icon: Icon, delay }: { title: string, value: string, icon: any, delay: number }) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay, duration: 0.4 }}
    className="flex-1"
  >
    <GlassCard className="p-4 flex flex-col items-center justify-center text-center h-32 relative group">
      <div className="absolute top-2 right-2 opacity-50">
        <Icon size={16} className="text-gray-400" />
      </div>
      <div className="bg-homebase/10 p-3 rounded-full mb-2 group-hover:scale-110 transition-transform duration-300">
        <Icon size={20} className="text-homebase" />
      </div>
      <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-0.5">{value}</h3>
      <p className="text-[10px] font-medium text-gray-400 uppercase tracking-wider">{title}</p>
    </GlassCard>
  </motion.div>
);

const JobRow: React.FC<{ job: Job }> = ({ job }) => (
  <GlassCard className="mb-3 p-4 flex items-center justify-between group active:scale-[0.98] transition-all">
    <div className="flex items-center space-x-4">
      <div className="h-12 w-12 rounded-xl bg-gray-100 dark:bg-glass-200 flex items-center justify-center text-gray-900 dark:text-white font-bold border border-gray-200 dark:border-white/5">
        {job.time.split(' ')[0]}
      </div>
      <div>
        <h4 className="text-sm font-semibold text-gray-900 dark:text-white">{job.clientName}</h4>
        <p className="text-xs text-gray-500 dark:text-gray-400">{job.service}</p>
      </div>
    </div>
    <div className="flex flex-col items-end space-y-2">
      <StatusChip status={job.status} />
      <span className="text-xs font-mono text-gray-400 dark:text-gray-500">${job.price}</span>
    </div>
  </GlassCard>
);

export default function Dashboard() {
  const { theme, toggleTheme } = useTheme();
  const jobs: Job[] = [
    { 
      id: '1', 
      clientName: 'Sarah Miller', 
      service: 'Deep Clean', 
      time: '09:00 AM', 
      status: 'in-progress', 
      price: 180,
      date: new Date(),
      duration: 120,
      address: '123 Main St'
    },
    { 
      id: '2', 
      clientName: 'TechStart Office', 
      service: 'Standard Maintenance', 
      time: '11:30 AM', 
      status: 'scheduled', 
      price: 250,
      date: new Date(),
      duration: 60,
      address: '456 Tech Blvd'
    },
    { 
      id: '3', 
      clientName: 'James Wilson', 
      service: 'Move-out Clean', 
      time: '02:00 PM', 
      status: 'scheduled', 
      price: 320,
      date: new Date(),
      duration: 180,
      address: '789 Elm St'
    },
  ];

  return (
    <div className="pb-24">
      <GlassHeader 
        title="Good Morning" 
        subtitle="Clean & Co. LLC" 
        rightAction={
          <div className="flex items-center gap-2">
            <button 
              onClick={toggleTheme}
              className="p-2 bg-gray-100 dark:bg-glass-200 rounded-full text-gray-900 dark:text-white hover:scale-105 active:scale-95 transition-all"
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </button>
            <div className="relative p-2 bg-gray-100 dark:bg-glass-200 rounded-full">
              <Bell size={20} className="text-gray-900 dark:text-white" />
              <span className="absolute top-0 right-0 h-3 w-3 bg-red-500 rounded-full border-2 border-white dark:border-black"></span>
            </div>
          </div>
        } 
      />

      <div className="px-5 mt-6 space-y-6">
        {/* Helper Tiles */}
        <motion.div 
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex space-x-3 overflow-x-auto pb-2 scrollbar-hide"
        >
          {['Unpaid Invoice #1024', 'Confirm Appointment', 'Low Supplies'].map((item, i) => (
             <GlassCard key={i} className="min-w-[160px] p-3 border-l-4 border-l-homebase">
               <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Attention needed</p>
               <p className="text-sm font-semibold text-gray-900 dark:text-white whitespace-nowrap">{item}</p>
             </GlassCard>
          ))}
        </motion.div>

        {/* KPIs */}
        <div className="grid grid-cols-2 gap-3">
          <KPICard title="Revenue MTD" value="$4.2k" icon={DollarSign} delay={0.1} />
          <KPICard title="Completed" value="24 Jobs" icon={Briefcase} delay={0.2} />
          <KPICard title="Active Clients" value="48" icon={Users} delay={0.3} />
          <KPICard title="Upcoming" value="8" icon={Calendar} delay={0.4} />
        </div>

        {/* Today's Jobs */}
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white">Today's Schedule</h3>
            <button className="text-xs text-homebase font-semibold flex items-center">
              View All <ArrowRight size={12} className="ml-1" />
            </button>
          </div>
          
          <div className="space-y-1">
            {jobs.map((job) => (
              <JobRow key={job.id} job={job} />
            ))}
          </div>
        </div>

        {/* Activity Skeleton */}
        <div className="space-y-3">
           <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Recent Activity</h3>
           <GlassCard className="h-16 animate-pulse flex items-center px-4 space-x-4">
             <div className="h-8 w-8 rounded-full bg-gray-200 dark:bg-white/10" />
             <div className="space-y-2 flex-1">
               <div className="h-2 w-1/3 bg-gray-200 dark:bg-white/10 rounded" />
               <div className="h-2 w-1/2 bg-gray-100 dark:bg-white/5 rounded" />
             </div>
           </GlassCard>
        </div>
      </div>
    </div>
  );
}
