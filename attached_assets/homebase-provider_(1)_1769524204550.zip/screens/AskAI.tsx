import React, { useState, useRef, useEffect } from 'react';
import { GlassHeader, GlassCard, GlassInput } from '../components/LiquidComponents';
import { Send, Mic, Sparkles, ArrowLeft, MoreHorizontal, User, Volume2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface AskAIProps {
    onBack: () => void;
}

interface Message {
    id: string;
    text: string;
    sender: 'user' | 'ai';
    timestamp: Date;
    type?: 'text' | 'action';
}

export default function AskAI({ onBack }: AskAIProps) {
    const [messages, setMessages] = useState<Message[]>([
        { 
            id: '1', 
            text: "Hi there! I'm your HomeBase assistant. I can help you manage your schedule, add new clients, check your earnings, or answer questions about your business. Try asking me to 'Add a new client' or 'Check my schedule for today'.", 
            sender: 'ai', 
            timestamp: new Date() 
        }
    ]);
    const [inputText, setInputText] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const [isListening, setIsListening] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);

    // Auto-scroll to bottom
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages, isTyping]);

    const handleSend = () => {
        if (!inputText.trim()) return;

        const userMsg: Message = {
            id: Date.now().toString(),
            text: inputText,
            sender: 'user',
            timestamp: new Date()
        };
        setMessages(prev => [...prev, userMsg]);
        setInputText('');
        setIsTyping(true);

        // Simulate AI Response logic
        setTimeout(() => {
            let aiResponseText = "I can definitely help with that. Let me pull that up for you.";
            const lowerInput = userMsg.text.toLowerCase();

            if (lowerInput.includes('schedule') || lowerInput.includes('job')) {
                aiResponseText = "You have 3 jobs scheduled for today. Your first job is at 9:00 AM with Sarah Miller for a 'Deep Clean'. Would you like to see the full list?";
            } else if (lowerInput.includes('client') || lowerInput.includes('add')) {
                aiResponseText = "Sure, I can help you add a new client. What's their name?";
            } else if (lowerInput.includes('money') || lowerInput.includes('revenue')) {
                aiResponseText = "Your current revenue for this month is $4,200, which is up 12% from last month. Great job!";
            } else if (lowerInput.includes('hello') || lowerInput.includes('hi')) {
                aiResponseText = "Hello! Ready to get to work? What can I do for you?";
            }

            const aiMsg: Message = {
                id: (Date.now() + 1).toString(),
                text: aiResponseText,
                sender: 'ai',
                timestamp: new Date()
            };
            setMessages(prev => [...prev, aiMsg]);
            setIsTyping(false);
        }, 1500);
    };

    const handleMicClick = () => {
        setIsListening(true);
        // Simulate voice recognition delay then auto-close
        setTimeout(() => {
            setIsListening(false);
            setInputText("Show me today's schedule");
            // Auto send after "voice recognition"
            setTimeout(() => handleSend(), 500);
        }, 3000);
    };

    return (
        <div className="h-full bg-black flex flex-col relative">
            {/* Header */}
            <div className="sticky top-0 z-40 bg-black/80 backdrop-blur-xl border-b border-white/5">
                <div className="px-4 py-4 pt-12 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-white/10 text-gray-400">
                            <ArrowLeft size={20} />
                        </button>
                        <div>
                             <h1 className="text-lg font-bold text-white flex items-center gap-2">
                                <Sparkles size={16} className="text-homebase" /> 
                                HomeBase AI
                             </h1>
                             <div className="flex items-center gap-1.5">
                                 <span className="relative flex h-2 w-2">
                                   <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                                   <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                                 </span>
                                 <span className="text-[10px] text-gray-400 uppercase tracking-wide">Online</span>
                             </div>
                        </div>
                    </div>
                    <button className="p-2 rounded-full hover:bg-white/10 text-gray-400">
                        <MoreHorizontal size={20} />
                    </button>
                </div>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-32" ref={scrollRef}>
                {messages.map((msg) => (
                    <motion.div 
                        key={msg.id}
                        initial={{ opacity: 0, y: 10, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                        <div className={`flex max-w-[85%] ${msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row'} gap-3`}>
                            {/* Avatar */}
                            <div className={`h-8 w-8 rounded-full flex-shrink-0 flex items-center justify-center border border-white/10 ${msg.sender === 'ai' ? 'bg-homebase/20' : 'bg-glass-200'}`}>
                                {msg.sender === 'ai' ? <Sparkles size={14} className="text-homebase" /> : <User size={14} className="text-gray-300" />}
                            </div>

                            {/* Bubble */}
                            <div className={`p-4 rounded-2xl text-sm leading-relaxed shadow-sm ${
                                msg.sender === 'user' 
                                ? 'bg-homebase text-white rounded-tr-sm' 
                                : 'bg-glass-200 border border-white/5 text-gray-100 rounded-tl-sm'
                            }`}>
                                {msg.text}
                            </div>
                        </div>
                    </motion.div>
                ))}

                {/* Typing Indicator */}
                {isTyping && (
                    <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="flex justify-start"
                    >
                         <div className="flex max-w-[80%] gap-3">
                            <div className="h-8 w-8 rounded-full flex-shrink-0 flex items-center justify-center border border-white/10 bg-homebase/20">
                                <Sparkles size={14} className="text-homebase" />
                            </div>
                            <div className="bg-glass-200 border border-white/5 px-4 py-3 rounded-2xl rounded-tl-sm flex items-center gap-1">
                                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                                <span className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                            </div>
                         </div>
                    </motion.div>
                )}
            </div>

            {/* Input Area */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/80 backdrop-blur-xl border-t border-white/10 safe-bottom">
                <div className="flex items-center gap-3">
                    <button 
                        onClick={handleMicClick}
                        className="p-3 rounded-full bg-glass-200 text-gray-300 hover:text-white hover:bg-glass-300 transition-colors border border-white/5 active:scale-95"
                    >
                        <Mic size={20} />
                    </button>
                    <div className="flex-1 relative">
                        <input
                            type="text"
                            value={inputText}
                            onChange={(e) => setInputText(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Ask me anything..."
                            className="w-full bg-glass-200 border border-white/10 rounded-full pl-5 pr-12 py-3 text-sm text-white placeholder-gray-500 outline-none focus:border-homebase/50 transition-colors"
                        />
                        <button 
                            onClick={handleSend}
                            disabled={!inputText.trim()}
                            className="absolute right-1.5 top-1.5 p-1.5 bg-homebase text-white rounded-full disabled:opacity-50 disabled:bg-gray-700 transition-all hover:scale-105 active:scale-95"
                        >
                            <Send size={16} />
                        </button>
                    </div>
                </div>
            </div>

            {/* Voice Listening Overlay */}
            <AnimatePresence>
                {isListening && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 z-50 bg-black/90 backdrop-blur-2xl flex flex-col items-center justify-center p-8"
                    >
                        <button 
                            onClick={() => setIsListening(false)}
                            className="absolute top-12 right-6 p-2 rounded-full bg-white/10 text-white"
                        >
                            <X size={24} />
                        </button>

                        <div className="relative mb-12">
                             {/* Pulsing Rings */}
                             <motion.div 
                                animate={{ scale: [1, 1.5, 1], opacity: [0.5, 0, 0.5] }}
                                transition={{ repeat: Infinity, duration: 2 }}
                                className="absolute inset-0 bg-homebase/30 rounded-full blur-xl"
                             />
                             <motion.div 
                                animate={{ scale: [1, 1.2, 1], opacity: [0.8, 0, 0.8] }}
                                transition={{ repeat: Infinity, duration: 2, delay: 0.5 }}
                                className="absolute inset-0 bg-homebase/50 rounded-full"
                             />
                             <div className="relative h-24 w-24 bg-homebase rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(15,175,110,0.6)]">
                                 <Mic size={40} className="text-white" />
                             </div>
                        </div>

                        <h3 className="text-2xl font-bold text-white mb-2">Listening...</h3>
                        <p className="text-gray-400 text-center max-w-xs">
                            Try saying "Check my schedule" or "Add a new client named John"
                        </p>

                        {/* Fake Waveform */}
                        <div className="flex items-center gap-1 h-12 mt-12">
                            {[...Array(10)].map((_, i) => (
                                <motion.div
                                    key={i}
                                    animate={{ height: [10, 40, 10] }}
                                    transition={{ 
                                        repeat: Infinity, 
                                        duration: 0.8, 
                                        delay: i * 0.1,
                                        ease: "easeInOut"
                                    }}
                                    className="w-1.5 bg-gradient-to-t from-homebase to-green-300 rounded-full"
                                />
                            ))}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}