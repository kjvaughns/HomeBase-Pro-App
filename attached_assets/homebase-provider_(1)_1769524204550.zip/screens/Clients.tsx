import React, { useState } from 'react';
import { GlassHeader, GlassCard, GlassInput, StatusChip, GlassButton } from '../components/LiquidComponents';
import { Search, MoreHorizontal, Phone, MessageCircle, FileText, ChevronRight, ArrowLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Client } from '../types';

export default function Clients() {
  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  
  const clients: Client[] = [
    { id: '1', name: 'Sarah Miller', status: 'active', ltv: 4500, lastService: '2 days ago', image: 'https://picsum.photos/100/100' },
    { id: '2', name: 'John Doe', status: 'lead', ltv: 0, lastService: 'N/A', image: 'https://picsum.photos/101/101' },
    { id: '3', name: 'Emily Clark', status: 'inactive', ltv: 1200, lastService: '3 months ago', image: 'https://picsum.photos/102/102' },
    { id: '4', name: 'Michael Brown', status: 'active', ltv: 8900, lastService: '1 week ago', image: 'https://picsum.photos/103/103' },
  ];

  if (selectedClient) {
    return (
      <motion.div 
        initial={{ opacity: 0, x: 50 }} 
        animate={{ opacity: 1, x: 0 }} 
        className="h-full bg-black pb-24"
      >
        <GlassHeader 
          title=""
          rightAction={<MoreHorizontal className="text-white" />}
        />
        <div className="absolute top-14 left-4 z-50">
            <button onClick={() => setSelectedClient(null)} className="p-2 bg-glass-200 rounded-full backdrop-blur-md">
                <ArrowLeft size={20} className="text-white" />
            </button>
        </div>

        <div className="px-6 -mt-4 text-center">
            <div className="relative w-24 h-24 mx-auto mb-4">
                <img src={selectedClient.image} alt={selectedClient.name} className="w-full h-full rounded-full border-4 border-black object-cover" />
                <div className="absolute bottom-0 right-0 h-6 w-6 bg-homebase rounded-full border-4 border-black" />
            </div>
            <h2 className="text-2xl font-bold text-white">{selectedClient.name}</h2>
            <p className="text-gray-400 text-sm mt-1">Client since 2023 • LTV ${selectedClient.ltv}</p>
            
            <div className="flex justify-center space-x-4 mt-6">
                <GlassButton variant="secondary" className="rounded-full h-12 w-12 !p-0"><Phone size={20} /></GlassButton>
                <GlassButton variant="primary" className="rounded-full h-12 w-12 !p-0"><MessageCircle size={20} /></GlassButton>
                <GlassButton variant="secondary" className="rounded-full h-12 w-12 !p-0"><FileText size={20} /></GlassButton>
            </div>
        </div>

        <div className="mt-8 px-5">
            <GlassCard className="min-h-[400px]">
                <div className="flex border-b border-white/10">
                    {['Overview', 'Activity', 'Billing'].map((tab, i) => (
                        <button key={tab} className={`flex-1 py-4 text-sm font-medium ${i===0 ? 'text-homebase border-b-2 border-homebase' : 'text-gray-400'}`}>
                            {tab}
                        </button>
                    ))}
                </div>
                <div className="p-5 space-y-6">
                     <div>
                        <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Recent Activity</h4>
                        <div className="space-y-4 border-l border-white/10 pl-4 ml-1">
                            {[1,2,3].map(i => (
                                <div key={i} className="relative">
                                    <div className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full bg-glass-300 ring-4 ring-black" />
                                    <p className="text-sm text-white">Job Completed: Deep Clean</p>
                                    <p className="text-xs text-gray-500">Yesterday at 4:00 PM</p>
                                </div>
                            ))}
                        </div>
                     </div>
                     
                     <div className="pt-4 border-t border-white/5">
                        <h4 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">Details</h4>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <p className="text-[10px] text-gray-400">EMAIL</p>
                                <p className="text-sm text-white truncate">sarah.miller@example.com</p>
                            </div>
                            <div>
                                <p className="text-[10px] text-gray-400">PHONE</p>
                                <p className="text-sm text-white">(555) 123-4567</p>
                            </div>
                        </div>
                     </div>
                </div>
            </GlassCard>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="pb-24">
      <GlassHeader title="Clients" subtitle="142 Total" rightAction={<div className="bg-glass-200 p-2 rounded-full"><MoreHorizontal size={20} /></div>} />
      
      <div className="px-5 mt-4 space-y-4">
        <GlassInput placeholder="Search clients..." icon={Search} />
        
        <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-hide">
            {['All', 'Active', 'Leads', 'Archived'].map(filter => (
                <button key={filter} className="px-4 py-1.5 rounded-full bg-glass-100 border border-glass-border text-xs font-medium text-white whitespace-nowrap active:bg-homebase/20 transition-colors">
                    {filter}
                </button>
            ))}
        </div>

        <div className="space-y-3">
            {clients.map(client => (
                <GlassCard key={client.id} onClick={() => setSelectedClient(client)} className="p-4 flex items-center justify-between group active:scale-[0.98] transition-all cursor-pointer">
                    <div className="flex items-center space-x-3">
                        <img src={client.image} alt={client.name} className="h-10 w-10 rounded-full object-cover" />
                        <div>
                            <h4 className="text-sm font-bold text-white">{client.name}</h4>
                            <p className="text-xs text-gray-400">Last seen: {client.lastService}</p>
                        </div>
                    </div>
                    <div className="flex flex-col items-end space-y-1">
                        <StatusChip status={client.status} />
                        <ChevronRight size={16} className="text-gray-600" />
                    </div>
                </GlassCard>
            ))}
        </div>
      </div>
    </div>
  );
}