import React, { useState, useEffect } from 'react';
import { GlassHeader, GlassCard, GlassInput, GlassButton, StatusChip } from '../components/LiquidComponents';
import { 
    Search, Plus, ArrowLeft, Star, Briefcase, Ruler, Clock, 
    DollarSign, CheckCircle, Smartphone, Calendar, ChevronRight, X,
    Repeat, Tag
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ServicesProps {
    onBack: () => void;
    isCreating?: boolean;
    onCreationClose?: () => void;
}

// Mock Data
const MOCK_SERVICES = [
    { id: '1', name: 'Standard Clean', category: 'Cleaning', priceType: 'Fixed', price: 120, isActive: true },
    { id: '2', name: 'Deep Clean', category: 'Cleaning', priceType: 'Variable', price: 180, isActive: true },
    { id: '3', name: 'Gutter Repair', category: 'Handyman', priceType: 'Quote', price: 0, isActive: false },
];

export default function Services({ onBack, isCreating, onCreationClose }: ServicesProps) {
    const [view, setView] = useState<'list' | 'editor'>('list');
    const [editingId, setEditingId] = useState<string | null>(null);

    // Editor State
    const [pricingType, setPricingType] = useState<'fixed' | 'variable' | 'callout' | 'quote'>('fixed');
    const [serviceName, setServiceName] = useState('');
    const [category, setCategory] = useState('Cleaning');
    
    // New Feature State
    const [billingFrequency, setBillingFrequency] = useState<'one-time' | 'weekly' | 'bi-weekly' | 'monthly'>('one-time');
    const [discounts, setDiscounts] = useState<{id: string, name: string, type: 'percent' | 'fixed', amount: string}[]>([]);
    const [newDiscount, setNewDiscount] = useState({ name: '', amount: '', type: 'percent' as 'percent' | 'fixed' });

    useEffect(() => {
        if (isCreating) {
            handleCreate();
        }
    }, [isCreating]);

    const handleCreate = () => {
        setEditingId(null);
        setServiceName('');
        setPricingType('fixed');
        setBillingFrequency('one-time');
        setDiscounts([]);
        setView('editor');
    };

    const handleEdit = (id: string) => {
        setEditingId(id);
        const svc = MOCK_SERVICES.find(s => s.id === id);
        if(svc) {
            setServiceName(svc.name);
            setCategory(svc.category);
            // In a real app, we'd load freq and discounts here
        }
        setView('editor');
    };

    const handleCloseEditor = () => {
        setView('list');
        if (onCreationClose) onCreationClose();
    };

    const addDiscount = () => {
        if (newDiscount.name && newDiscount.amount) {
            setDiscounts([...discounts, { ...newDiscount, id: Math.random().toString() }]);
            setNewDiscount({ name: '', amount: '', type: 'percent' });
        }
    };

    const removeDiscount = (id: string) => {
        setDiscounts(discounts.filter(d => d.id !== id));
    };

    // --- SUB-COMPONENTS ---

    const PricingOption = ({ 
        type, 
        selected, 
        icon: Icon, 
        label, 
        desc 
    }: { type: string, selected: boolean, icon: any, label: string, desc: string }) => (
        <button 
            onClick={() => setPricingType(type as any)}
            className={`w-full p-4 rounded-2xl border text-left transition-all duration-300 relative overflow-hidden group ${
                selected 
                ? 'bg-homebase/10 border-homebase shadow-[0_0_15px_rgba(15,175,110,0.2)]' 
                : 'bg-glass-200 border-white/5 hover:bg-glass-300'
            }`}
        >
            <div className="flex items-start space-x-4">
                <div className={`p-2.5 rounded-xl ${selected ? 'bg-homebase text-white' : 'bg-white/10 text-gray-400'}`}>
                    <Icon size={20} />
                </div>
                <div>
                    <h4 className={`text-sm font-bold ${selected ? 'text-white' : 'text-gray-200'}`}>{label}</h4>
                    <p className="text-xs text-gray-400 mt-1 leading-relaxed">{desc}</p>
                </div>
            </div>
            {selected && (
                <motion.div 
                    layoutId="check"
                    className="absolute top-4 right-4 text-homebase"
                >
                    <CheckCircle size={18} fill="currentColor" className="text-black" />
                </motion.div>
            )}
        </button>
    );

    return (
        <div className="h-full bg-black">
            <AnimatePresence mode="wait">
                {view === 'list' ? (
                    <motion.div 
                        key="list"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="pb-24"
                    >
                        <GlassHeader 
                            title="My Services" 
                            rightAction={
                                <button onClick={handleCreate} className="bg-homebase p-2 rounded-full text-white shadow-[0_0_15px_rgba(15,175,110,0.4)]">
                                    <Plus size={20} />
                                </button>
                            }
                        />
                         <div className="absolute top-14 left-4 z-50">
                            <button onClick={onBack} className="p-2 bg-glass-200 rounded-full backdrop-blur-md">
                                <ArrowLeft size={20} className="text-white" />
                            </button>
                        </div>

                        <div className="px-5 mt-6 space-y-4">
                            <GlassInput icon={Search} placeholder="Search services..." />
                            
                            {/* Filter Chips */}
                            <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-hide">
                                {['All', 'Cleaning', 'HVAC', 'Handyman', 'Plumbing'].map(cat => (
                                    <button key={cat} className="px-4 py-1.5 rounded-full bg-glass-100 border border-glass-border text-xs font-medium text-white whitespace-nowrap active:bg-homebase/20 transition-colors">
                                        {cat}
                                    </button>
                                ))}
                            </div>

                            {/* Service Cards */}
                            <div className="space-y-3">
                                {MOCK_SERVICES.map(svc => (
                                    <GlassCard key={svc.id} onClick={() => handleEdit(svc.id)} className="p-4 active:bg-glass-200 transition-colors cursor-pointer group">
                                        <div className="flex justify-between items-start mb-2">
                                            <div className="flex items-center space-x-3">
                                                <div className="h-10 w-10 rounded-xl bg-glass-200 flex items-center justify-center border border-white/5">
                                                    <Star size={18} className="text-homebase" />
                                                </div>
                                                <div>
                                                    <h4 className="text-base font-bold text-white">{svc.name}</h4>
                                                    <p className="text-xs text-gray-400">{svc.category}</p>
                                                </div>
                                            </div>
                                            <div className={`w-8 h-5 rounded-full p-0.5 transition-colors ${svc.isActive ? 'bg-homebase' : 'bg-gray-600'}`}>
                                                <div className={`h-4 w-4 rounded-full bg-white shadow-sm transition-transform ${svc.isActive ? 'translate-x-3' : 'translate-x-0'}`} />
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-between pt-2 border-t border-white/5 mt-3">
                                            <span className="text-[10px] font-bold uppercase tracking-wider bg-white/5 px-2 py-1 rounded-md text-gray-300">
                                                {svc.priceType}
                                            </span>
                                            <span className="text-sm font-medium text-white">
                                                {svc.priceType === 'Quote' ? 'Ask for Price' : `$${svc.price}`}
                                            </span>
                                        </div>
                                    </GlassCard>
                                ))}
                            </div>
                        </div>
                    </motion.div>
                ) : (
                    <motion.div 
                        key="editor"
                        initial={{ opacity: 0, y: 50 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 50 }}
                        className="fixed inset-0 z-50 bg-black flex flex-col"
                    >
                        {/* Editor Header */}
                        <div className="px-6 pt-12 pb-4 bg-black/80 backdrop-blur-xl border-b border-white/5 flex justify-between items-center z-40 sticky top-0">
                             <button onClick={handleCloseEditor} className="p-2 -ml-2 hover:bg-white/10 rounded-full text-gray-400">
                                <X size={24} />
                             </button>
                             <h2 className="text-lg font-bold text-white">
                                {editingId ? 'Edit Service' : 'New Service'}
                             </h2>
                             <button onClick={handleCloseEditor} className="text-sm font-bold text-homebase">
                                Save
                             </button>
                        </div>

                        {/* Editor Content */}
                        <div className="flex-1 overflow-y-auto px-5 py-6 space-y-8 pb-32">
                            
                            {/* Section 1: Basics */}
                            <section className="space-y-4">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Basics</h3>
                                <GlassInput icon={Briefcase} placeholder="Service Name" value={serviceName} onChange={(e) => setServiceName(e.target.value)} />
                                <div className="grid grid-cols-2 gap-3">
                                    <div className="bg-glass-200 border border-glass-border rounded-xl px-4 py-3 text-sm text-white flex justify-between items-center">
                                        <span>{category}</span>
                                        <ChevronRight size={16} className="text-gray-500" />
                                    </div>
                                    <div className="flex items-center justify-between bg-glass-200 border border-glass-border rounded-xl px-3 py-3">
                                        <span className="text-xs text-gray-300 font-medium">Published</span>
                                        <div className="w-8 h-5 rounded-full bg-homebase p-0.5">
                                            <div className="h-4 w-4 rounded-full bg-white shadow-sm translate-x-3" />
                                        </div>
                                    </div>
                                </div>
                                <textarea 
                                    className="w-full bg-glass-200 border border-glass-border rounded-xl px-4 py-3 text-sm text-white placeholder-gray-500 min-h-[80px] outline-none focus:bg-glass-300 transition-colors"
                                    placeholder="Short description for clients..."
                                />
                            </section>

                            {/* Section 2: Pricing Model */}
                            <section className="space-y-4">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Pricing Model</h3>
                                <div className="grid grid-cols-1 gap-3">
                                    <PricingOption 
                                        type="fixed" 
                                        selected={pricingType === 'fixed'} 
                                        icon={DollarSign} 
                                        label="Fixed Price" 
                                        desc="Simple flat rate for the service."
                                    />
                                    <PricingOption 
                                        type="variable" 
                                        selected={pricingType === 'variable'} 
                                        icon={Ruler} 
                                        label="Variable Pricing" 
                                        desc="Price adjusts based on size or units."
                                    />
                                    <PricingOption 
                                        type="callout" 
                                        selected={pricingType === 'callout'} 
                                        icon={Smartphone} 
                                        label="Service Call" 
                                        desc="Fee for showing up + hourly rate."
                                    />
                                    <PricingOption 
                                        type="quote" 
                                        selected={pricingType === 'quote'} 
                                        icon={Briefcase} 
                                        label="Quote Only" 
                                        desc="No price shown. Requires estimate."
                                    />
                                </div>

                                {/* Dynamic Pricing Config */}
                                <AnimatePresence mode="wait">
                                    {pricingType === 'fixed' && (
                                        <motion.div key="fixed" initial={{opacity:0}} animate={{opacity:1}} className="pt-2 space-y-4">
                                            <GlassInput icon={DollarSign} placeholder="0.00" />
                                            
                                            {/* Billing Frequency Selector */}
                                            <div>
                                                 <div className="flex items-center gap-2 mb-2">
                                                     <Repeat size={12} className="text-gray-400" />
                                                     <label className="text-xs text-gray-400 font-bold uppercase">Billing Frequency</label>
                                                 </div>
                                                 <div className="grid grid-cols-4 gap-2">
                                                     {[
                                                         { id: 'one-time', label: 'Once' },
                                                         { id: 'weekly', label: 'Weekly' },
                                                         { id: 'bi-weekly', label: '2 Wks' },
                                                         { id: 'monthly', label: 'Month' }
                                                     ].map(freq => (
                                                         <button 
                                                            key={freq.id}
                                                            onClick={() => setBillingFrequency(freq.id as any)}
                                                            className={`py-2 rounded-xl text-xs font-medium border transition-colors duration-200 ${
                                                                billingFrequency === freq.id 
                                                                ? 'bg-homebase text-white border-homebase' 
                                                                : 'bg-glass-200 text-gray-400 border-glass-border hover:bg-glass-300'
                                                            }`}
                                                         >
                                                            {freq.label}
                                                         </button>
                                                     ))}
                                                 </div>
                                            </div>

                                            <div className="flex items-center space-x-3 bg-glass-200 p-3 rounded-xl border border-glass-border">
                                                <Clock size={18} className="text-gray-400" />
                                                <span className="text-sm text-gray-300 flex-1">Duration</span>
                                                <span className="text-sm font-bold text-white">60 mins</span>
                                            </div>
                                        </motion.div>
                                    )}

                                    {pricingType === 'variable' && (
                                        <motion.div key="variable" initial={{opacity:0}} animate={{opacity:1}} className="pt-2 space-y-3">
                                             <GlassInput icon={DollarSign} placeholder="Base Price (Optional)" />
                                             <p className="text-xs text-gray-400 mt-2 mb-2">Adjustable Factors</p>
                                             <div className="flex flex-wrap gap-2">
                                                 {['Bedrooms', 'Bathrooms', 'Sq Ft', 'Hours'].map(factor => (
                                                     <span key={factor} className="px-3 py-1.5 rounded-lg bg-glass-300 border border-white/10 text-xs font-medium text-white flex items-center">
                                                         {factor} <Plus size={12} className="ml-2 text-homebase" />
                                                     </span>
                                                 ))}
                                             </div>
                                             <GlassCard className="p-3 bg-homebase/10 border-homebase/30">
                                                 <p className="text-xs text-homebase font-bold uppercase mb-1">Preview</p>
                                                 <p className="text-sm text-white">Starts at $100 + $25/Bedroom</p>
                                             </GlassCard>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </section>

                            {/* Section 3: Discounts */}
                            <section className="space-y-4">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Discounts & Offers</h3>
                                <GlassCard className="p-4 space-y-4">
                                    {/* Add Discount Input */}
                                    <div className="flex gap-2">
                                        <div className="flex-1">
                                            <div className="relative flex items-center bg-glass-200 border border-glass-border rounded-xl px-4 py-3 backdrop-blur-md">
                                                <Tag size={18} className="text-gray-400 mr-3" />
                                                <input 
                                                    type="text" 
                                                    className="bg-transparent border-none outline-none text-white placeholder-gray-500 w-full text-sm"
                                                    placeholder="Name (e.g. Senior)"
                                                    value={newDiscount.name}
                                                    onChange={e => setNewDiscount({...newDiscount, name: e.target.value})}
                                                />
                                            </div>
                                        </div>
                                        <div className="w-24">
                                             <div className="bg-glass-200 rounded-xl flex items-center border border-glass-border h-full">
                                                <input 
                                                    className="bg-transparent pl-3 w-full text-white text-sm outline-none text-right font-mono" 
                                                    placeholder="0"
                                                    value={newDiscount.amount}
                                                    onChange={e => setNewDiscount({...newDiscount, amount: e.target.value})}
                                                />
                                                <button 
                                                    onClick={() => setNewDiscount({...newDiscount, type: newDiscount.type === 'percent' ? 'fixed' : 'percent'})}
                                                    className="pr-3 pl-1 text-xs text-homebase font-bold w-8 h-full flex items-center justify-center hover:bg-white/5 rounded-r-xl"
                                                >
                                                    {newDiscount.type === 'percent' ? '%' : '$'}
                                                </button>
                                             </div>
                                        </div>
                                        <button 
                                            onClick={addDiscount}
                                            className="bg-glass-200 w-12 flex items-center justify-center rounded-xl text-homebase hover:bg-homebase hover:text-white transition-colors border border-glass-border"
                                        >
                                            <Plus size={20} />
                                        </button>
                                    </div>
                                    
                                    {/* Discounts List */}
                                    <div className="space-y-2">
                                        {discounts.map(d => (
                                            <div key={d.id} className="flex justify-between items-center bg-white/5 p-3 rounded-xl border border-white/5">
                                                <span className="text-sm text-gray-200 font-medium">{d.name}</span>
                                                <div className="flex items-center gap-3">
                                                    <span className="text-sm font-bold text-homebase bg-homebase/10 px-2 py-0.5 rounded-md">
                                                        -{d.type === 'percent' ? `${d.amount}%` : `$${d.amount}`}
                                                    </span>
                                                    <button onClick={() => removeDiscount(d.id)} className="text-gray-600 hover:text-red-400 transition-colors p-1">
                                                        <X size={14} />
                                                    </button>
                                                </div>
                                            </div>
                                        ))}
                                        {discounts.length === 0 && (
                                            <div className="text-center py-2 border-t border-dashed border-white/10 mt-2">
                                                <p className="text-[10px] text-gray-500 italic">No discounts active for this service.</p>
                                            </div>
                                        )}
                                    </div>
                                </GlassCard>
                            </section>

                            {/* Section 4: Booking Rules */}
                            <section className="space-y-4">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Booking Rules</h3>
                                
                                <GlassCard className="p-0 divide-y divide-white/5">
                                    <div className="p-4 flex items-center justify-between">
                                        <div>
                                            <p className="text-sm font-bold text-white">Instant Booking</p>
                                            <p className="text-xs text-gray-400">Allow clients to book without approval</p>
                                        </div>
                                        <div className="w-10 h-6 bg-homebase rounded-full relative">
                                             <div className="absolute right-1 top-1 h-4 w-4 bg-white rounded-full shadow-sm" />
                                        </div>
                                    </div>
                                    <div className="p-4">
                                        <div className="flex justify-between items-center mb-2">
                                            <p className="text-sm font-bold text-white">Intake Questions</p>
                                            <button className="text-xs text-homebase font-bold">+ Add</button>
                                        </div>
                                        <div className="space-y-2">
                                            <div className="p-2 bg-glass-100 rounded-lg text-xs text-gray-300 border border-white/5 flex justify-between">
                                                Do you have pets? (Yes/No)
                                                <X size={14} />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="p-4 flex items-center justify-between">
                                        <p className="text-sm font-bold text-white">Require Photos</p>
                                        <div className="w-10 h-6 bg-glass-300 rounded-full relative">
                                             <div className="absolute left-1 top-1 h-4 w-4 bg-white/50 rounded-full shadow-sm" />
                                        </div>
                                    </div>
                                </GlassCard>
                            </section>

                             {/* Section 5: Scheduling */}
                             <section className="space-y-4">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Availability</h3>
                                <div className="flex gap-3">
                                    <div className="flex-1 bg-glass-200 rounded-xl p-3 border border-glass-border">
                                        <p className="text-xs text-gray-400 mb-1">Buffer Before</p>
                                        <p className="text-sm font-bold text-white">15 mins</p>
                                    </div>
                                    <div className="flex-1 bg-glass-200 rounded-xl p-3 border border-glass-border">
                                        <p className="text-xs text-gray-400 mb-1">Buffer After</p>
                                        <p className="text-sm font-bold text-white">15 mins</p>
                                    </div>
                                </div>
                             </section>

                            {/* Section 6: Preview */}
                            <section className="space-y-4">
                                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">Client Preview</h3>
                                <GlassCard className="p-5 bg-gradient-to-br from-glass-200 to-glass-100 border border-white/10 relative overflow-hidden">
                                    <div className="flex justify-between items-start relative z-10">
                                        <div>
                                            <h4 className="text-lg font-bold text-white">{serviceName || 'New Service'}</h4>
                                            <p className="text-sm text-gray-300 mt-1">{category} • 60 mins</p>
                                            {discounts.length > 0 && (
                                                <div className="flex items-center gap-1 mt-2 text-homebase">
                                                    <Tag size={12} />
                                                    <span className="text-[10px] font-bold uppercase">{discounts.length} Deals Available</span>
                                                </div>
                                            )}
                                        </div>
                                        <div className="text-right">
                                            <p className="text-xl font-bold text-homebase">
                                                {pricingType === 'quote' ? 'Ask for Price' : (
                                                    <>
                                                        $120.00
                                                        {billingFrequency !== 'one-time' && (
                                                            <span className="text-xs text-gray-400 font-medium ml-1">
                                                                / {billingFrequency === 'bi-weekly' ? '2wks' : billingFrequency === 'monthly' ? 'mo' : 'wk'}
                                                            </span>
                                                        )}
                                                    </>
                                                )}
                                            </p>
                                        </div>
                                    </div>
                                    <GlassButton variant="secondary" className="w-full mt-4 text-xs h-10 relative z-10">
                                        See full preview
                                    </GlassButton>
                                    {/* Decorative background accent */}
                                    <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-homebase/10 blur-2xl rounded-full" />
                                </GlassCard>
                            </section>

                        </div>

                        {/* Floating Save Button Area */}
                        <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black via-black/90 to-transparent">
                            <GlassButton onClick={handleCloseEditor} className="w-full shadow-lg shadow-homebase/20">
                                Save Service
                            </GlassButton>
                        </div>

                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
}