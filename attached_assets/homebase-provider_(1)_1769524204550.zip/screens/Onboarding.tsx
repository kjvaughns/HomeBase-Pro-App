import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
    CheckCircle, ArrowRight, Sparkles, MapPin, Briefcase, 
    TrendingUp, Calendar, Clock, DollarSign, Shield, Star, 
    Lock, Check, Smartphone, ThumbsUp, Wrench, Zap, Droplets, 
    Hammer, Scissors, Truck, Camera, MessageSquare
} from 'lucide-react';
import { GlassCard, GlassInput, GlassButton, StatusChip } from '../components/LiquidComponents';

interface OnboardingProps {
    onComplete: () => void;
}

const stepsTotal = 22;

export default function Onboarding({ onComplete }: OnboardingProps) {
    const [step, setStep] = useState(1);
    const [selections, setSelections] = useState<any>({
        industry: '',
        rawDescription: '',
        availability: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        serviceName: '',
        servicePrice: ''
    });
    const [aiText, setAiText] = useState("");
    
    // Hold Button Logic
    const [holdProgress, setHoldProgress] = useState(0);
    const holdInterval = useRef<any>(null);

    const handleNext = () => {
        if (step < stepsTotal) setStep(step + 1);
    };

    const startHold = () => {
        holdInterval.current = setInterval(() => {
            setHoldProgress(prev => {
                if (prev >= 100) {
                    clearInterval(holdInterval.current);
                    return 100;
                }
                return prev + 4; 
            });
        }, 30);
    };

    const stopHold = () => {
        clearInterval(holdInterval.current);
        if (holdProgress < 100) {
            setHoldProgress(0);
        } else {
            handleNext();
        }
    };

    // AI Typing Effect Helper
    useEffect(() => {
        if (step === 8) {
            setAiText("");
            const industry = selections.industry || "General";
            const raw = selections.rawDescription || "We do good work.";
            
            // Mock AI generation based on input
            const fullText = `Premium ${industry.toLowerCase()} services. ${raw.replace(/^\w/, c => c.toUpperCase())}. Professional, reliable, and dedicated to excellence in every job.`;
            
            let i = 0;
            const interval = setInterval(() => {
                setAiText(fullText.substring(0, i));
                i++;
                if (i > fullText.length) clearInterval(interval);
            }, 30);
            return () => clearInterval(interval);
        }
    }, [step]);

    // --- ANIMATION VARIANTS ---
    const slideVariants = {
        enter: { x: 20, opacity: 0 },
        center: { x: 0, opacity: 1 },
        exit: { x: -20, opacity: 0 }
    };

    // --- SUB-COMPONENTS ---
    const SelectionCard = ({ label, id, multi = false }: { label: string, id: string, multi?: boolean }) => {
        const isSelected = multi 
            ? selections[step]?.includes(id) 
            : selections[step] === id;
        
        return (
            <button 
                onClick={() => {
                    if (multi) {
                        const current = selections[step] || [];
                        const updated = current.includes(id) 
                            ? current.filter((i: string) => i !== id) 
                            : [...current, id];
                        setSelections({ ...selections, [step]: updated });
                    } else {
                        setSelections({ ...selections, [step]: id });
                        setTimeout(handleNext, 300);
                    }
                }}
                className={`w-full p-4 rounded-xl border text-left transition-all duration-200 mb-3 flex items-center justify-between ${
                    isSelected 
                    ? 'bg-homebase/20 border-homebase shadow-[0_0_15px_rgba(15,175,110,0.2)]' 
                    : 'bg-glass-200 border-white/5 hover:bg-glass-300'
                }`}
            >
                <span className={`text-sm font-medium ${isSelected ? 'text-white' : 'text-gray-300'}`}>{label}</span>
                {isSelected && <CheckCircle size={18} className="text-homebase" />}
            </button>
        );
    };

    const IndustryCard = ({ icon: Icon, label }: { icon: any, label: string }) => (
        <button
            onClick={() => {
                setSelections({ ...selections, industry: label });
                setTimeout(handleNext, 300);
            }}
            className={`flex flex-col items-center justify-center p-4 rounded-2xl border transition-all duration-200 aspect-square ${
                selections.industry === label
                ? 'bg-homebase/20 border-homebase shadow-[0_0_15px_rgba(15,175,110,0.2)]'
                : 'bg-glass-200 border-white/5 hover:bg-glass-300'
            }`}
        >
            <Icon size={32} className={`mb-3 ${selections.industry === label ? 'text-homebase' : 'text-white'}`} />
            <span className="text-xs font-bold text-white text-center">{label}</span>
        </button>
    );

    // --- RENDER CONTENT ---
    const renderContent = () => {
        switch (step) {
            // --- PHASE 1: ARRIVAL ---
            case 1:
                return (
                    <div className="flex flex-col items-center justify-center h-full text-center px-4">
                        <motion.div 
                            initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.5 }}
                            className="h-24 w-24 bg-homebase/20 rounded-full flex items-center justify-center mb-8 shadow-[0_0_40px_rgba(15,175,110,0.4)]"
                        >
                            <Sparkles size={40} className="text-homebase" />
                        </motion.div>
                        <h1 className="text-3xl font-bold text-white mb-4">Welcome to HomeBase</h1>
                        <p className="text-gray-400 text-lg leading-relaxed max-w-xs">
                            The operating system for modern home service businesses.
                        </p>
                    </div>
                );
            case 2:
                return (
                    <div className="px-6 pt-10">
                        <h2 className="text-2xl font-bold text-white mb-6">Let's set the record straight.</h2>
                        <GlassCard className="p-6 bg-glass-200 border-l-4 border-l-homebase">
                            <p className="text-lg text-white font-medium leading-relaxed">
                                "You are not just 'doing jobs'.<br/><br/>
                                <span className="text-homebase font-bold">You are building a business.</span>"
                            </p>
                        </GlassCard>
                    </div>
                );
            case 3:
                return (
                    <div className="px-6 pt-10">
                        <h2 className="text-2xl font-bold text-white mb-2">Why are you here?</h2>
                        <p className="text-gray-400 mb-8">Select all that apply.</p>
                        <SelectionCard label="I want to look more professional" id="pro" multi />
                        <SelectionCard label="I need to organize my schedule" id="schedule" multi />
                        <SelectionCard label="I'm tired of chasing payments" id="payments" multi />
                        <SelectionCard label="I want to grow my revenue" id="growth" multi />
                    </div>
                );

            // --- PHASE 2: BUSINESS CORE ---
            case 4:
                return (
                    <div className="px-6 pt-10">
                        <h2 className="text-2xl font-bold text-white mb-2">What do you do?</h2>
                        <p className="text-gray-400 mb-8">Select your primary industry.</p>
                        <div className="grid grid-cols-2 gap-3">
                            <IndustryCard icon={Droplets} label="Cleaning" />
                            <IndustryCard icon={Scissors} label="Lawn Care" />
                            <IndustryCard icon={Zap} label="HVAC" />
                            <IndustryCard icon={Hammer} label="Handyman" />
                            <IndustryCard icon={Wrench} label="Plumbing" />
                            <IndustryCard icon={Truck} label="Moving" />
                        </div>
                        <div className="mt-4">
                            <GlassInput placeholder="Other (Type here)" />
                        </div>
                    </div>
                );
            case 5:
                return (
                    <div className="px-6 pt-10">
                        <h2 className="text-2xl font-bold text-white mb-2">Business Name</h2>
                        <p className="text-gray-400 mb-8">What do your clients call you?</p>
                        <GlassInput placeholder="e.g. Joe's Services" icon={Briefcase} />
                    </div>
                );
            case 6:
                return (
                    <div className="px-6 pt-10">
                        <h2 className="text-2xl font-bold text-white mb-2">Location</h2>
                        <p className="text-gray-400 mb-8">Where are you based?</p>
                        <GlassInput placeholder="Zip Code or City" icon={MapPin} />
                        <div className="mt-4 flex gap-2 flex-wrap">
                            <span className="px-3 py-1 bg-glass-200 rounded-full text-xs text-gray-300">San Francisco</span>
                            <span className="px-3 py-1 bg-glass-200 rounded-full text-xs text-gray-300">Bay Area</span>
                        </div>
                    </div>
                );
            case 7:
                 return (
                     <div className="px-6 pt-10">
                         <h2 className="text-2xl font-bold text-white mb-2">In your own words...</h2>
                         <p className="text-gray-400 mb-6">Describe what you do like you're talking to a friend. We'll handle the professional polish.</p>
                         <textarea 
                             className="w-full h-32 bg-glass-200 border border-glass-border rounded-xl p-4 text-white placeholder-gray-500 outline-none focus:border-homebase/50 transition-colors resize-none"
                             placeholder="e.g. I mow lawns, trim hedges, and do basic yard cleanup. I'm really good at detail work..."
                             value={selections.rawDescription}
                             onChange={(e) => setSelections({...selections, rawDescription: e.target.value})}
                         />
                     </div>
                 );
            case 8:
                return (
                    <div className="px-6 pt-10">
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-2xl font-bold text-white">Your Pro Profile</h2>
                            <div className="flex items-center gap-1 text-homebase text-xs font-bold uppercase">
                                <Sparkles size={12} /> AI Generating
                            </div>
                        </div>
                        <GlassCard className="p-6 min-h-[200px] relative bg-gradient-to-br from-glass-200 to-glass-100">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="h-10 w-10 bg-homebase rounded-lg flex items-center justify-center font-bold text-white">
                                    {selections.industry?.[0] || 'B'}
                                </div>
                                <div>
                                    <div className="h-4 w-32 bg-white/10 rounded mb-1" />
                                    <div className="h-3 w-20 bg-white/5 rounded" />
                                </div>
                            </div>
                            <div className="absolute top-4 right-4 h-2 w-2 bg-homebase rounded-full animate-ping" />
                            <p className="text-lg text-gray-200 leading-relaxed font-medium">
                                {aiText}<span className="animate-pulse">|</span>
                            </p>
                        </GlassCard>
                        <p className="text-center text-xs text-gray-500 mt-4">We translated your notes into a professional bio.</p>
                    </div>
                );
            case 9:
                return (
                    <div className="px-6 pt-10">
                        <h2 className="text-2xl font-bold text-white mb-6">Visual Identity</h2>
                        <div className="flex flex-col items-center justify-center space-y-6">
                            <div className="relative h-32 w-32 rounded-full bg-glass-200 border-2 border-dashed border-gray-600 flex items-center justify-center group cursor-pointer hover:border-homebase transition-colors">
                                <Camera size={32} className="text-gray-400 group-hover:text-homebase" />
                                <div className="absolute -bottom-2 bg-black px-2 text-xs text-gray-400">Add Logo</div>
                            </div>
                            <p className="text-center text-sm text-gray-400 max-w-xs">
                                Adding a logo increases client trust by <span className="text-homebase font-bold">40%</span>.
                            </p>
                        </div>
                    </div>
                );

            // --- PHASE 3: OPERATIONS SETUP ---
            case 10:
                 return (
                     <div className="px-6 pt-10">
                         <h2 className="text-2xl font-bold text-white mb-2">Availability</h2>
                         <p className="text-gray-400 mb-6">When do you work?</p>
                         <div className="space-y-2">
                             {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => {
                                 const isActive = selections.availability.includes(day);
                                 return (
                                     <button 
                                        key={day}
                                        onClick={() => {
                                            const current = selections.availability;
                                            setSelections({
                                                ...selections, 
                                                availability: isActive ? current.filter((d: string) => d !== day) : [...current, day]
                                            });
                                        }}
                                        className={`flex items-center justify-between w-full p-3 rounded-xl border transition-all ${
                                            isActive 
                                            ? 'bg-glass-200 border-homebase/50' 
                                            : 'bg-glass-100 border-white/5 opacity-50'
                                        }`}
                                     >
                                         <span className="text-sm font-bold text-white">{day}</span>
                                         <div className={`w-10 h-6 rounded-full relative transition-colors ${isActive ? 'bg-homebase' : 'bg-gray-700'}`}>
                                             <div className={`absolute top-1 h-4 w-4 bg-white rounded-full transition-all ${isActive ? 'left-5' : 'left-1'}`} />
                                         </div>
                                     </button>
                                 )
                             })}
                         </div>
                     </div>
                 );
            case 11:
                return (
                    <div className="px-6 pt-10">
                         <h2 className="text-2xl font-bold text-white mb-6">Let's build your service menu.</h2>
                         <p className="text-gray-400 text-lg mb-8">
                             Stop creating quotes from scratch. Define your core service once, sell it forever.
                         </p>
                         <GlassCard className="p-4 bg-homebase/10 border-homebase/30">
                             <div className="flex justify-between items-center">
                                 <div>
                                     <p className="font-bold text-white">{selections.industry || 'Service'} Package</p>
                                     <p className="text-xs text-gray-300">1h • Fixed Price</p>
                                 </div>
                                 <p className="font-bold text-homebase">$100+</p>
                             </div>
                         </GlassCard>
                    </div>
                );
            case 12:
                return (
                    <div className="px-6 pt-10">
                        <h2 className="text-2xl font-bold text-white mb-6">Create your first service</h2>
                        <div className="space-y-4">
                            <GlassInput 
                                placeholder="Service Name (e.g. Lawn Mowing)" 
                                icon={Briefcase} 
                                value={selections.serviceName}
                                onChange={(e) => setSelections({...selections, serviceName: e.target.value})}
                            />
                            <div className="flex gap-3">
                                <button className="flex-1 p-3 bg-glass-200 rounded-xl border border-glass-border text-sm text-white font-medium text-center hover:bg-homebase/20 hover:border-homebase transition-all ring-1 ring-homebase">
                                    Fixed Price
                                </button>
                                <button className="flex-1 p-3 bg-glass-200 rounded-xl border border-glass-border text-sm text-gray-400 font-medium text-center">
                                    Hourly
                                </button>
                            </div>
                            <GlassInput 
                                placeholder="Price ($)" 
                                icon={DollarSign}
                                value={selections.servicePrice}
                                onChange={(e) => setSelections({...selections, servicePrice: e.target.value})}
                            />
                        </div>
                    </div>
                );
            case 13:
                return (
                     <div className="px-6 pt-10">
                         <h2 className="text-2xl font-bold text-white mb-4">Pricing Confidence</h2>
                         <p className="text-gray-400 mb-8">Based on your area, similar pros charge between <span className="text-white font-bold">$120 - $150</span> for this service.</p>
                         <div className="bg-glass-200 rounded-xl p-6 border border-glass-border relative overflow-hidden">
                             <div className="flex justify-between text-sm text-gray-400 mb-2">
                                 <span>Market Avg</span>
                                 <span>$135</span>
                             </div>
                             <div className="flex justify-between text-sm text-gray-400 mb-4">
                                 <span>Your Price</span>
                                 <span className="text-homebase font-bold">${selections.servicePrice || '0'}</span>
                             </div>
                             <div className="h-1 w-full bg-gray-700 rounded-full overflow-hidden">
                                 <div className="h-full bg-homebase w-2/3" />
                             </div>
                             <p className="text-xs text-green-400 mt-2 font-bold flex items-center">
                                 <TrendingUp size={12} className="mr-1" /> You are competitive!
                             </p>
                         </div>
                     </div>
                );

            // --- PHASE 4: PREVIEW & VALIDATION ---
            case 14:
                return (
                    <div className="px-6 pt-10">
                        <div className="text-center mb-8">
                            <h2 className="text-2xl font-bold text-white mb-2">Meet Your AI Assistant</h2>
                            <p className="text-gray-400">It handles the busy work while you work.</p>
                        </div>
                        
                        <div className="relative">
                            <GlassCard className="p-4 space-y-4">
                                {/* Simulated Chat */}
                                <motion.div 
                                    initial={{ opacity: 0, x: -20 }} 
                                    animate={{ opacity: 1, x: 0 }} 
                                    transition={{ delay: 0.5 }}
                                    className="bg-glass-200 p-3 rounded-xl rounded-tl-none border border-white/5 w-[85%]"
                                >
                                    <p className="text-xs text-gray-400 mb-1">Client</p>
                                    <p className="text-sm text-white">Hey, can you fit me in for a {selections.serviceName || 'job'} tomorrow?</p>
                                </motion.div>

                                <motion.div 
                                    initial={{ opacity: 0, scale: 0.8 }} 
                                    animate={{ opacity: 1, scale: 1 }} 
                                    transition={{ delay: 1.5 }}
                                    className="flex justify-center"
                                >
                                    <div className="bg-homebase/20 px-3 py-1 rounded-full text-xs text-homebase font-bold flex items-center gap-2">
                                        <Sparkles size={12} /> Checking schedule...
                                    </div>
                                </motion.div>

                                <motion.div 
                                    initial={{ opacity: 0, x: 20 }} 
                                    animate={{ opacity: 1, x: 0 }} 
                                    transition={{ delay: 3 }}
                                    className="bg-homebase p-3 rounded-xl rounded-tr-none ml-auto w-[85%]"
                                >
                                    <p className="text-xs text-white/70 mb-1">HomeBase AI</p>
                                    <p className="text-sm text-white">I checked the schedule. You have an opening at 2 PM. Shall I book it?</p>
                                </motion.div>
                            </GlassCard>
                        </div>
                    </div>
                );
            case 15:
                return (
                    <div className="px-6 pt-6 flex flex-col h-full pb-20">
                        <h2 className="text-xl font-bold text-white mb-4 text-center">Your New Business Profile</h2>
                        
                        {/* Profile Preview Card */}
                        <div className="flex-1 bg-black border border-white/10 rounded-3xl overflow-hidden relative shadow-2xl">
                             {/* Header Img */}
                             <div className="h-32 bg-gray-800 relative">
                                 <img src="https://picsum.photos/400/200" className="w-full h-full object-cover opacity-50" />
                                 <div className="absolute -bottom-8 left-4 h-16 w-16 bg-black rounded-xl border-2 border-homebase flex items-center justify-center">
                                     <span className="text-2xl font-bold text-white">{selections.industry?.[0] || 'B'}</span>
                                 </div>
                             </div>
                             
                             <div className="pt-10 px-4">
                                 <h3 className="text-lg font-bold text-white">Clean & Co.</h3>
                                 <div className="flex items-center gap-1 text-homebase text-xs mb-4">
                                     <Star size={10} fill="currentColor" /> 5.0 (New)
                                 </div>
                                 
                                 <div className="text-xs text-gray-400 mb-6 line-clamp-3">
                                     {aiText || "Professional services..."}
                                 </div>

                                 <h4 className="text-xs font-bold text-white uppercase mb-2">Services</h4>
                                 <div className="p-3 bg-white/5 rounded-xl flex justify-between items-center mb-2">
                                     <span className="text-sm text-gray-200">{selections.serviceName || 'Service'}</span>
                                     <span className="text-sm font-bold text-white">${selections.servicePrice || '100'}</span>
                                 </div>
                             </div>
                             
                             {/* Fake Button */}
                             <div className="absolute bottom-4 left-4 right-4">
                                 <div className="w-full h-10 bg-homebase rounded-lg flex items-center justify-center text-sm font-bold text-white">
                                     Book Now
                                 </div>
                             </div>
                        </div>
                    </div>
                );
            case 16:
                return (
                    <div className="px-6 pt-10">
                        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
                            <div className="bg-homebase/20 w-16 h-16 rounded-2xl flex items-center justify-center mb-6 text-homebase">
                                <Calendar size={32} />
                            </div>
                            <h2 className="text-3xl font-bold text-white mb-4">No more chaos.</h2>
                            <p className="text-gray-400 text-lg">
                                Your schedule, your jobs, your life. Everything in one place.
                            </p>
                        </motion.div>
                    </div>
                );
            case 17:
                return (
                     <div className="px-6 pt-10">
                         <h2 className="text-2xl font-bold text-white mb-8">The Money Pipeline</h2>
                         <div className="space-y-4">
                             <GlassCard className="flex items-center gap-4 border-l-4 border-l-blue-500">
                                 <Briefcase className="text-blue-500" />
                                 <div><p className="font-bold text-white">Job Done</p></div>
                                 <ArrowRight className="ml-auto text-gray-600" />
                             </GlassCard>
                             <GlassCard className="flex items-center gap-4 border-l-4 border-l-purple-500">
                                 <Clock className="text-purple-500" />
                                 <div><p className="font-bold text-white">Auto-Invoice</p></div>
                                 <ArrowRight className="ml-auto text-gray-600" />
                             </GlassCard>
                             <GlassCard className="flex items-center gap-4 border-l-4 border-l-homebase">
                                 <DollarSign className="text-homebase" />
                                 <div><p className="font-bold text-white">Paid Instantly</p></div>
                                 <CheckCircle className="ml-auto text-homebase" />
                             </GlassCard>
                         </div>
                     </div>
                );
            case 18:
                return (
                    <div className="px-6 pt-10">
                        <h2 className="text-2xl font-bold text-white mb-6">We'll handle the busy work.</h2>
                        <div className="space-y-3">
                             {['Remind clients of appointments', 'Follow up on unpaid invoices', 'Request reviews after jobs', 'Track your expenses'].map((item, i) => (
                                 <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-glass-100">
                                     <div className="p-1 bg-homebase rounded-full"><Check size={12} className="text-black" /></div>
                                     <span className="text-sm text-white">{item}</span>
                                 </div>
                             ))}
                        </div>
                    </div>
                );
            case 19:
                return (
                    <div className="px-6 pt-10 text-center">
                        <div className="w-20 h-20 bg-glass-200 rounded-full mx-auto mb-6 flex items-center justify-center border border-white/10">
                            <Smartphone size={32} className="text-white" />
                        </div>
                        <h2 className="text-2xl font-bold text-white mb-4">Your Operations Manager</h2>
                        <p className="text-gray-400 mb-8">
                            Think of HomeBase as the partner who handles the boring stuff so you can do the work you love.
                        </p>
                    </div>
                );

            // --- PHASE 5: COMMITMENT ---
            case 20:
                return (
                    <div className="px-6 pt-10 text-center">
                        <h2 className="text-2xl font-bold text-white mb-2">The Future</h2>
                        <p className="text-gray-400 mb-8">In 30 days, your business could look like this.</p>
                        <div className="h-48 w-full bg-glass-200 rounded-2xl border border-glass-border flex items-end px-4 pb-0 relative overflow-hidden">
                             <div className="absolute inset-0 bg-gradient-to-t from-homebase/10 to-transparent" />
                             {/* Fake Graph */}
                             <svg className="w-full h-32" viewBox="0 0 100 50" preserveAspectRatio="none">
                                 <path d="M0,50 L10,45 L20,48 L30,35 L40,30 L50,35 L60,20 L70,15 L80,10 L90,5 L100,0 L100,50 Z" fill="rgba(15,175,110,0.2)" />
                                 <path d="M0,50 L10,45 L20,48 L30,35 L40,30 L50,35 L60,20 L70,15 L80,10 L90,5 L100,0" fill="none" stroke="#0FAF6E" strokeWidth="2" />
                             </svg>
                        </div>
                        <div className="flex justify-between mt-4 px-2">
                            <div className="text-left">
                                <p className="text-xs text-gray-400">Monthly Rev</p>
                                <p className="text-lg font-bold text-white">$8,500</p>
                            </div>
                            <div className="text-right">
                                <p className="text-xs text-gray-400">Time Saved</p>
                                <p className="text-lg font-bold text-homebase">20hrs</p>
                            </div>
                        </div>
                    </div>
                );
            case 21:
                return (
                    <div className="px-6 pt-20 text-center">
                        <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }}>
                            <ThumbsUp size={60} className="text-homebase mx-auto mb-8" />
                            <h2 className="text-3xl font-bold text-white mb-6">You're ready.</h2>
                            <p className="text-xl text-gray-300 mb-12">
                                Press and hold to initialize your new business operating system.
                            </p>
                            
                            {/* Hold Button */}
                            <div className="relative h-20 w-full max-w-xs mx-auto">
                                <motion.button
                                    onPointerDown={startHold}
                                    onPointerUp={stopHold}
                                    onPointerLeave={stopHold}
                                    className="relative w-full h-full bg-glass-200 rounded-2xl border border-homebase/30 overflow-hidden flex items-center justify-center"
                                    whileTap={{ scale: 0.98 }}
                                >
                                    <span className="relative z-10 text-lg font-bold text-white uppercase tracking-wider">Hold to Launch</span>
                                    <motion.div 
                                        className="absolute inset-0 bg-homebase origin-left"
                                        style={{ width: `${holdProgress}%` }}
                                    />
                                </motion.button>
                            </div>
                        </motion.div>
                    </div>
                );
            case 22:
                return (
                    <div className="px-6 pt-6 h-full flex flex-col relative">
                        {/* Background Elements to simulate dashboard behind */}
                        <div className="absolute inset-0 bg-black/60 backdrop-blur-xl z-0" />
                        
                        <div className="relative z-10 flex flex-col h-full pb-8">
                            <div className="text-center mb-6">
                                <div className="inline-flex items-center justify-center p-3 bg-homebase/20 rounded-full mb-4">
                                    <Lock size={24} className="text-homebase" />
                                </div>
                                <h2 className="text-2xl font-bold text-white">Unlock Your Business</h2>
                                <p className="text-gray-400 mt-2 text-sm">Start your 14-day free trial. Cancel anytime.</p>
                            </div>

                            <div className="space-y-4 mb-auto">
                                <button className="w-full bg-glass-200 border-2 border-homebase rounded-2xl p-4 relative overflow-hidden">
                                    <div className="absolute top-0 right-0 bg-homebase text-black text-[10px] font-bold px-3 py-1 rounded-bl-xl">
                                        MOST POPULAR
                                    </div>
                                    <div className="text-left">
                                        <p className="text-sm font-bold text-gray-300">Annual Plan</p>
                                        <div className="flex items-end gap-1 mt-1">
                                            <span className="text-3xl font-bold text-white">$29</span>
                                            <span className="text-sm text-gray-400 mb-1">/mo</span>
                                        </div>
                                        <p className="text-xs text-homebase mt-2 font-medium">Save 40% ($240/yr)</p>
                                    </div>
                                </button>

                                <button className="w-full bg-glass-100 border border-white/10 rounded-2xl p-4">
                                    <div className="text-left">
                                        <p className="text-sm font-bold text-gray-300">Monthly Plan</p>
                                        <div className="flex items-end gap-1 mt-1">
                                            <span className="text-3xl font-bold text-white">$49</span>
                                            <span className="text-sm text-gray-400 mb-1">/mo</span>
                                        </div>
                                    </div>
                                </button>
                            </div>

                            <div className="space-y-4 mt-4">
                                <div className="flex flex-col gap-2">
                                     <div className="flex items-center gap-2 text-xs text-gray-300">
                                         <Check size={14} className="text-homebase" /> Unlimited Clients & Jobs
                                     </div>
                                     <div className="flex items-center gap-2 text-xs text-gray-300">
                                         <Check size={14} className="text-homebase" /> Automated Invoicing
                                     </div>
                                     <div className="flex items-center gap-2 text-xs text-gray-300">
                                         <Check size={14} className="text-homebase" /> AI Business Assistant
                                     </div>
                                </div>

                                <GlassButton 
                                    onClick={onComplete} 
                                    className="w-full h-14 text-lg font-bold shadow-[0_0_30px_rgba(15,175,110,0.4)]"
                                >
                                    Start Free Trial
                                </GlassButton>
                                <p className="text-center text-[10px] text-gray-500">
                                    Recurring billing. Cancel anytime in settings.
                                </p>
                            </div>
                        </div>
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className="absolute inset-0 z-[100] bg-black text-white flex flex-col safe-top safe-bottom">
            {/* Background Ambience */}
            <div className="absolute top-[-20%] right-[-20%] w-[80%] h-[80%] bg-homebase/10 blur-[100px] pointer-events-none rounded-full" />
            
            {/* Progress Header (Hidden on first and last step for immersion) */}
            {step > 1 && step < 22 && (
                <div className="px-6 py-4 flex items-center gap-3">
                    <div className="flex-1 h-1 bg-glass-200 rounded-full overflow-hidden">
                        <motion.div 
                            className="h-full bg-homebase" 
                            initial={{ width: 0 }}
                            animate={{ width: `${(step / stepsTotal) * 100}%` }}
                        />
                    </div>
                    <span className="text-xs font-mono text-gray-500">{step}/{stepsTotal}</span>
                </div>
            )}

            {/* Main Content Area */}
            <div className="flex-1 relative overflow-hidden flex flex-col">
                <AnimatePresence mode="wait">
                    <motion.div
                        key={step}
                        variants={slideVariants}
                        initial="enter"
                        animate="center"
                        exit="exit"
                        transition={{ duration: 0.3, type: "spring", bounce: 0, stiffness: 300, damping: 30 }}
                        className="flex-1 flex flex-col"
                    >
                        {renderContent()}
                    </motion.div>
                </AnimatePresence>
            </div>

            {/* Footer Actions (Hidden on Paywall and Hold Step) */}
            {step < 21 && (
                <div className="p-6 bg-gradient-to-t from-black via-black/90 to-transparent">
                    <GlassButton 
                        onClick={handleNext} 
                        className="w-full h-14 text-base font-bold flex justify-between px-6 group"
                    >
                        <span>{step === 1 ? "Get Started" : "Continue"}</span>
                        <ArrowRight className="group-hover:translate-x-1 transition-transform" />
                    </GlassButton>
                </div>
            )}
        </div>
    );
}