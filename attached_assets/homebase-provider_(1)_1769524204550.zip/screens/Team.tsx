import React, { useState } from 'react';
import { GlassHeader, GlassCard, GlassButton, GlassSheet, GlassInput, StatusChip } from '../components/LiquidComponents';
import { 
    Users, Plus, ArrowLeft, Star, Briefcase, MapPin, 
    MoreHorizontal, Phone, MessageCircle, Shield, CheckCircle, 
    Sparkles, UserPlus, Clock, Navigation, Camera, Settings, ArrowRight,
    ToggleLeft, ToggleRight, X, Mail
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface TeamProps {
    onBack: () => void;
}

interface TeamMember {
    id: string;
    name: string;
    role: 'Owner' | 'Admin' | 'Technician';
    status: 'available' | 'on-job' | 'offline';
    avatar: string;
    jobsToday: number;
    completedJobs: number;
    rating: number;
    phone: string;
    email: string;
}

const MOCK_TEAM: TeamMember[] = [
    { id: '1', name: 'You', role: 'Owner', status: 'available', avatar: 'https://picsum.photos/100/100', jobsToday: 1, completedJobs: 142, rating: 5.0, phone: '', email: '' },
    { id: '2', name: 'Mike Ross', role: 'Technician', status: 'on-job', avatar: 'https://picsum.photos/101/101', jobsToday: 3, completedJobs: 45, rating: 4.8, phone: '555-0101', email: 'mike@clean.co' },
    { id: '3', name: 'Rachel Zane', role: 'Admin', status: 'offline', avatar: 'https://picsum.photos/102/102', jobsToday: 0, completedJobs: 0, rating: 0, phone: '555-0102', email: 'rachel@clean.co' },
];

export default function Team({ onBack }: TeamProps) {
    const [view, setView] = useState<'overview' | 'detail' | 'portal'>('overview');
    const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
    const [isInviteOpen, setIsInviteOpen] = useState(false);
    const [inviteStep, setInviteStep] = useState(1);

    // --- SUB-VIEWS ---

    const renderOverview = () => (
        <div className="pb-24">
            <GlassHeader 
                title="My Team" 
                rightAction={
                    <button onClick={() => setIsInviteOpen(true)} className="bg-homebase p-2 rounded-full text-white shadow-[0_0_15px_rgba(15,175,110,0.4)]">
                        <Plus size={20} />
                    </button>
                }
            />
            <div className="absolute top-14 left-4 z-50">
                <button onClick={onBack} className="p-2 bg-glass-200 rounded-full backdrop-blur-md">
                    <ArrowLeft size={20} className="text-white" />
                </button>
            </div>

            <div className="px-5 mt-6 space-y-4">
                {/* Status Summary */}
                <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                    <GlassCard className="min-w-[120px] p-3 flex flex-col items-center justify-center border-l-4 border-l-homebase">
                        <span className="text-2xl font-bold text-white">3</span>
                        <span className="text-[10px] text-gray-400 uppercase tracking-wide">Total Members</span>
                    </GlassCard>
                    <GlassCard className="min-w-[120px] p-3 flex flex-col items-center justify-center border-l-4 border-l-blue-500">
                        <span className="text-2xl font-bold text-white">1</span>
                        <span className="text-[10px] text-gray-400 uppercase tracking-wide">Active Jobs</span>
                    </GlassCard>
                </div>

                {/* Team List */}
                <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Team Members</h3>
                <div className="space-y-3">
                    {MOCK_TEAM.map(member => (
                        <GlassCard 
                            key={member.id} 
                            onClick={() => { setSelectedMember(member); setView('detail'); }}
                            className="p-4 flex items-center justify-between active:scale-[0.98] transition-transform cursor-pointer"
                        >
                            <div className="flex items-center gap-4">
                                <div className="relative">
                                    <img src={member.avatar} className="w-12 h-12 rounded-full object-cover border border-white/10" />
                                    <div className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-black ${
                                        member.status === 'available' ? 'bg-green-500' : 
                                        member.status === 'on-job' ? 'bg-yellow-500' : 'bg-gray-500'
                                    }`} />
                                </div>
                                <div>
                                    <h4 className="text-sm font-bold text-white">{member.name}</h4>
                                    <div className="flex items-center gap-2">
                                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                                            member.role === 'Owner' ? 'bg-purple-500/20 text-purple-400' :
                                            member.role === 'Admin' ? 'bg-blue-500/20 text-blue-400' :
                                            'bg-gray-700 text-gray-300'
                                        }`}>
                                            {member.role}
                                        </span>
                                        {member.status === 'on-job' && (
                                            <span className="text-[10px] text-yellow-500 font-medium">On Job</span>
                                        )}
                                    </div>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className="text-lg font-bold text-white">{member.jobsToday}</p>
                                <p className="text-[10px] text-gray-500 uppercase">Jobs Today</p>
                            </div>
                        </GlassCard>
                    ))}
                </div>

                {/* Empty State Mockup */}
                <div className="mt-8 border-t border-white/5 pt-8 text-center opacity-60">
                    <div className="w-16 h-16 bg-glass-200 rounded-full mx-auto flex items-center justify-center mb-4">
                        <UserPlus size={24} className="text-gray-400" />
                    </div>
                    <p className="text-sm text-gray-300 font-bold">Grow your operation</p>
                    <p className="text-xs text-gray-500 mt-1 max-w-xs mx-auto">Invite more technicians to handle more jobs and increase revenue.</p>
                </div>
            </div>
        </div>
    );

    const renderDetail = () => {
        if (!selectedMember) return null;
        return (
            <div className="pb-24 bg-black min-h-full">
                 <div className="relative h-40 bg-gradient-to-b from-gray-900 to-black border-b border-white/5">
                     <button onClick={() => setView('overview')} className="absolute top-14 left-4 p-2 bg-glass-200 rounded-full backdrop-blur-md z-10">
                        <ArrowLeft size={20} className="text-white" />
                     </button>
                     <div className="absolute -bottom-12 left-6">
                        <div className="relative">
                            <img src={selectedMember.avatar} className="w-24 h-24 rounded-2xl border-4 border-black object-cover" />
                            <div className={`absolute -bottom-1 -right-1 h-6 w-6 rounded-full border-4 border-black flex items-center justify-center ${
                                selectedMember.status === 'available' ? 'bg-green-500' : 
                                selectedMember.status === 'on-job' ? 'bg-yellow-500' : 'bg-gray-500'
                            }`}>
                                {selectedMember.status === 'on-job' && <Clock size={12} className="text-black font-bold" />}
                            </div>
                        </div>
                     </div>
                 </div>

                 <div className="mt-14 px-6">
                     <div className="flex justify-between items-start">
                         <div>
                             <h2 className="text-2xl font-bold text-white">{selectedMember.name}</h2>
                             <p className="text-gray-400 text-sm">{selectedMember.role} • Joined Oct 2023</p>
                         </div>
                         <div className="flex gap-2">
                             <GlassButton variant="secondary" className="!p-2.5 rounded-full"><Phone size={18}/></GlassButton>
                             <GlassButton variant="secondary" className="!p-2.5 rounded-full"><MessageCircle size={18}/></GlassButton>
                         </div>
                     </div>

                     {/* Stats */}
                     <div className="grid grid-cols-2 gap-3 mt-6">
                         <GlassCard className="p-3">
                             <p className="text-xs text-gray-400 uppercase">Performance</p>
                             <div className="flex items-end gap-1 mt-1">
                                 <span className="text-xl font-bold text-white">{selectedMember.rating}</span>
                                 <div className="flex pb-1.5"><Star size={10} className="fill-homebase text-homebase" /></div>
                             </div>
                         </GlassCard>
                         <GlassCard className="p-3">
                             <p className="text-xs text-gray-400 uppercase">Jobs Done</p>
                             <span className="text-xl font-bold text-white mt-1">{selectedMember.completedJobs}</span>
                         </GlassCard>
                     </div>

                     {/* Team Portal Access */}
                     <div className="mt-6">
                         <GlassCard className="p-1 bg-gradient-to-r from-homebase/20 to-glass-100 border-homebase/30">
                             <button 
                                onClick={() => setView('portal')}
                                className="w-full py-3 flex items-center justify-center gap-2 text-sm font-bold text-white hover:bg-white/5 rounded-xl transition-colors"
                             >
                                 <Sparkles size={16} className="text-homebase" />
                                 Open Team Portal View
                             </button>
                         </GlassCard>
                         <p className="text-center text-[10px] text-gray-500 mt-2">
                             Preview what {selectedMember.name.split(' ')[0]} sees in their app.
                         </p>
                     </div>

                     {/* Permissions Mockup */}
                     <div className="mt-8">
                         <h3 className="text-sm font-bold text-white mb-4">Permissions</h3>
                         <div className="space-y-4">
                             {[
                                 { label: 'View Full Schedule', enabled: true },
                                 { label: 'Create Invoices', enabled: false },
                                 { label: 'See Pricing', enabled: false },
                                 { label: 'Edit Client Details', enabled: true },
                             ].map((perm, i) => (
                                 <div key={i} className="flex items-center justify-between">
                                     <span className="text-sm text-gray-300">{perm.label}</span>
                                     {perm.enabled ? <ToggleRight size={24} className="text-homebase" /> : <ToggleLeft size={24} className="text-gray-600" />}
                                 </div>
                             ))}
                         </div>
                     </div>
                 </div>
            </div>
        );
    }

    // --- TEAM PORTAL SIMULATION ---
    const renderPortal = () => (
        <div className="fixed inset-0 z-[60] bg-black flex flex-col safe-top safe-bottom">
            {/* Simulation Banner */}
            <div className="bg-homebase px-4 py-2 flex justify-between items-center shadow-lg z-50">
                <span className="text-xs font-bold text-black uppercase tracking-wide flex items-center gap-2">
                    <Sparkles size={12} /> Viewing as {selectedMember?.name}
                </span>
                <button onClick={() => setView('detail')} className="text-xs font-bold text-black border border-black/20 px-3 py-1 rounded-full hover:bg-black/10">
                    Exit
                </button>
            </div>

            {/* Portal Content */}
            <div className="flex-1 bg-gray-900 overflow-y-auto">
                <div className="p-6">
                    <h1 className="text-2xl font-bold text-white mb-1">Good Morning, {selectedMember?.name.split(' ')[0]}</h1>
                    <p className="text-gray-400 text-sm mb-6">You have 3 jobs today.</p>

                    {/* Today's Jobs List */}
                    <div className="space-y-4">
                        {[
                            { time: '09:00 AM', client: 'Sarah Miller', service: 'Deep Clean', address: '123 Pine St', status: 'In Progress' },
                            { time: '11:30 AM', client: 'TechStart Office', service: 'Maintenance', address: '400 Market St', status: 'Scheduled' },
                            { time: '02:00 PM', client: 'James Wilson', service: 'Move-out', address: '880 Mission St', status: 'Scheduled', ai: true }
                        ].map((job, i) => (
                            <div key={i} className="bg-gray-800 rounded-2xl p-4 border border-gray-700 shadow-xl">
                                <div className="flex justify-between items-start mb-3">
                                    <div className="bg-gray-700 px-3 py-1 rounded-lg">
                                        <span className="text-sm font-bold text-white">{job.time}</span>
                                    </div>
                                    {job.ai && (
                                        <div className="flex items-center gap-1 text-[10px] text-homebase font-bold bg-homebase/10 px-2 py-1 rounded-full border border-homebase/20">
                                            <Sparkles size={10} /> Auto-Assigned
                                        </div>
                                    )}
                                </div>
                                
                                <h3 className="text-lg font-bold text-white">{job.client}</h3>
                                <p className="text-sm text-homebase font-medium mb-1">{job.service}</p>
                                <p className="text-xs text-gray-400 flex items-center mb-4">
                                    <MapPin size={12} className="mr-1" /> {job.address}
                                </p>

                                <div className="grid grid-cols-2 gap-3 pt-3 border-t border-gray-700">
                                    <button className="flex items-center justify-center gap-2 py-2 bg-gray-700 rounded-lg text-xs font-bold text-white">
                                        <Navigation size={14} /> Navigate
                                    </button>
                                    <button className={`flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-bold ${
                                        job.status === 'In Progress' ? 'bg-homebase text-white' : 'bg-gray-700 text-white'
                                    }`}>
                                        {job.status === 'In Progress' ? 'Complete' : 'Start Job'}
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* AI Assignment Demo */}
                    <div className="mt-8 p-4 bg-gradient-to-r from-blue-900/40 to-purple-900/40 border border-blue-500/30 rounded-2xl">
                        <div className="flex gap-3">
                            <div className="p-2 bg-blue-500 rounded-lg h-fit">
                                <Sparkles size={18} className="text-white" />
                            </div>
                            <div>
                                <h4 className="text-sm font-bold text-white">Smart Assignment Active</h4>
                                <p className="text-xs text-gray-300 mt-1 leading-relaxed">
                                    Jobs are automatically routed to you based on your location to minimize drive time.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );

    // --- RENDER ---
    return (
        <AnimatePresence mode="wait">
            {view === 'overview' && (
                <motion.div key="overview" initial={{opacity:0, x:-20}} animate={{opacity:1, x:0}} exit={{opacity:0, x:-20}} className="h-full">
                    {renderOverview()}
                </motion.div>
            )}
            
            {view === 'detail' && (
                <motion.div key="detail" initial={{opacity:0, x:20}} animate={{opacity:1, x:0}} exit={{opacity:0, x:20}} className="h-full">
                    {renderDetail()}
                </motion.div>
            )}

            {view === 'portal' && (
                <motion.div key="portal" initial={{opacity:0, scale:0.95}} animate={{opacity:1, scale:1}} exit={{opacity:0, scale:0.95}}>
                    {renderPortal()}
                </motion.div>
            )}

            {/* Invite Sheet */}
            <GlassSheet isOpen={isInviteOpen} onClose={() => { setIsInviteOpen(false); setInviteStep(1); }} title="Invite Member">
                <div className="pb-4">
                    {inviteStep === 1 ? (
                        <div className="space-y-4">
                            <p className="text-sm text-gray-400">Send an invite link via email or text.</p>
                            <GlassInput icon={Mail} placeholder="Email Address" />
                            <GlassInput icon={Phone} placeholder="Phone Number" />
                            
                            <div>
                                <p className="text-xs font-bold text-gray-500 uppercase mb-2">Role</p>
                                <div className="grid grid-cols-2 gap-3">
                                    <button className="p-3 bg-homebase/20 border border-homebase rounded-xl text-left">
                                        <p className="text-sm font-bold text-white">Technician</p>
                                        <p className="text-[10px] text-gray-400">Can view schedule & complete jobs.</p>
                                    </button>
                                    <button className="p-3 bg-glass-200 border border-glass-border rounded-xl text-left opacity-60">
                                        <p className="text-sm font-bold text-white">Admin</p>
                                        <p className="text-[10px] text-gray-400">Full access to billing & settings.</p>
                                    </button>
                                </div>
                            </div>
                            
                            <GlassButton onClick={() => setInviteStep(2)} className="w-full mt-4">Send Invite</GlassButton>
                        </div>
                    ) : (
                        <div className="text-center py-8">
                            <div className="w-16 h-16 bg-homebase/20 rounded-full flex items-center justify-center mx-auto mb-4">
                                <CheckCircle size={32} className="text-homebase" />
                            </div>
                            <h3 className="text-xl font-bold text-white mb-2">Invite Sent!</h3>
                            <p className="text-gray-400 text-sm mb-6">They will receive a link to join your team shortly.</p>
                            <GlassButton onClick={() => { setIsInviteOpen(false); setInviteStep(1); }} variant="secondary">Done</GlassButton>
                        </div>
                    )}
                </div>
            </GlassSheet>
        </AnimatePresence>
    );
}