import React, { useState } from 'react';
import { GlassHeader, GlassCard, GlassButton, GlassSheet, GlassInput, StatusChip } from '../components/LiquidComponents';
import { 
    ArrowLeft, Sparkles, MessageCircle, Plus, ChevronDown, ChevronUp, 
    FileText, HelpCircle, CheckCircle, Send 
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface SupportProps {
    onBack: () => void;
}

interface Ticket {
    id: string;
    subject: string;
    status: 'open' | 'resolved' | 'pending';
    date: string;
}

export default function Support({ onBack }: SupportProps) {
    const [tickets, setTickets] = useState<Ticket[]>([
        { id: '10234', subject: 'Issue with invoice syncing', status: 'open', date: 'Today' },
        { id: '9821', subject: 'How to change business address', status: 'resolved', date: 'Oct 24' },
    ]);
    const [isCreatingTicket, setIsCreatingTicket] = useState(false);
    const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

    const faqs = [
        { q: "How do I add a new team member?", a: "Go to the Team tab in the More menu and tap the + icon. You can invite them via email or phone." },
        { q: "When does the billing cycle reset?", a: "Billing cycles reset on the day of the month you started your subscription." },
        { q: "Can I export my client list?", a: "Yes! Go to Clients, tap the three dots in the top right, and select 'Export CSV'." },
    ];

    return (
        <div className="pb-24">
            <GlassHeader title="Support" />
            <div className="absolute top-14 left-4 z-50">
                <button onClick={onBack} className="p-2 bg-glass-200 rounded-full backdrop-blur-md">
                    <ArrowLeft size={20} className="text-white" />
                </button>
            </div>

            <div className="px-5 mt-6 space-y-8">
                
                {/* AI Instant Help */}
                <section>
                    <GlassCard className="p-0 overflow-hidden border-homebase/30 relative">
                        <div className="absolute inset-0 bg-gradient-to-r from-homebase/10 to-transparent" />
                        <div className="p-5 relative z-10">
                            <div className="flex items-center gap-2 mb-3">
                                <div className="p-2 bg-homebase rounded-lg">
                                    <Sparkles size={20} className="text-white" />
                                </div>
                                <h3 className="text-lg font-bold text-white">Need instant help?</h3>
                            </div>
                            <p className="text-sm text-gray-300 mb-4 leading-relaxed">
                                Our AI support agent can answer questions, guide you through features, or troubleshoot issues instantly.
                            </p>
                            <GlassButton icon={MessageCircle} className="w-full justify-center">
                                Chat with Support AI
                            </GlassButton>
                        </div>
                    </GlassCard>
                </section>

                {/* My Tickets */}
                <section>
                    <div className="flex justify-between items-end mb-3 px-1">
                        <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider">My Tickets</h3>
                        <button 
                            onClick={() => setIsCreatingTicket(true)}
                            className="text-xs font-bold text-homebase flex items-center"
                        >
                            <Plus size={14} className="mr-1" /> New Ticket
                        </button>
                    </div>
                    <div className="space-y-3">
                        {tickets.map(ticket => (
                            <GlassCard key={ticket.id} className="p-4 flex justify-between items-center group active:scale-[0.99] transition-transform">
                                <div>
                                    <div className="flex items-center gap-2 mb-1">
                                        <span className="text-[10px] text-gray-500 font-mono">#{ticket.id}</span>
                                        <span className="text-[10px] text-gray-400">• {ticket.date}</span>
                                    </div>
                                    <h4 className="text-sm font-bold text-white group-hover:text-homebase transition-colors">{ticket.subject}</h4>
                                </div>
                                <div className={`px-2.5 py-1 rounded-lg border text-[10px] font-bold uppercase tracking-wider ${
                                    ticket.status === 'open' ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :
                                    ticket.status === 'resolved' ? 'bg-green-500/20 text-green-400 border-green-500/30' :
                                    'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                                }`}>
                                    {ticket.status}
                                </div>
                            </GlassCard>
                        ))}
                    </div>
                </section>

                {/* FAQ */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 px-1">Common Questions</h3>
                    <div className="space-y-2">
                        {faqs.map((faq, i) => (
                            <GlassCard key={i} className="p-0 overflow-hidden">
                                <button 
                                    onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
                                    className="w-full flex justify-between items-center p-4 text-left"
                                >
                                    <span className="text-sm font-medium text-white pr-4">{faq.q}</span>
                                    {expandedFaq === i ? <ChevronUp size={16} className="text-gray-400" /> : <ChevronDown size={16} className="text-gray-400" />}
                                </button>
                                <AnimatePresence>
                                    {expandedFaq === i && (
                                        <motion.div 
                                            initial={{ height: 0, opacity: 0 }}
                                            animate={{ height: 'auto', opacity: 1 }}
                                            exit={{ height: 0, opacity: 0 }}
                                            className="px-4 pb-4"
                                        >
                                            <p className="text-xs text-gray-400 leading-relaxed border-t border-white/5 pt-2">
                                                {faq.a}
                                            </p>
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </GlassCard>
                        ))}
                    </div>
                </section>

                {/* Contact Footer */}
                <div className="pt-4 pb-8 text-center">
                    <p className="text-xs text-gray-500">
                        Still need help? Email us at <span className="text-homebase font-bold">support@homebase.co</span>
                    </p>
                </div>
            </div>

            {/* Create Ticket Sheet */}
            <GlassSheet isOpen={isCreatingTicket} onClose={() => setIsCreatingTicket(false)} title="New Support Ticket">
                <div className="pb-6 space-y-4">
                    <GlassInput icon={FileText} placeholder="Subject (e.g. Billing Issue)" />
                    
                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase mb-2 block ml-1">Priority</label>
                        <div className="flex gap-2">
                            {['Low', 'Medium', 'High'].map(p => (
                                <button key={p} className="flex-1 py-2 bg-glass-200 border border-glass-border rounded-xl text-xs font-bold text-gray-300 hover:bg-glass-300 focus:bg-homebase/20 focus:border-homebase focus:text-white transition-all">
                                    {p}
                                </button>
                            ))}
                        </div>
                    </div>

                    <div>
                        <label className="text-xs font-bold text-gray-500 uppercase mb-2 block ml-1">Description</label>
                        <textarea 
                            className="w-full h-32 bg-glass-200 border border-glass-border rounded-xl p-4 text-white placeholder-gray-500 outline-none focus:border-homebase/50 transition-colors resize-none text-sm"
                            placeholder="Describe your issue in detail..."
                        />
                    </div>

                    <GlassButton 
                        onClick={() => {
                            setTickets([{ id: '10235', subject: 'New Ticket', status: 'open', date: 'Just now' }, ...tickets]);
                            setIsCreatingTicket(false);
                        }} 
                        className="w-full mt-4"
                        icon={Send}
                    >
                        Submit Ticket
                    </GlassButton>
                </div>
            </GlassSheet>
        </div>
    );
}