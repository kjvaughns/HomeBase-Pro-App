
import React, { useState, useEffect } from 'react';
import { GlassHeader, SegmentedControl, GlassCard, GlassSheet, GlassButton, StatusChip, GlassInput } from '../components/LiquidComponents';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Clock, MapPin, ChevronLeft, ChevronRight, Calendar as CalendarIcon, 
  User, CheckCircle, Navigation, MessageCircle, FileText, Star,
  DollarSign
} from 'lucide-react';
import { Job, Service } from '../types';

// --- HELPERS ---
const isSameDay = (d1: Date, d2: Date) => 
  d1.getFullYear() === d2.getFullYear() && 
  d1.getMonth() === d2.getMonth() && 
  d1.getDate() === d2.getDate();

const getWeekDays = (centerDate: Date) => {
  const start = new Date(centerDate);
  start.setDate(centerDate.getDate() - centerDate.getDay()); // Start on Sunday
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return d;
  });
};

const getMonthDays = (date: Date) => {
  const year = date.getFullYear();
  const month = date.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startDayOffset = firstDay.getDay(); 
  
  const days = [];
  for (let i = 0; i < startDayOffset; i++) days.push(null);
  for (let i = 1; i <= daysInMonth; i++) days.push(new Date(year, month, i));
  return days;
};

const today = new Date();
const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
const yesterday = new Date(today); yesterday.setDate(today.getDate() - 1);

const mockJobs: Job[] = [
  { 
    id: '1', 
    clientName: 'Sarah Miller', 
    clientAvatar: 'https://picsum.photos/100/100',
    service: 'Deep Clean', 
    time: '09:00 AM', 
    date: today, 
    duration: 90, 
    status: 'in-progress', 
    price: 180,
    address: '123 Pine St, San Francisco, CA',
    notes: 'Gate code: 1234. Watch out for the cat.',
    lineItems: [{ name: 'Deep Clean', price: 180 }]
  },
  { 
    id: '2', 
    clientName: 'TechStart Office', 
    clientAvatar: 'https://picsum.photos/101/101',
    service: 'Maintenance', 
    time: '11:30 AM', 
    date: today, 
    duration: 60, 
    status: 'scheduled', 
    price: 250,
    address: '400 Market St, Suite 200',
    lineItems: [{ name: 'Office Standard', price: 250 }]
  },
  { 
    id: '3', 
    clientName: 'James Wilson', 
    clientAvatar: 'https://picsum.photos/102/102',
    service: 'Move-out Clean', 
    time: '02:00 PM', 
    date: tomorrow, 
    duration: 120, 
    status: 'scheduled', 
    price: 320,
    address: '880 Mission St',
    lineItems: [{ name: 'Move-out Clean', price: 300 }, { name: 'Oven Clean', price: 20 }]
  },
   { 
    id: '4', 
    clientName: 'Emily Davis', 
    clientAvatar: 'https://picsum.photos/103/103',
    service: 'Weekly Clean', 
    time: '10:00 AM', 
    date: yesterday, 
    duration: 120, 
    status: 'completed', 
    price: 150,
    address: '500 4th St',
    lineItems: [{ name: 'Weekly Clean', price: 150 }]
  },
];

const availableServices: Service[] = [
    { id: 's1', name: 'Standard Clean', price: 120, duration: 60, isActive: true, category: 'Cleaning' },
    { id: 's2', name: 'Deep Clean', price: 180, duration: 90, isActive: true, category: 'Cleaning' },
    { id: 's3', name: 'Move-out Clean', price: 300, duration: 120, isActive: true, category: 'Cleaning' },
];

const EmptyState = ({ date }: { date?: Date }) => (
  <div className="flex flex-col items-center justify-center py-12 opacity-60">
    <div className="bg-gray-100 dark:bg-glass-200 p-4 rounded-full mb-3">
      <CalendarIcon size={24} className="text-gray-400" />
    </div>
    <h3 className="text-sm font-bold text-gray-900 dark:text-white">No jobs scheduled</h3>
    <p className="text-xs text-gray-400 mt-1">
        {date ? date.toLocaleDateString() : 'Enjoy your time off!'}
    </p>
  </div>
);

const JobCard: React.FC<{ job: Job, onClick: () => void }> = ({ job, onClick }) => (
    <motion.div
        layout
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
    >
        <GlassCard onClick={onClick} className="mb-3 p-0 group active:scale-[0.98] transition-all">
            <div className="p-4 flex flex-row items-start gap-4">
                <div className="flex flex-col items-center min-w-[3.5rem]">
                    <span className="text-sm font-bold text-gray-900 dark:text-white">{job.time.split(' ')[0]}</span>
                    <span className="text-[10px] font-medium text-gray-500 uppercase">{job.time.split(' ')[1]}</span>
                    <div className="h-full w-0.5 bg-gray-200 dark:bg-white/5 mt-2 rounded-full min-h-[1.5rem]" />
                </div>
                
                <div className="flex-1 pb-1">
                    <div className="flex justify-between items-start mb-1">
                        <h4 className="text-base font-bold text-gray-900 dark:text-white">{job.clientName}</h4>
                        <StatusChip status={job.status} />
                    </div>
                    <p className="text-sm text-homebase font-medium mb-1">{job.service}</p>
                    <div className="flex items-center text-xs text-gray-400 dark:text-gray-500">
                        <MapPin size={10} className="mr-1" />
                        <span className="truncate max-w-[150px]">{job.address}</span>
                    </div>
                </div>
            </div>
            
            <div className="flex border-t border-gray-100 dark:border-white/5 divide-x divide-gray-100 dark:divide-white/5">
                <button className="flex-1 py-3 flex items-center justify-center text-xs font-medium text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors">
                    <Navigation size={14} className="mr-1.5" /> Route
                </button>
                <button className="flex-1 py-3 flex items-center justify-center text-xs font-medium text-gray-500 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-white/5 transition-colors">
                    <CheckCircle size={14} className="mr-1.5" /> Complete
                </button>
            </div>
        </GlassCard>
    </motion.div>
);

const DayViewBlock: React.FC<{ job: Job, onClick: () => void }> = ({ job, onClick }) => {
    let top = 0;
    const hour = parseInt(job.time); 
    if (job.time.includes('AM')) top = (hour === 12 ? 0 : hour) * 60;
    else top = (hour === 12 ? 12 : hour + 12) * 60;
    
    top = (top - 540); 
    if(top < 0) top = 0; 

    return (
        <motion.div
            onClick={onClick}
            className="absolute left-14 right-4 rounded-xl bg-homebase/20 border-l-4 border-homebase backdrop-blur-md p-3 cursor-pointer hover:brightness-110 active:scale-[0.98] transition-all overflow-hidden"
            style={{ top: `${top}px`, height: '80px' }}
        >
             <p className="text-xs font-bold text-white mb-0.5">{job.service}</p>
             <p className="text-[10px] text-gray-100">{job.clientName}</p>
        </motion.div>
    )
}

interface ScheduleProps {
  isCreatingJob: boolean;
  setIsCreatingJob: (val: boolean) => void;
}

export default function Schedule({ isCreatingJob, setIsCreatingJob }: ScheduleProps) {
  const [view, setView] = useState('list');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);
  
  const [createStep, setCreateStep] = useState(1);
  const [newJobData, setNewJobData] = useState<Partial<Job>>({});

  useEffect(() => {
    if (isCreatingJob) setCreateStep(1);
  }, [isCreatingJob]);

  const handleNext = () => {
    const next = new Date(selectedDate);
    if (view === 'month') next.setMonth(selectedDate.getMonth() + 1);
    else if (view === 'week') next.setDate(selectedDate.getDate() + 7);
    else next.setDate(selectedDate.getDate() + 1);
    setSelectedDate(next);
  };

  const handlePrev = () => {
    const prev = new Date(selectedDate);
    if (view === 'month') prev.setMonth(selectedDate.getMonth() - 1);
    else if (view === 'week') prev.setDate(selectedDate.getDate() - 7);
    else prev.setDate(selectedDate.getDate() - 1);
    setSelectedDate(prev);
  };
  
  const getHeaderDate = () => {
      if (view === 'month') return selectedDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      if (view === 'week') {
          const weekStart = new Date(selectedDate);
          weekStart.setDate(selectedDate.getDate() - selectedDate.getDay());
          const weekEnd = new Date(weekStart);
          weekEnd.setDate(weekStart.getDate() + 6);
          if (weekStart.getMonth() === weekEnd.getMonth()) {
               return `${weekStart.toLocaleDateString('en-US', { month: 'short' })} ${weekStart.getDate()} - ${weekEnd.getDate()}`;
          }
          return `${weekStart.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${weekEnd.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}`;
      }
      return selectedDate.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  }

  const todaysJobs = mockJobs.filter(j => isSameDay(j.date, selectedDate));

  const renderCreateStep = () => {
      switch(createStep) {
          case 1:
            return (
                <div className="space-y-4">
                     <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Who is this job for?</h3>
                     <div className="flex gap-2 mb-4">
                         <GlassButton variant="secondary" className="flex-1 text-xs">Existing Client</GlassButton>
                         <GlassButton variant="primary" className="flex-1 text-xs">New Client</GlassButton>
                     </div>
                     <GlassInput icon={User} placeholder="Client Name" />
                     <GlassInput icon={MapPin} placeholder="Service Address" />
                     <GlassInput icon={MessageCircle} placeholder="Phone Number (Optional)" />
                </div>
            );
          case 2:
             return (
                 <div className="space-y-4">
                     <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Select Services</h3>
                     <div className="grid grid-cols-1 gap-3">
                         {availableServices.map(svc => (
                             <GlassCard key={svc.id} className="p-3 flex items-center justify-between cursor-pointer active:bg-homebase/10" onClick={() => setNewJobData({...newJobData, service: svc.name, price: svc.price})}>
                                 <div className="flex items-center gap-3">
                                     <div className="p-2 bg-gray-100 dark:bg-glass-200 rounded-lg"><Star size={16} className="text-homebase"/></div>
                                     <div>
                                         <p className="text-sm font-bold text-gray-900 dark:text-white">{svc.name}</p>
                                         <p className="text-xs text-gray-500 dark:text-gray-400">{svc.duration} mins</p>
                                     </div>
                                 </div>
                                 <span className="text-sm font-medium text-gray-900 dark:text-white">${svc.price}</span>
                             </GlassCard>
                         ))}
                         <button className="text-sm text-homebase font-medium py-2">+ Add Custom Service</button>
                     </div>
                 </div>
             );
           case 3:
             return (
                 <div className="space-y-4">
                     <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">When is it?</h3>
                     <GlassCard className="p-4">
                         <div className="flex justify-between items-center mb-4">
                             <span className="text-sm text-gray-500 dark:text-gray-400">Date</span>
                             <span className="text-sm text-gray-900 dark:text-white font-bold">{selectedDate.toLocaleDateString()}</span>
                         </div>
                         <div className="flex justify-between items-center mb-4">
                             <span className="text-sm text-gray-500 dark:text-gray-400">Time</span>
                             <span className="text-sm text-gray-900 dark:text-white font-bold">09:00 AM</span>
                         </div>
                         <div className="flex justify-between items-center">
                             <span className="text-sm text-gray-500 dark:text-gray-400">Duration</span>
                             <span className="text-sm text-gray-900 dark:text-white font-bold">1h 30m</span>
                         </div>
                     </GlassCard>
                     <div className="flex items-center justify-between px-2">
                         <span className="text-sm text-gray-500 dark:text-gray-400">Block this time on schedule</span>
                         <div className="w-10 h-6 bg-homebase rounded-full relative">
                             <div className="absolute right-1 top-1 h-4 w-4 bg-white rounded-full shadow-sm" />
                         </div>
                     </div>
                 </div>
             );
           case 4:
             return (
                 <div className="space-y-4">
                     <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">Final Details</h3>
                     <GlassInput icon={DollarSign} placeholder="Price" value={newJobData.price ? `$${newJobData.price}` : ''} />
                     <GlassInput icon={FileText} placeholder="Notes for this job..." />
                 </div>
             );
           default: return null;
      }
  }

  return (
    <div className="h-full flex flex-col pb-24 relative">
      <GlassHeader 
        title="Schedule" 
        rightAction={
          <div className="flex items-center space-x-2 bg-gray-100 dark:bg-glass-200 rounded-lg p-1">
             <button onClick={handlePrev} className="p-1 hover:bg-gray-200 dark:hover:bg-white/10 rounded"><ChevronLeft size={16} className="text-gray-400" /></button>
             <span className="text-xs font-semibold text-gray-900 dark:text-white min-w-[100px] text-center">{getHeaderDate()}</span>
             <button onClick={handleNext} className="p-1 hover:bg-gray-200 dark:hover:bg-white/10 rounded"><ChevronRight size={16} className="text-gray-400" /></button>
          </div>
        } 
      />
      
      <div className="px-5 mt-4 z-20">
        <SegmentedControl 
          options={['list', 'day', 'week', 'month']} 
          selected={view} 
          onChange={setView} 
        />
      </div>

      <div className="flex-1 overflow-y-auto mt-4 px-5 relative">
        <AnimatePresence mode="wait">
          {view === 'list' && (
             <motion.div key="list" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-2 pb-32">
                 {todaysJobs.length > 0 ? (
                    <>
                        <h3 className="text-xs font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider mb-2">Jobs for {selectedDate.toLocaleDateString()}</h3>
                        {todaysJobs.map(job => (
                            <JobCard key={job.id} job={job} onClick={() => setSelectedJob(job)} />
                        ))}
                    </>
                 ) : (
                    <EmptyState date={selectedDate} />
                 )}
             </motion.div>
          )}

          {view === 'day' && (
              <motion.div key="day" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="relative pb-32 min-h-[600px]">
                  {[9,10,11,12,13,14,15,16,17].map((hour) => (
                      <div key={hour} className="flex items-start h-[60px] border-t border-gray-100 dark:border-white/5 relative">
                          <span className="w-12 text-[10px] text-gray-400 dark:text-gray-500 pt-1 font-mono text-right pr-2">
                              {hour > 12 ? hour - 12 : hour} {hour >= 12 ? 'PM' : 'AM'}
                          </span>
                      </div>
                  ))}
                  <div className="absolute top-[140px] left-12 right-0 h-px bg-red-500 z-10">
                      <div className="absolute -left-1 -top-1 h-2 w-2 rounded-full bg-red-500" />
                  </div>
                  {todaysJobs.map(job => (
                      <DayViewBlock key={job.id} job={job} onClick={() => setSelectedJob(job)} />
                  ))}
                  {todaysJobs.length === 0 && <div className="absolute top-20 left-20 text-xs text-gray-500">No jobs today</div>}
              </motion.div>
          )}

          {view === 'week' && (
              <motion.div key="week" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col h-full">
                   <div className="flex justify-between items-center mb-6 bg-gray-50 dark:bg-glass-100 p-2 rounded-2xl border border-gray-200 dark:border-glass-border">
                       {getWeekDays(selectedDate).map((date, i) => {
                           const isSelected = isSameDay(date, selectedDate);
                           return (
                               <button 
                                key={i} 
                                onClick={() => setSelectedDate(date)}
                                className={`flex flex-col items-center justify-center h-14 w-10 rounded-xl transition-all duration-200 ${
                                    isSelected 
                                    ? 'bg-homebase text-white border-2 border-white dark:border-white shadow-[0_0_15px_rgba(15,175,110,0.5)] scale-110 z-10' 
                                    : 'text-gray-400 hover:bg-gray-200 dark:hover:bg-white/5'
                                }`}
                               >
                                   <span className={`text-[10px] font-medium uppercase mb-0.5 ${isSelected ? 'text-white' : 'text-gray-400'}`}>{date.toLocaleDateString('en-US', { weekday: 'narrow' })}</span>
                                   <span className={`text-sm font-bold ${isSelected ? 'text-white' : 'text-gray-700 dark:text-gray-200'}`}>{date.getDate()}</span>
                                   {!isSelected && mockJobs.some(j => isSameDay(j.date, date)) && (
                                       <div className="h-1 w-1 rounded-full bg-homebase mt-1" />
                                   )}
                               </button>
                           )
                       })}
                   </div>

                   <div className="space-y-2 pb-32">
                        {todaysJobs.length > 0 ? (
                            todaysJobs.map(job => (
                                <JobCard key={job.id} job={job} onClick={() => setSelectedJob(job)} />
                            ))
                        ) : (
                            <EmptyState date={selectedDate} />
                        )}
                   </div>
              </motion.div>
          )}

          {view === 'month' && (
              <motion.div key="month" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pb-32">
                  <GlassCard className="p-4">
                      <div className="grid grid-cols-7 mb-4">
                          {['S','M','T','W','T','F','S'].map(d => (
                              <div key={d} className="text-center text-xs font-bold text-gray-500 py-2">{d}</div>
                          ))}
                      </div>
                      <div className="grid grid-cols-7 gap-y-4">
                          {getMonthDays(selectedDate).map((date, i) => {
                              if (!date) return <div key={i} />;
                              const isSelected = isSameDay(date, selectedDate);
                              const hasJobs = mockJobs.some(j => isSameDay(j.date, date));
                              return (
                                  <div key={i} className="flex flex-col items-center relative">
                                      <button 
                                        onClick={() => { setSelectedDate(date); setView('list'); }}
                                        className={`h-9 w-9 flex items-center justify-center rounded-full text-sm font-medium transition-all ${
                                            isSelected ? 'bg-homebase text-white font-bold' : 'text-gray-700 dark:text-white hover:bg-gray-100 dark:hover:bg-white/10'
                                        }`}
                                      >
                                          {date.getDate()}
                                      </button>
                                      {hasJobs && !isSelected && (
                                          <div className="absolute bottom-[-4px] h-1.5 w-1.5 rounded-full bg-homebase" />
                                      )}
                                  </div>
                              )
                          })}
                      </div>
                  </GlassCard>
                  
                  <div className="mt-6">
                       <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 px-2">Summary</h3>
                       <GlassCard className="p-4 flex items-center justify-between">
                           <div>
                               <p className="text-sm text-gray-500 dark:text-gray-400">Total Jobs this Month</p>
                               <p className="text-xl font-bold text-gray-900 dark:text-white">42</p>
                           </div>
                           <div className="h-10 w-10 bg-homebase/20 rounded-full flex items-center justify-center text-homebase">
                               <CalendarIcon size={20} />
                           </div>
                       </GlassCard>
                  </div>
              </motion.div>
          )}
        </AnimatePresence>
      </div>

      <GlassSheet isOpen={!!selectedJob} onClose={() => setSelectedJob(null)} title="Job Details">
         {selectedJob && (
             <div className="space-y-6">
                 <div className="flex items-center justify-between">
                     <div className="flex items-center space-x-3">
                         <img src={selectedJob.clientAvatar} className="w-12 h-12 rounded-full border border-gray-200 dark:border-white/10" />
                         <div>
                             <h4 className="text-lg font-bold text-gray-900 dark:text-white">{selectedJob.clientName}</h4>
                             <p className="text-xs text-gray-500 dark:text-gray-400">Client since 2023</p>
                         </div>
                     </div>
                     <StatusChip status={selectedJob.status} />
                 </div>

                 <div className="grid grid-cols-4 gap-2">
                     <button className="flex flex-col items-center justify-center p-3 rounded-xl bg-gray-100 dark:bg-glass-200 active:bg-gray-200 dark:active:bg-glass-300 transition-colors">
                         <Navigation size={20} className="text-blue-500 mb-1" />
                         <span className="text-[10px] text-gray-500 dark:text-gray-300">Go</span>
                     </button>
                     <button className="flex flex-col items-center justify-center p-3 rounded-xl bg-gray-100 dark:bg-glass-200 active:bg-gray-200 dark:active:bg-glass-300 transition-colors">
                         <MessageCircle size={20} className="text-homebase mb-1" />
                         <span className="text-[10px] text-gray-500 dark:text-gray-300">Chat</span>
                     </button>
                     <button className="flex flex-col items-center justify-center p-3 rounded-xl bg-gray-100 dark:bg-glass-200 active:bg-gray-200 dark:active:bg-glass-300 transition-colors">
                         <FileText size={20} className="text-purple-600 mb-1" />
                         <span className="text-[10px] text-gray-500 dark:text-gray-300">Invoice</span>
                     </button>
                     <button className="flex flex-col items-center justify-center p-3 rounded-xl bg-gray-100 dark:bg-glass-200 active:bg-gray-200 dark:active:bg-glass-300 transition-colors">
                         <CheckCircle size={20} className="text-green-600 mb-1" />
                         <span className="text-[10px] text-gray-500 dark:text-gray-300">Done</span>
                     </button>
                 </div>

                 <div className="space-y-4">
                     <GlassCard className="p-4 space-y-3">
                         <h5 className="text-xs font-bold text-gray-500 uppercase">Service</h5>
                         <div className="flex justify-between items-center">
                             <span className="text-gray-900 dark:text-white font-medium">{selectedJob.service}</span>
                             <span className="text-homebase font-bold">${selectedJob.price}</span>
                         </div>
                         <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                             <Clock size={14} className="mr-2 text-gray-400" />
                             {selectedJob.time} ({selectedJob.duration} mins)
                         </div>
                     </GlassCard>

                     <GlassCard className="p-4 space-y-3">
                         <h5 className="text-xs font-bold text-gray-500 uppercase">Location</h5>
                         <div className="flex items-start">
                             <MapPin size={16} className="mt-0.5 mr-2 text-gray-400" />
                             <p className="text-sm text-gray-900 dark:text-white leading-relaxed">{selectedJob.address}</p>
                         </div>
                     </GlassCard>

                     {selectedJob.notes && (
                         <GlassCard className="p-4 space-y-2">
                             <h5 className="text-xs font-bold text-gray-500 uppercase">Notes</h5>
                             <p className="text-sm text-gray-600 dark:text-gray-300 italic">"{selectedJob.notes}"</p>
                         </GlassCard>
                     )}
                 </div>
             </div>
         )}
      </GlassSheet>

      <GlassSheet isOpen={isCreatingJob} onClose={() => setIsCreatingJob(false)} title="New Job">
          <div className="pb-4">
             <div className="flex space-x-2 mb-6">
                 {[1,2,3,4].map(step => (
                     <div key={step} className={`h-1 flex-1 rounded-full transition-colors duration-300 ${step <= createStep ? 'bg-homebase' : 'bg-gray-200 dark:bg-white/10'}`} />
                 ))}
             </div>
             
             <motion.div
                key={createStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
             >
                 {renderCreateStep()}
             </motion.div>

             <div className="flex items-center space-x-3 mt-8 pt-4 border-t border-gray-100 dark:border-white/5">
                 {createStep > 1 && (
                     <GlassButton onClick={() => setCreateStep(s => s-1)} variant="secondary" className="flex-1">Back</GlassButton>
                 )}
                 <GlassButton 
                    onClick={() => {
                        if(createStep < 4) setCreateStep(s => s+1);
                        else setIsCreatingJob(false); 
                    }} 
                    variant="primary" 
                    className="flex-[2]"
                 >
                     {createStep === 4 ? 'Add to Schedule' : 'Next'}
                 </GlassButton>
             </div>
          </div>
      </GlassSheet>
    </div>
  );
}
