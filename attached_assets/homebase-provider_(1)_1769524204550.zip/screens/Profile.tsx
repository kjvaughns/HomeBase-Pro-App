import React from 'react';
import { GlassHeader, GlassCard, GlassInput, GlassButton } from '../components/LiquidComponents';
import { Image, MapPin, Globe, Camera, Briefcase, Star, ChevronRight, Eye } from 'lucide-react';

interface ProfileProps {
    onPreviewBooking?: () => void;
}

const MenuItem = ({ icon: Icon, label, value }: { icon: any, label: string, value?: string }) => (
  <GlassCard className="p-4 flex items-center justify-between active:bg-glass-200 transition-colors cursor-pointer mb-3">
    <div className="flex items-center space-x-3">
      <div className="p-2 rounded-lg bg-glass-200">
         <Icon size={18} className="text-homebase" />
      </div>
      <span className="text-sm font-medium text-white">{label}</span>
    </div>
    <div className="flex items-center space-x-2">
      {value && <span className="text-xs text-gray-400">{value}</span>}
      <ChevronRight size={16} className="text-gray-500" />
    </div>
  </GlassCard>
);

export default function Profile({ onPreviewBooking }: ProfileProps) {
  return (
    <div className="pb-24">
      <GlassHeader title="Business Profile" subtitle="Public Preview" />

      <div className="px-5 mt-6">
        {/* Profile Header Image */}
        <div className="relative h-48 rounded-2xl overflow-hidden mb-8 border border-glass-border">
             <img src="https://picsum.photos/800/400" alt="Cover" className="w-full h-full object-cover opacity-60" />
             <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
             
             <div className="absolute bottom-4 left-4 flex items-end space-x-4">
                 <div className="h-20 w-20 rounded-xl bg-black border-2 border-homebase overflow-hidden relative group">
                     <img src="https://picsum.photos/200/200" className="h-full w-full object-cover" />
                     <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Camera size={20} className="text-white" />
                     </div>
                 </div>
                 <div className="mb-2">
                     <h2 className="text-xl font-bold text-white">Clean & Co. LLC</h2>
                     <p className="text-xs text-homebase flex items-center">
                        <Star size={10} className="fill-homebase mr-1" /> 4.9 (128 Reviews)
                     </p>
                 </div>
             </div>
             
             <button className="absolute top-4 right-4 p-2 bg-black/40 backdrop-blur-md rounded-full border border-white/10">
                 <Camera size={18} className="text-white" />
             </button>
        </div>

        {/* Form Sections */}
        <div className="space-y-6">
            <section>
                <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 px-1">Details</h3>
                <GlassInput icon={Briefcase} placeholder="Business Name" value="Clean & Co. LLC" />
                <div className="h-3" />
                <GlassInput icon={Globe} placeholder="Website Slug" value="homebase.co/clean-co" />
            </section>

            <section>
                 <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 px-1">Configuration</h3>
                 <MenuItem icon={MapPin} label="Service Area" value="San Francisco, CA" />
                 <MenuItem icon={Image} label="Portfolio" value="12 Photos" />
                 <MenuItem icon={Star} label="Reviews" />
            </section>

            <div className="pt-6 space-y-4">
                <GlassButton className="w-full justify-center">Save Changes</GlassButton>
                
                {onPreviewBooking && (
                    <button 
                        onClick={onPreviewBooking}
                        className="w-full py-3 rounded-xl border border-glass-border bg-glass-100 text-white font-medium text-sm flex items-center justify-center hover:bg-glass-200 transition-colors"
                    >
                        <Eye size={16} className="mr-2 text-homebase" />
                        Preview Booking Page
                    </button>
                )}
            </div>
        </div>
      </div>
    </div>
  );
}