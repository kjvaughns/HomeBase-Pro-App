import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Star, MapPin, CheckCircle, Send, ArrowRight, Sparkles, User, Calendar, MessageCircle, ArrowLeft, Phone, Mail, Clock } from 'lucide-react';
import { GlassCard, GlassButton } from '../components/LiquidComponents';

interface BookingPreviewProps {
    onClose: () => void;
}

interface Message {
    id: string;
    text: React.ReactNode;
    sender: 'user' | 'ai';
    type?: 'text' | 'date-picker' | 'summary';
}

export default function BookingPreview({ onClose }: BookingPreviewProps) {
    const [mode, setMode] = useState<'landing' | 'chat' | 'success'>('landing');
    const [messages, setMessages] = useState<Message[]>([]);
    const [inputValue, setInputValue] = useState('');
    const [isTyping, setIsTyping] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);
    const [bookingData, setBookingData] = useState({
        service: 'General Cleaning',
        date: '',
        details: ''
    });

    // Auto-scroll chat
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [messages, isTyping]);

    const startChat = (initialService?: string) => {
        setMode('chat');
        
        let initialText = "Hi! I'm the AI Assistant for Clean & Co. I can help you book a service or get a quote. Tell me, what do you need help with today?";
        
        if (initialService) {
            setBookingData(prev => ({ ...prev, service: initialService }));
            initialText = `Hi! I see you're interested in our **${initialService}**. I can help you get that scheduled. To give you an accurate price, roughly how large is the space (bedrooms/bathrooms)?`;
        }

        setMessages([{
            id: '1',
            sender: 'ai',
            text: initialText,
            type: 'text'
        }]);
    };

    const handleSendMessage = () => {
        if (!inputValue.trim()) return;

        const newUserMsg: Message = { id: Date.now().toString(), text: inputValue, sender: 'user' };
        setMessages(prev => [...prev, newUserMsg]);
        setInputValue('');
        setIsTyping(true);

        // Simple mock AI logic
        setTimeout(() => {
            let responseText: React.ReactNode = "";
            let responseType: Message['type'] = 'text';

            // Very basic state machine for the demo
            if (messages.length === 1) {
                 if (bookingData.service !== 'General Cleaning') {
                     // If we already have a service, jump to date
                     responseText = "Thanks! Based on that size, it should take about 2-3 hours. When would you like us to come by?";
                     responseType = 'date-picker';
                 } else {
                     setBookingData(prev => ({ ...prev, details: inputValue }));
                     responseText = "I can definitely help with that. To give you an accurate price, roughly how large is the space (bedrooms/bathrooms) and do you have any pets?";
                 }
            } else if (messages.length >= 2 && messages.length < 5) {
                 // Logic to show date picker if not shown yet
                 const hasAskedDate = messages.some(m => m.text?.toString().includes("When would you like"));
                 if (!hasAskedDate) {
                     responseText = "Got it. Based on that, I'd recommend our standard package. When works best for you?";
                     responseType = 'date-picker';
                 } else {
                     responseText = "Perfect. I've compiled a Job Report for the team. Please review the details below to confirm.";
                     responseType = 'summary';
                 }
            } else {
                responseText = "Perfect. I've compiled a Job Report for the team. Please review the details below to confirm.";
                responseType = 'summary';
            }

            setMessages(prev => [...prev, {
                id: (Date.now() + 1).toString(),
                text: responseText,
                sender: 'ai',
                type: responseType
            }]);
            setIsTyping(false);
        }, 1500);
    };

    const handleDateSelect = (date: string) => {
        setBookingData(prev => ({ ...prev, date }));
        setMessages(prev => [...prev, { id: Date.now().toString(), text: `I'm available on ${date}`, sender: 'user' }]);
        setIsTyping(true);
        setTimeout(() => {
             setMessages(prev => [...prev, {
                id: (Date.now() + 1).toString(),
                text: "Great choice. I've compiled everything into a Job Report for the provider. Please confirm below.",
                sender: 'ai',
                type: 'summary'
            }]);
            setIsTyping(false);
        }, 1000);
    }

    const confirmBooking = () => {
        setMode('success');
    };

    return (
        <motion.div 
            initial={{ opacity: 0, y: "100%" }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: "100%" }}
            className="fixed inset-0 z-50 bg-black overflow-hidden flex flex-col"
        >
            {/* Simulation Header */}
            <div className="bg-gray-900 px-4 py-2 flex items-center justify-between border-b border-white/10 z-50 safe-top">
                <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Client View Preview</span>
                <button onClick={onClose} className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white">
                    <X size={16} />
                </button>
            </div>

            <AnimatePresence mode="wait">
                {/* LANDING MODE */}
                {mode === 'landing' && (
                    <motion.div 
                        key="landing"
                        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, x: -50 }}
                        className="flex-1 flex flex-col bg-black relative"
                    >
                        {/* Scrollable Content */}
                        <div className="flex-1 overflow-y-auto pb-32">
                            {/* Hero */}
                            <div className="relative h-64">
                                <img src="https://picsum.photos/800/600" className="w-full h-full object-cover" />
                                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
                                <div className="absolute bottom-6 left-6 right-6">
                                    <div className="flex justify-between items-end">
                                        <div>
                                            <h1 className="text-3xl font-bold text-white mb-2">Clean & Co. LLC</h1>
                                            <div className="flex items-center text-sm text-gray-300">
                                                <Star size={14} className="text-homebase fill-homebase mr-1" />
                                                <span className="font-bold text-white mr-1">4.9</span>
                                                (128 Reviews) • San Francisco, CA
                                            </div>
                                        </div>
                                        <div className="h-14 w-14 rounded-full border-2 border-white overflow-hidden bg-black">
                                            <img src="https://picsum.photos/200/200" className="w-full h-full object-cover" />
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Content */}
                            <div className="px-5 py-6 space-y-8">
                                {/* AI Teaser */}
                                <GlassCard className="p-4 bg-gradient-to-r from-homebase/20 to-glass-100 border-homebase/30 relative overflow-hidden">
                                    <div className="relative z-10 flex items-start gap-4">
                                        <div className="p-3 bg-homebase rounded-full shadow-lg shadow-homebase/20">
                                            <Sparkles size={24} className="text-white" />
                                        </div>
                                        <div className="flex-1">
                                            <h3 className="text-lg font-bold text-white">Not sure what you need?</h3>
                                            <p className="text-sm text-gray-300 mt-1 leading-relaxed">
                                                Chat with our AI Assistant to get a custom quote and book instantly.
                                            </p>
                                            <button onClick={() => startChat()} className="mt-3 text-sm font-bold text-homebase flex items-center">
                                                Start Chat <ArrowRight size={16} className="ml-1" />
                                            </button>
                                        </div>
                                    </div>
                                    <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-homebase/20 blur-3xl rounded-full" />
                                </GlassCard>

                                {/* Services */}
                                <section>
                                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">Popular Services</h3>
                                    <div className="space-y-3">
                                        {[
                                            { name: 'Standard Clean', price: '$120', dur: '60 mins', desc: 'Routine cleaning for upkeep.' },
                                            { name: 'Deep Clean', price: '$180', dur: '2.5 hrs', desc: 'Thorough top-to-bottom clean.' },
                                            { name: 'Move-out Clean', price: '$300', dur: '4 hrs', desc: 'Get your deposit back guaranteed.' }
                                        ].map((s, i) => (
                                            <GlassCard key={i} onClick={() => startChat(s.name)} className="p-4 flex justify-between items-center group active:scale-[0.98] transition-transform cursor-pointer">
                                                <div>
                                                    <h4 className="font-bold text-white">{s.name}</h4>
                                                    <p className="text-xs text-gray-400 mb-1">{s.desc}</p>
                                                    <p className="text-xs text-homebase font-medium">{s.dur}</p>
                                                </div>
                                                <div className="flex items-center gap-3">
                                                    <span className="font-mono text-white text-sm font-bold">{s.price}</span>
                                                    <div className="p-2 bg-glass-200 rounded-full text-homebase group-hover:bg-homebase group-hover:text-white transition-colors">
                                                        <ArrowRight size={16} />
                                                    </div>
                                                </div>
                                            </GlassCard>
                                        ))}
                                    </div>
                                </section>

                                {/* Reviews */}
                                <section>
                                    <div className="flex items-center justify-between mb-4">
                                        <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider">What Locals Say</h3>
                                        <span className="text-xs text-homebase font-bold">View All</span>
                                    </div>
                                    <div className="flex space-x-3 overflow-x-auto pb-4 scrollbar-hide -mx-5 px-5">
                                        {[1, 2, 3].map((_, i) => (
                                            <GlassCard key={i} className="min-w-[260px] p-4 bg-glass-100">
                                                <div className="flex items-center space-x-1 mb-2">
                                                    {[...Array(5)].map((_, j) => (
                                                        <Star key={j} size={12} className="text-homebase fill-homebase" />
                                                    ))}
                                                </div>
                                                <p className="text-sm text-gray-200 leading-relaxed mb-3">
                                                    "Absolutely amazing service. The team was on time, professional, and left my place sparkling."
                                                </p>
                                                <div className="flex items-center space-x-2">
                                                    <div className="h-6 w-6 rounded-full bg-gray-600" />
                                                    <span className="text-xs font-bold text-gray-400">Jessica M.</span>
                                                </div>
                                            </GlassCard>
                                        ))}
                                    </div>
                                </section>

                                {/* Contact Info */}
                                <section>
                                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">Contact & Location</h3>
                                    <GlassCard className="p-0 overflow-hidden">
                                        {/* Fake Map */}
                                        <div className="h-32 bg-gray-800 relative">
                                            <div className="absolute inset-0 opacity-30 bg-[url('https://upload.wikimedia.org/wikipedia/commons/e/ec/San_Francisco_OpenStreetMap.png')] bg-cover bg-center" />
                                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-8 w-8 bg-homebase/30 rounded-full flex items-center justify-center animate-pulse">
                                                 <div className="h-3 w-3 bg-homebase rounded-full ring-2 ring-white" />
                                            </div>
                                        </div>
                                        <div className="p-5 space-y-4">
                                            <div className="flex items-start space-x-3">
                                                <MapPin size={18} className="text-homebase mt-0.5" />
                                                <div>
                                                    <p className="text-sm font-bold text-white">Headquarters</p>
                                                    <p className="text-xs text-gray-400">123 Market Street, San Francisco, CA 94103</p>
                                                </div>
                                            </div>
                                            <div className="flex items-start space-x-3">
                                                <Clock size={18} className="text-homebase mt-0.5" />
                                                <div>
                                                    <p className="text-sm font-bold text-white">Business Hours</p>
                                                    <p className="text-xs text-gray-400">Mon - Fri: 8:00 AM - 6:00 PM</p>
                                                </div>
                                            </div>
                                            <div className="grid grid-cols-2 gap-3 pt-2">
                                                <GlassButton variant="secondary" className="h-10 text-xs" icon={Phone}>Call</GlassButton>
                                                <GlassButton variant="secondary" className="h-10 text-xs" icon={Mail}>Email</GlassButton>
                                            </div>
                                        </div>
                                    </GlassCard>
                                </section>

                                {/* Portfolio */}
                                <section>
                                    <h3 className="text-sm font-bold text-gray-500 uppercase tracking-wider mb-4">Portfolio</h3>
                                    <div className="grid grid-cols-2 gap-3">
                                        <div className="aspect-square rounded-xl overflow-hidden bg-glass-200 relative group">
                                            <img src="https://picsum.photos/300/300?1" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                        </div>
                                        <div className="aspect-square rounded-xl overflow-hidden bg-glass-200 relative group">
                                            <img src="https://picsum.photos/300/300?2" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                        </div>
                                        <div className="aspect-square rounded-xl overflow-hidden bg-glass-200 relative group">
                                            <img src="https://picsum.photos/300/300?3" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                        </div>
                                        <div className="aspect-square rounded-xl overflow-hidden bg-glass-200 relative group flex items-center justify-center">
                                            <span className="text-xs font-bold text-white">+8 More</span>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>

                        {/* Sticky Bottom Bar - Now truly sticky relative to viewport */}
                        <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/90 backdrop-blur-xl border-t border-white/10 flex justify-between items-center safe-bottom z-20">
                            <div className="flex flex-col">
                                <span className="text-[10px] text-gray-400 uppercase tracking-wide">Ready to start?</span>
                                <span className="text-xs text-white font-medium">Book online or chat with us</span>
                            </div>
                            <GlassButton onClick={() => startChat()} className="pl-6 pr-6 shadow-homebase/20 shadow-lg">
                                Book Now
                            </GlassButton>
                        </div>
                    </motion.div>
                )}

                {/* CHAT MODE */}
                {mode === 'chat' && (
                    <motion.div 
                        key="chat"
                        initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }}
                        className="flex-1 flex flex-col bg-black relative"
                    >
                        {/* Chat Header */}
                        <div className="px-4 py-3 bg-black/80 backdrop-blur-md border-b border-white/5 flex items-center gap-3">
                            <button onClick={() => setMode('landing')} className="p-2 -ml-2 rounded-full hover:bg-white/10 text-gray-400">
                                <ArrowLeft size={20} />
                            </button>
                            <div className="h-8 w-8 rounded-full bg-homebase flex items-center justify-center">
                                <Sparkles size={16} className="text-white" />
                            </div>
                            <div>
                                <h3 className="text-sm font-bold text-white">Clean & Co. AI</h3>
                                <p className="text-[10px] text-green-400 flex items-center gap-1">
                                    <span className="w-1.5 h-1.5 rounded-full bg-green-400" /> Online
                                </p>
                            </div>
                        </div>

                        {/* Messages */}
                        <div className="flex-1 overflow-y-auto p-4 space-y-6" ref={scrollRef}>
                            {messages.map((msg) => (
                                <motion.div 
                                    key={msg.id}
                                    initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                                    className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                                >
                                    <div className={`max-w-[85%] ${msg.sender === 'user' ? 'ml-auto' : ''}`}>
                                        {msg.sender === 'ai' && (
                                            <span className="text-[10px] text-gray-500 mb-1 ml-1 block">Assistant</span>
                                        )}
                                        
                                        <div className={`p-4 rounded-2xl text-sm leading-relaxed ${
                                            msg.sender === 'user' 
                                            ? 'bg-homebase text-white rounded-tr-sm' 
                                            : 'bg-glass-200 border border-white/10 text-gray-100 rounded-tl-sm'
                                        }`}>
                                            {/* Render markdown-ish bold text */}
                                            {typeof msg.text === 'string' ? msg.text.split('**').map((part, i) => i % 2 === 1 ? <strong key={i} className="text-white">{part}</strong> : part) : msg.text}
                                        </div>

                                        {/* Date Picker Component within Chat */}
                                        {msg.type === 'date-picker' && (
                                            <div className="mt-3 bg-glass-100 p-3 rounded-xl border border-white/5">
                                                <p className="text-xs text-gray-400 mb-2 font-bold uppercase">Select a Date</p>
                                                <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                                                    {['Mon 12', 'Tue 13', 'Wed 14'].map((d) => (
                                                        <button 
                                                            key={d}
                                                            onClick={() => handleDateSelect(d)}
                                                            className="px-4 py-2 rounded-lg bg-glass-200 hover:bg-homebase/50 text-white text-xs font-medium border border-white/10 transition-colors whitespace-nowrap"
                                                        >
                                                            {d}
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                        )}

                                        {/* Job Report Summary Card within Chat */}
                                        {msg.type === 'summary' && (
                                            <motion.div 
                                                initial={{ scale: 0.95, opacity: 0 }}
                                                animate={{ scale: 1, opacity: 1 }}
                                                className="mt-4"
                                            >
                                                <GlassCard className="p-0 overflow-hidden border-homebase/30">
                                                    <div className="bg-homebase/20 p-3 border-b border-homebase/20 flex justify-between items-center">
                                                        <div className="flex items-center gap-2">
                                                            <Sparkles size={14} className="text-homebase" />
                                                            <span className="text-xs font-bold text-homebase uppercase">AI Job Report</span>
                                                        </div>
                                                        <span className="text-[10px] text-gray-400">#DRAFT-102</span>
                                                    </div>
                                                    <div className="p-4 space-y-3">
                                                        <div className="flex justify-between">
                                                            <span className="text-xs text-gray-400">Service</span>
                                                            <span className="text-xs font-bold text-white text-right">{bookingData.service}</span>
                                                        </div>
                                                        <div className="flex justify-between">
                                                            <span className="text-xs text-gray-400">Date</span>
                                                            <span className="text-xs font-bold text-white text-right">{bookingData.date || 'TBD'} @ 9:00 AM</span>
                                                        </div>
                                                        <div className="bg-glass-200 p-2 rounded-lg">
                                                            <p className="text-[10px] text-gray-400 mb-1 uppercase">Notes</p>
                                                            <p className="text-xs text-gray-200 italic">"{bookingData.details || 'Requested via AI'}"</p>
                                                        </div>
                                                        <div className="pt-2 border-t border-white/5 flex justify-between items-center">
                                                            <span className="text-sm font-bold text-white">Total Est.</span>
                                                            <span className="text-lg font-bold text-homebase">$180.00</span>
                                                        </div>
                                                    </div>
                                                    <div className="p-2 bg-black/20">
                                                        <GlassButton onClick={confirmBooking} className="w-full h-10 text-sm">
                                                            Confirm & Book
                                                        </GlassButton>
                                                    </div>
                                                </GlassCard>
                                            </motion.div>
                                        )}
                                    </div>
                                </motion.div>
                            ))}
                            
                            {isTyping && (
                                <div className="flex items-center gap-2 ml-2">
                                    <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce" />
                                    <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce delay-100" />
                                    <div className="w-1.5 h-1.5 bg-gray-500 rounded-full animate-bounce delay-200" />
                                </div>
                            )}
                            <div className="h-24" /> {/* Spacer */}
                        </div>

                        {/* Input Area */}
                        <div className="absolute bottom-0 left-0 right-0 p-4 bg-black/80 backdrop-blur-xl border-t border-white/10 safe-bottom">
                            <div className="flex items-center gap-2">
                                <input 
                                    value={inputValue}
                                    onChange={(e) => setInputValue(e.target.value)}
                                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                                    placeholder="Type your message..."
                                    className="flex-1 bg-glass-200 border border-white/10 rounded-full px-4 py-3 text-sm text-white focus:border-homebase/50 outline-none"
                                />
                                <button 
                                    onClick={handleSendMessage}
                                    disabled={!inputValue.trim()}
                                    className="p-3 bg-homebase text-white rounded-full disabled:opacity-50 hover:scale-105 transition-transform"
                                >
                                    <Send size={18} />
                                </button>
                            </div>
                        </div>
                    </motion.div>
                )}

                {/* SUCCESS MODE */}
                {mode === 'success' && (
                    <motion.div 
                        key="success"
                        initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
                        className="flex-1 bg-black flex flex-col items-center justify-center p-8 text-center"
                    >
                        <div className="w-20 h-20 bg-homebase/20 rounded-full flex items-center justify-center mb-6 ring-4 ring-homebase/10">
                            <CheckCircle size={40} className="text-homebase" />
                        </div>
                        <h2 className="text-2xl font-bold text-white mb-2">Booking Confirmed!</h2>
                        <p className="text-gray-400 mb-8 max-w-xs">
                            Clean & Co. has received your request. You'll receive a confirmation text shortly.
                        </p>
                        <GlassCard className="w-full max-w-sm p-4 mb-8 text-left bg-glass-100">
                             <div className="flex items-start gap-3">
                                <div className="p-2 bg-glass-200 rounded-lg">
                                    <Calendar size={18} className="text-white" />
                                </div>
                                <div>
                                    <p className="text-xs text-gray-400">Date & Time</p>
                                    <p className="text-sm font-bold text-white">{bookingData.date} @ 9:00 AM</p>
                                    <p className="text-xs text-homebase mt-1">{bookingData.service}</p>
                                </div>
                             </div>
                        </GlassCard>
                        <button onClick={onClose} className="text-homebase font-bold text-sm">
                            Return to Editor
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>
        </motion.div>
    );
}