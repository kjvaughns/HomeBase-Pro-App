import React, { useState } from 'react';
import { GlassHeader, GlassCard, GlassButton } from '../components/LiquidComponents';
import { 
    ArrowLeft, Bell, CreditCard, Shield, Moon, Globe, 
    ChevronRight, LogOut, Check, Lock, Smartphone, Star
} from 'lucide-react';
import { motion } from 'framer-motion';

interface SettingsProps {
    onBack: () => void;
}

export default function Settings({ onBack }: SettingsProps) {
    const [toggles, setToggles] = useState({
        push: true,
        email: false,
        marketing: false,
        darkMode: true
    });

    const toggle = (key: keyof typeof toggles) => {
        setToggles(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const ToggleSwitch = ({ active, onToggle }: { active: boolean, onToggle: () => void }) => (
        <button 
            onClick={onToggle}
            className={`w-10 h-6 rounded-full relative transition-colors duration-300 ${active ? 'bg-homebase' : 'bg-gray-700'}`}
        >
            <div className={`absolute top-1 left-1 h-4 w-4 bg-white rounded-full shadow-md transition-transform duration-300 ${active ? 'translate-x-4' : ''}`} />
        </button>
    );

    return (
        <div className="pb-24">
            <GlassHeader title="App Settings" />
            <div className="absolute top-14 left-4 z-50">
                <button onClick={onBack} className="p-2 bg-glass-200 rounded-full backdrop-blur-md">
                    <ArrowLeft size={20} className="text-white" />
                </button>
            </div>

            <div className="px-5 mt-6 space-y-8">
                
                {/* Billing Section */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 px-1">Subscription</h3>
                    <GlassCard className="p-5 relative overflow-hidden group">
                        <div className="absolute top-0 right-0 bg-homebase text-[10px] font-bold text-black px-3 py-1 rounded-bl-xl z-10">
                            PRO PLAN
                        </div>
                        <div className="relative z-10">
                             <div className="flex items-center gap-3 mb-4">
                                 <div className="p-3 bg-homebase/20 rounded-xl">
                                     <CreditCard size={24} className="text-homebase" />
                                 </div>
                                 <div>
                                     <h4 className="text-lg font-bold text-white">Monthly Plan</h4>
                                     <p className="text-xs text-gray-400">Renews on Nov 14, 2023</p>
                                 </div>
                             </div>
                             <div className="flex items-center justify-between border-t border-white/5 pt-4">
                                 <div className="flex items-center gap-2">
                                     <span className="text-2xl font-bold text-white">$49</span>
                                     <span className="text-sm text-gray-400">/mo</span>
                                 </div>
                                 <button className="text-sm font-bold text-homebase hover:text-white transition-colors">
                                     Manage Billing
                                 </button>
                             </div>
                        </div>
                        <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-homebase/10 rounded-full blur-2xl group-hover:bg-homebase/20 transition-colors" />
                    </GlassCard>
                </section>

                {/* Notifications */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 px-1">Notifications</h3>
                    <GlassCard className="divide-y divide-white/5 p-0">
                        <div className="p-4 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <Smartphone size={18} className="text-gray-400" />
                                <span className="text-sm font-medium text-white">Push Notifications</span>
                            </div>
                            <ToggleSwitch active={toggles.push} onToggle={() => toggle('push')} />
                        </div>
                        <div className="p-4 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <Bell size={18} className="text-gray-400" />
                                <span className="text-sm font-medium text-white">Email Digests</span>
                            </div>
                            <ToggleSwitch active={toggles.email} onToggle={() => toggle('email')} />
                        </div>
                        <div className="p-4 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                                <Star size={18} className="text-gray-400" />
                                <span className="text-sm font-medium text-white">Marketing & Tips</span>
                            </div>
                            <ToggleSwitch active={toggles.marketing} onToggle={() => toggle('marketing')} />
                        </div>
                    </GlassCard>
                </section>

                {/* General & Security */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 px-1">General</h3>
                    <GlassCard className="divide-y divide-white/5 p-0">
                        <div className="p-4 flex items-center justify-between cursor-pointer active:bg-glass-200">
                             <div className="flex items-center gap-3">
                                 <Lock size={18} className="text-gray-400" />
                                 <span className="text-sm font-medium text-white">Security & Password</span>
                             </div>
                             <ChevronRight size={16} className="text-gray-500" />
                        </div>
                        <div className="p-4 flex items-center justify-between">
                             <div className="flex items-center gap-3">
                                 <Moon size={18} className="text-gray-400" />
                                 <span className="text-sm font-medium text-white">Dark Mode</span>
                             </div>
                             <ToggleSwitch active={toggles.darkMode} onToggle={() => toggle('darkMode')} />
                        </div>
                        <div className="p-4 flex items-center justify-between cursor-pointer active:bg-glass-200">
                             <div className="flex items-center gap-3">
                                 <Globe size={18} className="text-gray-400" />
                                 <span className="text-sm font-medium text-white">Language</span>
                             </div>
                             <div className="flex items-center gap-2">
                                 <span className="text-xs text-gray-400">English (US)</span>
                                 <ChevronRight size={16} className="text-gray-500" />
                             </div>
                        </div>
                    </GlassCard>
                </section>

                {/* Footer Actions */}
                <div className="pt-4 flex flex-col gap-4">
                    <button className="flex items-center justify-center gap-2 text-sm text-red-400 font-medium p-4 rounded-xl border border-red-500/20 hover:bg-red-500/10 transition-colors">
                        <LogOut size={16} /> Log Out
                    </button>
                    <p className="text-center text-[10px] text-gray-600 font-mono">
                        HomeBase v2.4.0 (1024) • Server: US-East
                    </p>
                </div>

            </div>
        </div>
    );
}