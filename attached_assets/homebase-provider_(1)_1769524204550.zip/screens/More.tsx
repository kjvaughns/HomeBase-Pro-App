
import React, { useState } from 'react';
import { GlassHeader, GlassCard } from '../components/LiquidComponents';
import { Users, User, Settings, Shield, ChevronRight, HelpCircle, Briefcase, PlayCircle, Moon, Sun, Mail } from 'lucide-react';
import { Tab } from '../types';
import { useTheme } from '../components/ThemeContext';
import { ProfileSwitcher } from '../components/ProfileSwitcher';

interface MoreProps {
    onNavigate: (tab: Tab) => void;
}

export default function More({ onNavigate }: MoreProps) {
    const { theme, toggleTheme } = useTheme();
    const [isSwitcherOpen, setIsSwitcherOpen] = useState(false);
    const [profileMode, setProfileMode] = useState<'homeowner' | 'provider'>('provider');

    const menuItems = [
        { icon: Users, label: 'Clients', target: 'clients' as Tab, subtitle: 'Manage client list & details' },
        { icon: Briefcase, label: 'My Services', target: 'services' as Tab, subtitle: 'Pricing, packages & booking rules' },
        { icon: User, label: 'Business Profile', target: 'profile' as Tab, subtitle: 'Public appearance & branding' },
    ];

    const secondaryItems = [
        { icon: Shield, label: 'Team & Permissions', target: 'team' as Tab }, 
        { icon: Settings, label: 'App Settings', target: 'settings' as Tab }, 
        { icon: HelpCircle, label: 'Support', target: 'support' as Tab }, 
    ];

    return (
        <div className="pb-24">
            <GlassHeader 
              title="More" 
              rightAction={
                <button 
                  onClick={toggleTheme}
                  className="p-2 bg-gray-100 dark:bg-glass-200 rounded-full text-gray-900 dark:text-white"
                >
                  {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
                </button>
              }
            />
            
            <div className="px-5 mt-6 space-y-8">
                {/* Account Card Section */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 px-1">Account</h3>
                    <GlassCard 
                        onClick={() => setIsSwitcherOpen(true)}
                        className="p-4 flex items-center justify-between active:bg-gray-100 dark:active:bg-glass-200 transition-all group relative overflow-hidden"
                    >
                        <div className="flex items-center space-x-4 relative z-10">
                            <div className="h-14 w-14 rounded-2xl bg-homebase/10 border border-homebase/20 overflow-hidden">
                                <img src="https://picsum.photos/200/200" alt="Avatar" className="w-full h-full object-cover" />
                            </div>
                            <div>
                                <h4 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
                                    Alex Johnson
                                    <span className="text-[10px] font-bold text-homebase uppercase tracking-wider bg-homebase/10 px-2 py-0.5 rounded-full border border-homebase/20">
                                        {profileMode === 'provider' ? 'Service Provider' : 'Homeowner'}
                                    </span>
                                </h4>
                                <p className="text-xs text-gray-500 dark:text-gray-400 flex items-center gap-1">
                                    <Mail size={12} /> alex.j@example.com
                                </p>
                            </div>
                        </div>
                        <ChevronRight size={18} className="text-gray-400 relative z-10" />
                        <div className="absolute top-[-50%] right-[-10%] w-40 h-40 bg-homebase/5 blur-[40px] rounded-full pointer-events-none" />
                    </GlassCard>
                </section>

                {/* Developer / Testing Section */}
                <section>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 px-1">Development</h3>
                    <GlassCard 
                        onClick={() => onNavigate('onboarding')}
                        className="p-4 flex items-center justify-between active:bg-gray-100 dark:active:bg-glass-200 transition-colors cursor-pointer group bg-gradient-to-r from-homebase/20 to-transparent border-homebase/30"
                    >
                        <div className="flex items-center space-x-4">
                            <div className="p-3 rounded-2xl bg-homebase text-white group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-homebase/20">
                                <PlayCircle size={22} />
                            </div>
                            <div>
                                <span className="text-base font-bold text-gray-900 dark:text-white block">Test Onboarding</span>
                                <span className="text-xs text-gray-500 dark:text-gray-300">Run the full new user flow</span>
                            </div>
                        </div>
                        <ChevronRight size={18} className="text-homebase" />
                    </GlassCard>
                </section>

                {/* Primary Navigation */}
                <div className="space-y-3">
                    {menuItems.map((item, i) => (
                        <GlassCard 
                            key={i} 
                            onClick={() => onNavigate(item.target)}
                            className="p-4 flex items-center justify-between active:bg-gray-100 dark:active:bg-glass-200 transition-colors cursor-pointer group"
                        >
                            <div className="flex items-center space-x-4">
                                <div className="p-3 rounded-2xl bg-homebase/10 text-homebase group-hover:scale-110 transition-transform duration-300">
                                    <item.icon size={22} />
                                </div>
                                <div>
                                    <span className="text-base font-bold text-gray-900 dark:text-white block">{item.label}</span>
                                    <span className="text-xs text-gray-500 dark:text-gray-400">{item.subtitle}</span>
                                </div>
                            </div>
                            <ChevronRight size={18} className="text-gray-400 dark:text-gray-500" />
                        </GlassCard>
                    ))}
                </div>

                {/* Secondary Actions */}
                <div>
                    <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3 px-1">General</h3>
                    <GlassCard className="divide-y divide-gray-200 dark:divide-white/5 p-0">
                        {secondaryItems.map((item, i) => (
                             <div 
                                key={i}
                                onClick={() => onNavigate(item.target)}
                                className="p-4 flex items-center justify-between active:bg-gray-100 dark:active:bg-glass-200 transition-colors cursor-pointer"
                             >
                                <div className="flex items-center space-x-3">
                                    <item.icon size={18} className="text-gray-400" />
                                    <span className="text-sm font-medium text-gray-700 dark:text-gray-200">{item.label}</span>
                                </div>
                                <ChevronRight size={16} className="text-gray-500 dark:text-gray-600" />
                             </div>
                        ))}
                    </GlassCard>
                </div>
                
                <div className="text-center pt-4">
                    <p className="text-[10px] text-gray-400 dark:text-gray-600 font-mono">Version 2.4.0 (Build 1024)</p>
                </div>
            </div>

            {/* Profile Switcher Bottom Sheet */}
            <ProfileSwitcher 
                isOpen={isSwitcherOpen} 
                onClose={() => setIsSwitcherOpen(false)} 
                currentProfile={profileMode}
                onSwitch={setProfileMode}
                onStartProviderOnboarding={() => onNavigate('onboarding')}
            />
        </div>
    );
}
