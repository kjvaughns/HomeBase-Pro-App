import React from 'react';
import { GlassHeader, GlassCard, GlassButton } from '../components/LiquidComponents';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { ArrowUpRight, Copy, CreditCard, Wallet } from 'lucide-react';
import { useTheme } from '../components/ThemeContext';

const data = [
  { name: 'M', amt: 2400 },
  { name: 'T', amt: 1398 },
  { name: 'W', amt: 9800 },
  { name: 'T', amt: 3908 },
  { name: 'F', amt: 4800 },
  { name: 'S', amt: 3800 },
  { name: 'S', amt: 4300 },
];

export default function MoneyHub() {
  const { theme } = useTheme();

  return (
    <div className="pb-24">
      <GlassHeader title="Money Hub" subtitle="Financial Overview" />

      <div className="px-5 mt-6 space-y-6">
        {/* Total Balance Card */}
        <GlassCard className="p-6 bg-gradient-to-br from-gray-50/50 to-white/30 dark:from-glass-200 dark:to-glass-100 border border-gray-200 dark:border-white/10 shadow-xl">
          <div className="flex justify-between items-start mb-6">
             <div>
                <p className="text-sm text-gray-500 dark:text-gray-400 font-medium">Total Balance</p>
                <h2 className="text-4xl font-bold text-gray-900 dark:text-white mt-1 tracking-tight">$14,250.00</h2>
             </div>
             <div className="p-2 bg-homebase/20 rounded-full">
                <Wallet className="text-homebase" size={24} />
             </div>
          </div>
          <div className="flex space-x-3">
             <GlassButton className="flex-1 text-xs" variant="primary">Withdraw</GlassButton>
             <GlassButton className="flex-1 text-xs" variant="secondary">Send Invoice</GlassButton>
          </div>
        </GlassCard>

        {/* Analytics Chart */}
        <div>
            <div className="flex justify-between items-end mb-3 px-1">
                <h3 className="text-lg font-bold text-gray-900 dark:text-white">Revenue</h3>
                <span className="text-xs text-homebase font-bold flex items-center bg-homebase/10 px-2 py-1 rounded-lg">
                    <ArrowUpRight size={12} className="mr-1" /> +12.5%
                </span>
            </div>
            <GlassCard className="h-64 p-4">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data}>
                        <XAxis 
                          dataKey="name" 
                          axisLine={false} 
                          tickLine={false} 
                          tick={{fill: theme === 'dark' ? '#6b7280' : '#9ca3af', fontSize: 12}} 
                        />
                        <Tooltip 
                            cursor={{fill: theme === 'dark' ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)'}}
                            contentStyle={{
                              backgroundColor: theme === 'dark' ? '#000' : '#fff', 
                              border: theme === 'dark' ? '1px solid rgba(255,255,255,0.1)' : '1px solid rgba(0,0,0,0.1)', 
                              borderRadius: '12px', 
                              color: theme === 'dark' ? '#fff' : '#111',
                              boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'
                            }}
                        />
                        <Bar dataKey="amt" fill="#0FAF6E" radius={[6, 6, 6, 6]} barSize={24} />
                    </BarChart>
                </ResponsiveContainer>
            </GlassCard>
        </div>

        {/* Payment Links */}
        <div>
            <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-3 px-1">Quick Links</h3>
            <GlassCard className="p-0 overflow-hidden divide-y divide-gray-100 dark:divide-white/5">
                <div className="p-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-white/5 transition-colors">
                    <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 bg-purple-500/20 rounded-xl flex items-center justify-center">
                             <CreditCard size={20} className="text-purple-600 dark:text-purple-400" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-gray-900 dark:text-white">Standard Clean</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">$120.00</p>
                        </div>
                    </div>
                    <button className="p-2 hover:bg-gray-200 dark:hover:bg-white/10 rounded-lg transition-colors">
                        <Copy size={18} className="text-gray-400 dark:text-gray-500" />
                    </button>
                </div>
                <div className="p-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-white/5 transition-colors">
                    <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 bg-blue-500/20 rounded-xl flex items-center justify-center">
                             <CreditCard size={20} className="text-blue-600 dark:text-blue-400" />
                        </div>
                        <div>
                            <p className="text-sm font-bold text-gray-900 dark:text-white">Deep Clean</p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">$250.00</p>
                        </div>
                    </div>
                    <button className="p-2 hover:bg-gray-200 dark:hover:bg-white/10 rounded-lg transition-colors">
                        <Copy size={18} className="text-gray-400 dark:text-gray-500" />
                    </button>
                </div>
            </GlassCard>
        </div>
      </div>
    </div>
  );
}