# HomeBase Provider Blueprint

This directory contains the single source of truth for the HomeBase Provider application. It serves as the formal contract between design, frontend, and backend implementation.

## Purpose
This blueprint ensures that any developer or automated vibe coding platform can extend the application (e.g., implementing the Supabase backend) without guessing the architecture, data relationships, or business logic.

## Drift Control
1. **Blueprint First**: Any structural change to the data model, API contract, or core logic MUST be updated here first.
2. **Implementation Second**: Only after the Blueprint is updated should code changes be applied.
3. **Audit**: Periodic checks ensure the Supabase schema and React components align with these definitions.

## Project Context
- **Project Name**: HomeBase Provider
- **App Type**: Mobile-first Web App (Progressive Web App)
- **Frontend**: React (ESM), Tailwind CSS, Framer Motion
- **Backend**: Supabase (Postgres, Auth, Storage, Edge Functions)
