# Notifications

## Types
1. **New Booking**: Real-time push to Owner/Admin when a client books via the public page.
2. **Job Reminder**: Sent to Technician 30 mins before `scheduled_start`.
3. **Payment Received**: Sent to Owner when an invoice is marked `paid`.

## Rules
- **Technicians**: Only receive notifications for `assigned_to` jobs.
- **Owners**: Receive all financial and booking notifications.
- **Dedupe**: If status changes twice within 5 seconds, send only the final state.
