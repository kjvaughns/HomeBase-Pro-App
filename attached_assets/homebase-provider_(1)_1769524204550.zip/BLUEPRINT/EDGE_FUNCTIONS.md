# Edge Functions

## 1. `ai-assistant`
- **Purpose**: Processes text from `AskAI` and `Onboarding`. Connects to Gemini API.
- **Trigger**: HTTP POST.
- **Inputs**: `prompt`, `context` (current schedule/clients).
- **Security**: Requires Supabase JWT.

## 2. `stripe-webhooks`
- **Purpose**: Syncs subscription status to `organizations.settings`.
- **Trigger**: HTTP POST (Stripe).
- **Security**: Stripe signature verification.

## 3. `process-invoice`
- **Purpose**: Generates PDF and sends email link when job is marked `completed`.
- **Trigger**: DB Trigger on `jobs` status change.
- **Security**: Internal system only.
