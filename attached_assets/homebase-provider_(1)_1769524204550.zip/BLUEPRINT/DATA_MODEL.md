# Data Model

## Enums
- `job_status`: `scheduled`, `on-the-way`, `in-progress`, `completed`, `cancelled`, `invoiced`
- `member_role`: `owner`, `admin`, `technician`
- `pricing_type`: `fixed`, `variable`, `quote`, `callout`
- `client_status`: `active`, `lead`, `inactive`

## Tables

### `organizations`
- `id`: uuid (PK)
- `name`: text (Required)
- `slug`: text (Unique, used for booking URL)
- `industry`: text
- `logo_url`: text
- `bio`: text
- `owner_id`: uuid (FK to profiles)
- `settings`: jsonb (billing frequency, currency)

### `profiles`
- `id`: uuid (PK, FK to auth.users)
- `org_id`: uuid (FK to organizations)
- `full_name`: text
- `avatar_url`: text
- `role`: member_role
- `phone`: text

### `clients`
- `id`: uuid (PK)
- `org_id`: uuid (FK to organizations)
- `full_name`: text
- `email`: text
- `phone`: text
- `address`: text
- `status`: client_status
- `notes`: text
- `ltv`: numeric (Default 0)

### `services`
- `id`: uuid (PK)
- `org_id`: uuid (FK to organizations)
- `name`: text
- `description`: text
- `category`: text
- `price_type`: pricing_type
- `base_price`: numeric
- `duration_minutes`: integer
- `is_active`: boolean (Default true)

### `jobs`
- `id`: uuid (PK)
- `org_id`: uuid (FK to organizations)
- `client_id`: uuid (FK to clients)
- `service_id`: uuid (FK to services)
- `scheduled_start`: timestamptz
- `duration_minutes`: integer
- `status`: job_status
- `price`: numeric
- `address`: text
- `notes`: text
- `assigned_to`: uuid (FK to profiles)

### `line_items`
- `id`: uuid (PK)
- `job_id`: uuid (FK to jobs)
- `name`: text
- `price`: numeric

### `support_tickets`
- `id`: uuid (PK)
- `user_id`: uuid (FK to profiles)
- `subject`: text
- `description`: text
- `status`: text (open, pending, resolved)
- `priority`: text
