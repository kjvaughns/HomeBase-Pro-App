# Application Specification

## Product Summary
HomeBase Provider is a "Business Operating System" for solo-pros and small home service teams (Cleaning, Landscaping, HVAC, etc.). It transforms a messy workflow of texts and paper into a high-fidelity, automated experience. Key value props: professional public appearance via AI-generated profiles, automated scheduling through an AI-assistant booking page, and seamless financial tracking.

## Personas & Jobs to be Done (JTBD)
1. **The Owner (Solo-Pro)**: Needs to look "bigger" than they are, automate client intake, and stop chasing unpaid invoices.
2. **The Technician (Team Member)**: Needs a clear daily schedule, turn-by-turn navigation to jobs, and a way to signal job completion without calling the boss.
3. **The Admin**: Needs to manage team permissions, billing, and high-level business settings.

## Roles & Permissions Matrix
| Feature | Owner | Admin | Technician | Public |
|---------|-------|-------|------------|--------|
| View Dashboard Stats | Yes | Yes | No | No |
| Manage Services/Pricing | Yes | Yes | No | No |
| Create/Edit Jobs | Yes | Yes | Assigned | No |
| View Client PII | Yes | Yes | Assigned | No |
| Manage Team Members | Yes | No | No | No |
| View Public Booking | Yes | Yes | Yes | Yes |

## Onboarding Flow
1. **Identity**: Industry selection and business naming.
2. **AI Bio**: Input raw description -> AI generates professional profile.
3. **Operational Core**: Set availability and create the first service.
4. **Validation**: Preview the public booking page.
5. **Gating**: Paywall (Stripe) to unlock the full dashboard.

## Feature Inventory
- **Liquid Dashboard**: KPI cards (Revenue, Jobs, Clients) and "Attention Needed" tiles.
- **Dynamic Schedule**: List, Day, Week, and Month views with drag-and-drop logic.
- **Client CRM**: Profile views with LTV tracking and activity history.
- **Money Hub**: Revenue charts, wallet balance, and quick-pay link generation.
- **Service Editor**: Support for Fixed, Variable, and Quote-only pricing.
- **Ask AI**: Direct chat interface to query business data or perform actions.
- **Team Portal**: Real-time simulation of the tech-side experience.

## Non-Functional Requirements
- **Performance**: < 100ms interaction delay; heavy use of Framer Motion for perceived speed.
- **Accessibility**: High contrast dark/light modes; ARIA-compliant sheets and inputs.
- **Reliability**: Offline-first optimistic updates for job completions.
