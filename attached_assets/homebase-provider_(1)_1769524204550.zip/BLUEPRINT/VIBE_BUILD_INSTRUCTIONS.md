# Build Instructions

## Phase 1: Infrastructure
1. Run `BLUEPRINT/SCHEMA.sql` in Supabase SQL Editor.
2. Run `BLUEPRINT/RLS_POLICIES.sql`.
3. Configure Supabase Auth with Google/Email.

## Phase 2: Frontend Data Binding
1. Create `lib/supabase.ts` using `@supabase/supabase-js`.
2. Replace mock arrays in `Dashboard.tsx`, `Schedule.tsx`, and `Clients.tsx` with `supabase.from('...').select()`.
3. Implement `ThemeContext` persistence via Supabase profile settings instead of just localStorage.

## Phase 3: AI Integration
1. Deploy `ai-assistant` Edge Function.
2. Update `AskAI.tsx` to call the edge function instead of the local mock timeout.

## Definition of Done
- All RLS policies are verified (Techs cannot see Org Revenue).
- Job status changes in UI reflect in the DB instantly.
- Public booking page creates a `lead` client and a `scheduled` job.
