
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, Home, Briefcase, Check, ChevronRight, 
  Sparkles, Shield, DollarSign, ArrowRight 
} from 'lucide-react';
import { GlassCard, GlassButton, GlassSheet } from './LiquidComponents';

interface ProfileSwitcherProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: 'homeowner' | 'provider';
  onSwitch: (profile: 'homeowner' | 'provider') => void;
  onStartProviderOnboarding: () => void;
}

export const ProfileSwitcher: React.FC<ProfileSwitcherProps> = ({ 
  isOpen, 
  onClose, 
  currentProfile, 
  onSwitch,
  onStartProviderOnboarding
}) => {
  const [view, setView] = useState<'selection' | 'confirm' | 'onboarding'>('selection');
  const [targetProfile, setTargetProfile] = useState<'homeowner' | 'provider' | null>(null);

  const isProviderSetUp = true; // Mock state

  const handleProfileSelect = (profile: 'homeowner' | 'provider') => {
    if (profile === currentProfile) return;
    
    if (profile === 'provider' && !isProviderSetUp) {
      setView('onboarding');
      return;
    }

    setTargetProfile(profile);
    setView('confirm');
  };

  const resetAndClose = () => {
    setView('selection');
    setTargetProfile(null);
    onClose();
  };

  const renderSelection = () => (
    <div className="space-y-4">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-900 dark:text-white">Switch Profile</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400">Choose how you want to use HomeBase</p>
      </div>

      {/* Homeowner Option */}
      <button 
        onClick={() => handleProfileSelect('homeowner')}
        className={`w-full text-left p-4 rounded-2xl border transition-all duration-300 relative overflow-hidden group ${
          currentProfile === 'homeowner' 
          ? 'bg-homebase/10 border-homebase ring-1 ring-homebase' 
          : 'bg-gray-100 dark:bg-glass-200 border-gray-200 dark:border-white/5 hover:bg-gray-200 dark:hover:bg-glass-300'
        }`}
      >
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-xl ${currentProfile === 'homeowner' ? 'bg-homebase text-white' : 'bg-gray-200 dark:bg-white/10 text-gray-500'}`}>
            <Home size={24} />
          </div>
          <div className="flex-1">
            <h4 className="font-bold text-gray-900 dark:text-white">Homeowner</h4>
            <p className="text-xs text-gray-500 dark:text-gray-400">Book services and manage your homes</p>
          </div>
          {currentProfile === 'homeowner' ? (
            <div className="bg-homebase text-white p-1 rounded-full">
              <Check size={14} />
            </div>
          ) : (
            <span className="text-[10px] font-bold text-homebase uppercase tracking-wider bg-homebase/10 px-2 py-0.5 rounded-full">Available</span>
          )}
        </div>
      </button>

      {/* Provider Option */}
      <button 
        onClick={() => handleProfileSelect('provider')}
        className={`w-full text-left p-4 rounded-2xl border transition-all duration-300 relative overflow-hidden group ${
          currentProfile === 'provider' 
          ? 'bg-homebase/10 border-homebase ring-1 ring-homebase' 
          : 'bg-gray-100 dark:bg-glass-200 border-gray-200 dark:border-white/5 hover:bg-gray-200 dark:hover:bg-glass-300'
        }`}
      >
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-xl ${currentProfile === 'provider' ? 'bg-homebase text-white' : 'bg-gray-200 dark:bg-white/10 text-gray-500'}`}>
            <Briefcase size={24} />
          </div>
          <div className="flex-1">
            <h4 className="font-bold text-gray-900 dark:text-white">
              {isProviderSetUp ? 'Service Provider' : 'Become a Provider'}
            </h4>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {isProviderSetUp ? 'Run your service business on HomeBase' : 'Set up your business in minutes'}
            </p>
          </div>
          {currentProfile === 'provider' ? (
            <div className="bg-homebase text-white p-1 rounded-full">
              <Check size={14} />
            </div>
          ) : isProviderSetUp ? (
            <span className="text-[10px] font-bold text-homebase uppercase tracking-wider bg-homebase/10 px-2 py-0.5 rounded-full">Available</span>
          ) : (
            <ChevronRight size={18} className="text-gray-400" />
          )}
        </div>
      </button>
    </div>
  );

  const renderConfirm = () => (
    <div className="text-center py-4">
      <div className="w-16 h-16 bg-homebase/20 rounded-full flex items-center justify-center mx-auto mb-6">
        {targetProfile === 'provider' ? <Briefcase size={32} className="text-homebase" /> : <Home size={32} className="text-homebase" />}
      </div>
      <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
        Switch to {targetProfile === 'provider' ? 'Service Provider' : 'Homeowner'}?
      </h3>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-8 max-w-xs mx-auto">
        You can switch back anytime. Your data and settings stay separate for each profile.
      </p>
      <div className="space-y-3">
        <GlassButton 
          onClick={() => {
            onSwitch(targetProfile!);
            resetAndClose();
          }} 
          className="w-full"
        >
          Switch Profile
        </GlassButton>
        <button 
          onClick={() => setView('selection')} 
          className="text-sm font-medium text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white py-2"
        >
          Cancel
        </button>
      </div>
    </div>
  );

  const renderOnboardingIntro = () => (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-16 h-16 bg-homebase/20 rounded-full flex items-center justify-center mx-auto mb-6">
          <Sparkles size={32} className="text-homebase" />
        </div>
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Unlock the Provider Side</h3>
        <p className="text-sm text-gray-500 dark:text-gray-400">Transform how you work and get paid</p>
      </div>

      <div className="space-y-4">
        {[
          { icon: Sparkles, label: 'Get booked by homeowners', desc: 'Auto-scheduling via AI assistant' },
          { icon: DollarSign, label: 'Manage jobs and payments', desc: 'Track every dollar and invoice' },
          { icon: Shield, label: 'Grow your business', desc: 'Professional public profile and SEO' },
        ].map((item, i) => (
          <div key={i} className="flex gap-4 p-4 rounded-xl bg-gray-50 dark:bg-white/5 border border-gray-200 dark:border-white/5">
            <div className="p-2 bg-homebase/10 rounded-lg h-fit">
              <item.icon size={20} className="text-homebase" />
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900 dark:text-white">{item.label}</p>
              <p className="text-xs text-gray-500 dark:text-gray-400">{item.desc}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-3 pt-4">
        <GlassButton 
          onClick={() => {
            onStartProviderOnboarding();
            resetAndClose();
          }} 
          className="w-full flex justify-between px-6"
        >
          <span>Start Provider Setup</span>
          <ArrowRight size={18} />
        </GlassButton>
        <button 
          onClick={() => setView('selection')} 
          className="w-full text-center text-sm font-medium text-gray-500 dark:text-gray-400 py-2"
        >
          Not now
        </button>
      </div>
    </div>
  );

  return (
    <GlassSheet 
      isOpen={isOpen} 
      onClose={resetAndClose} 
      title={view === 'selection' ? 'Switch Profile' : ''}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={view}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          {view === 'selection' && renderSelection()}
          {view === 'confirm' && renderConfirm()}
          {view === 'onboarding' && renderOnboardingIntro()}
        </motion.div>
      </AnimatePresence>
    </GlassSheet>
  );
};
