
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LucideIcon, X } from 'lucide-react';

// --- Base Container ---
export const GlassCard: React.FC<{ children?: React.ReactNode; className?: string; onClick?: () => void }> = ({ children, className = '', onClick }) => (
  <motion.div
    whileTap={onClick ? { scale: 0.98 } : undefined}
    onClick={onClick}
    className={`relative overflow-hidden rounded-2xl border border-gray-200 dark:border-glass-border bg-white/60 dark:bg-glass-100 backdrop-blur-xl shadow-lg ${className}`}
  >
    <div className="absolute inset-0 bg-gradient-to-br from-white/20 dark:from-white/5 to-transparent pointer-events-none" />
    <div className="relative z-10">{children}</div>
  </motion.div>
);

// --- Sheets ---
export const GlassSheet: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  children: React.ReactNode; 
  title?: string;
}> = ({ isOpen, onClose, children, title }) => (
  <AnimatePresence>
    {isOpen && (
      <>
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-black/40 dark:bg-black/60 backdrop-blur-sm z-50"
        />
        <motion.div
          initial={{ y: "100%" }}
          animate={{ y: 0 }}
          exit={{ y: "100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className="fixed bottom-0 left-0 right-0 bg-white dark:bg-glass-200 border-t border-gray-200 dark:border-glass-border backdrop-blur-xl rounded-t-3xl z-50 max-h-[90vh] overflow-y-auto shadow-2xl safe-bottom"
        >
          <div className="sticky top-0 left-0 right-0 bg-white/90 dark:bg-glass-300/80 backdrop-blur-md z-10 border-b border-gray-200 dark:border-white/5 px-6 py-4 flex justify-between items-center">
             <div className="w-8" /> {/* Spacer */}
             {/* Drag Handle */}
             <div className="absolute top-2 left-1/2 -translate-x-1/2 w-12 h-1 bg-gray-300 dark:bg-white/20 rounded-full" />
             <h3 className="text-lg font-bold text-gray-900 dark:text-white pt-2">{title}</h3>
             <button onClick={onClose} className="p-1 rounded-full bg-gray-100 dark:bg-white/10 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-white/20">
               <X size={20} />
             </button>
          </div>
          <div className="p-6 pb-12">
            {children}
          </div>
        </motion.div>
      </>
    )}
  </AnimatePresence>
);

// --- Inputs ---
export const GlassInput = ({ icon: Icon, placeholder, value, onChange }: { icon?: LucideIcon, placeholder: string, value?: string, onChange?: (e: any) => void }) => (
  <div className="relative group">
    <div className="absolute inset-0 rounded-xl bg-homebase opacity-0 group-focus-within:opacity-20 transition-opacity duration-300 blur-md" />
    <div className="relative flex items-center bg-gray-100/50 dark:bg-glass-200 border border-gray-200 dark:border-glass-border rounded-xl px-4 py-3 backdrop-blur-md">
      {Icon && <Icon size={18} className="text-gray-400 mr-3" />}
      <input 
        type="text" 
        className="bg-transparent border-none outline-none text-gray-900 dark:text-white placeholder-gray-400 dark:placeholder-gray-500 w-full text-sm"
        placeholder={placeholder}
        value={value}
        onChange={onChange}
      />
    </div>
  </div>
);

// --- Headers ---
export const GlassHeader = ({ title, subtitle, rightAction }: { title: string; subtitle?: string; rightAction?: React.ReactNode }) => (
  <div className="sticky top-0 z-40 px-6 pt-12 pb-4 bg-white/70 dark:bg-black/60 backdrop-blur-xl border-b border-gray-200 dark:border-white/5 flex justify-between items-center">
    <div>
      <h1 className="text-xl font-bold text-gray-900 dark:text-white tracking-tight">{title}</h1>
      {subtitle && <p className="text-xs text-homebase font-medium mt-0.5 uppercase tracking-wider">{subtitle}</p>}
    </div>
    {rightAction}
  </div>
);

// --- Buttons ---
export const GlassButton: React.FC<{ children?: React.ReactNode; variant?: 'primary' | 'secondary' | 'ghost' | 'danger'; className?: string; onClick?: () => void; icon?: LucideIcon }> = ({ children, variant = 'primary', className = '', onClick, icon: Icon }) => {
  const baseStyles = "relative flex items-center justify-center rounded-xl px-5 py-3 font-medium text-sm transition-all duration-200 overflow-hidden";
  const variants = {
    primary: "bg-homebase text-white shadow-[0_0_20px_rgba(15,175,110,0.4)] hover:bg-homebase-light active:scale-[0.96]",
    secondary: "bg-gray-100 dark:bg-glass-200 border border-gray-200 dark:border-glass-border text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-glass-300 active:scale-[0.96]",
    ghost: "bg-transparent text-homebase hover:bg-gray-100 dark:hover:bg-glass-100",
    danger: "bg-red-500/10 dark:bg-red-500/20 text-red-500 dark:text-red-400 border border-red-500/20 dark:border-red-500/30 hover:bg-red-500/20 dark:hover:bg-red-500/30"
  };

  return (
    <motion.button 
      whileTap={{ scale: 0.96 }}
      className={`${baseStyles} ${variants[variant]} ${className}`}
      onClick={onClick}
    >
      {Icon && <Icon size={16} className="mr-2" />}
      {children}
    </motion.button>
  );
};

// --- Segmented Control ---
export const SegmentedControl = ({ options, selected, onChange }: { options: string[]; selected: string; onChange: (val: string) => void }) => (
  <div className="bg-gray-100 dark:bg-glass-200 p-1 rounded-xl flex border border-gray-200 dark:border-glass-border backdrop-blur-md relative">
    {options.map((option) => {
      const isSelected = selected.toLowerCase() === option.toLowerCase();
      return (
        <button
          key={option}
          onClick={() => onChange(option)}
          className={`flex-1 relative py-1.5 text-xs font-semibold rounded-lg capitalize transition-colors duration-200 z-10 ${isSelected ? 'text-gray-900 dark:text-white' : 'text-gray-400'}`}
        >
          {option}
          {isSelected && (
            <motion.div
              layoutId="segmentIndicator"
              className="absolute inset-0 bg-white dark:bg-glass-300 rounded-lg border border-gray-200 dark:border-white/10 shadow-sm -z-10"
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
            />
          )}
        </button>
      );
    })}
  </div>
);

// --- Status Chips ---
export const StatusChip = ({ status }: { status: string }) => {
  const getColors = (s: string) => {
    switch(s.toLowerCase()) {
      case 'completed': return 'bg-homebase/20 text-homebase border-homebase/30';
      case 'invoiced': return 'bg-purple-500/20 text-purple-600 dark:text-purple-400 border-purple-500/30';
      case 'scheduled': return 'bg-blue-500/20 text-blue-600 dark:text-blue-400 border-blue-500/30';
      case 'on-the-way': return 'bg-yellow-500/20 text-yellow-600 dark:text-yellow-400 border-yellow-500/30';
      case 'in-progress': return 'bg-orange-500/20 text-orange-600 dark:text-orange-400 border-orange-500/30';
      case 'cancelled': return 'bg-red-500/20 text-red-600 dark:text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-500 dark:text-gray-400 border-gray-500/30';
    }
  }

  return (
    <span className={`px-2.5 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider border ${getColors(status)}`}>
      {status.replace(/-/g, ' ')}
    </span>
  )
};
