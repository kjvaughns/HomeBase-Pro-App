
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Home as HomeIcon, Search, Plus, Calendar, MoreHorizontal, Sparkles, Building, X, DollarSign, LayoutGrid, Briefcase, FileText, User, Receipt, ChevronRight } from 'lucide-react';
import { Tab, Provider, HomeProfile, ProfileType } from './types';
import Home from './screens/Home';
import Explore from './screens/Explore';
import Manage from './screens/Manage';
import More from './screens/More';
import AIChat from './screens/AIChat';
import ProviderProfile from './screens/ProviderProfile';
import BookingFlow from './screens/BookingFlow';
import ToolsHome from './screens/ToolsHome';
import SurvivalKit from './screens/SurvivalKit';
import HomeHealthScore from './screens/HomeHealthScore';
import HouseFaxLedger from './screens/HouseFaxLedger';
import BudgetSavings from './screens/BudgetSavings';
import OnboardingFlow from './screens/OnboardingFlow';

// Provider Portal Screens
import ProviderHome from './screens/ProviderHome';
import ProviderSchedule from './screens/ProviderSchedule';
import ProviderMoney from './screens/ProviderMoney';

const INITIAL_HOMES: HomeProfile[] = [
  { 
    id: 'h1', 
    nickname: 'Main House', 
    address: '123 Emerald Heights, San Francisco, CA', 
    zip: '94105',
    type: 'House', 
    sqft: 2400, 
    beds: 4,
    baths: 3.5,
    yearBuilt: '2010s', 
    roofAge: '5 to 15 years', 
    systems: { hvac: 'Central', heating: 'Gas', waterHeater: 'Traditional Tank', pool: false, lawn: true },
    habits: { filters: true, gutters: true, hvac: true },
    booking: { preferredTimes: ["Morning (8am-12pm)"], shareNotes: true, gateCode: '4422', pets: '1 Golden Retriever' },
    issues: ['Low Water Pressure'],
    goal: 'Prevent emergencies',
    image: 'https://picsum.photos/400/300?1',
    profileStrength: 85
  }
];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.Home);
  const [fabOpen, setFabOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [profileType, setProfileType] = useState<ProfileType>(ProfileType.Homeowner);
  
  const [homes, setHomes] = useState<HomeProfile[]>(INITIAL_HOMES);
  const [activeHome, setActiveHome] = useState<HomeProfile>(INITIAL_HOMES[0]);
  
  const [selectedProvider, setSelectedProvider] = useState<Provider | null>(null);
  const [bookingProvider, setBookingProvider] = useState<Provider | null>(null);

  useEffect(() => {
    setTimeout(() => setLoading(false), 1200);
  }, []);

  const toggleTheme = () => setIsDarkMode(prev => !prev);

  const HOMEOWNER_FAB = [
    { label: 'AI Intelligence', icon: <Sparkles size={20} />, action: () => { setAiOpen(true); setFabOpen(false); } },
    { label: 'Book Specialist', icon: <Search size={20} />, action: () => { setActiveTab(Tab.Explore); setFabOpen(false); } },
    { label: 'Infrastructure Tools', icon: <Building size={20} />, action: () => { setActiveTab(Tab.ToolsHome); setFabOpen(false); } },
    { label: 'Add Portfolio Home', icon: <Plus size={20} />, action: () => { setActiveTab(Tab.Manage); setFabOpen(false); } },
  ];

  const PROVIDER_FAB = [
    { label: 'New Job', icon: <Briefcase size={20} />, action: () => { setFabOpen(false); } },
    { label: 'Send Invoice', icon: <DollarSign size={20} />, action: () => { setFabOpen(false); } },
    { label: 'Client Add', icon: <User size={20} />, action: () => { setFabOpen(false); } },
    { label: 'Ask HomeBase AI', icon: <Sparkles size={20} className="text-homebase" />, action: () => { setAiOpen(true); setFabOpen(false); } },
  ];

  const isSubViewActive = !!selectedProvider || !!bookingProvider || aiOpen || [Tab.SurvivalKit, Tab.HomeHealth, Tab.HouseFax, Tab.BudgetSavings, Tab.Onboarding].includes(activeTab);

  const isProvider = profileType === ProfileType.Provider;

  return (
    <div className={`relative w-full h-screen bg-app transition-colors duration-700 overflow-hidden select-none flex justify-center items-center ${isDarkMode ? '' : 'light-mode'}`}>
      
      {/* Premium Screen Container */}
      <div className={`relative w-full max-w-[430px] h-full sm:h-[90vh] bg-surface sm:rounded-[4rem] sm:border-[10px] border-surface shadow-[0_50px_100px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col transition-all duration-700`}>
        
        {/* Content Layer */}
        <div className="flex-1 relative">
          <AnimatePresence mode="wait">
            {loading ? (
              <motion.div 
                key="loading" 
                className="absolute inset-0 flex flex-col items-center justify-center bg-surface z-[120]"
                exit={{ opacity: 0 }}
              >
                <div className="w-20 h-20 bg-homebase rounded-4xl shadow-2xl shadow-homebase/40 flex items-center justify-center animate-pulse mb-8">
                  <HomeIcon size={38} className="text-white fill-white" />
                </div>
                <h1 className="text-2xl font-black text-main tracking-tighter italic">HOMEBASE</h1>
              </motion.div>
            ) : (
              <motion.div
                key={`${profileType}-${activeTab}`}
                initial={{ opacity: 0, scale: 0.99 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, ease: "easeOut" }}
                className="absolute inset-0 overflow-hidden"
              >
                {/* Routing Logic */}
                {!isProvider ? (
                  <>
                    {activeTab === Tab.Home && <Home onNavigate={setActiveTab} onOpenAI={() => setAiOpen(true)} isDarkMode={isDarkMode} toggleTheme={toggleTheme} />}
                    {activeTab === Tab.Explore && <Explore onOpenAI={() => setAiOpen(true)} onSelectProvider={(p) => setSelectedProvider(p)} />}
                    {activeTab === Tab.Manage && <Manage homes={homes} onAddHome={()=>{}} onUpdateHome={()=>{}} onDeleteHome={()=>{}} onNavigate={setActiveTab} onOpenAI={() => setAiOpen(true)} />}
                  </>
                ) : (
                  <>
                    {activeTab === Tab.Home && <ProviderHome onOpenAI={() => setAiOpen(true)} onNavigate={setActiveTab} />}
                    {activeTab === Tab.Explore && <ProviderSchedule />}
                    {activeTab === Tab.Manage && <ProviderMoney />}
                  </>
                )}

                {activeTab === Tab.More && (
                  <More 
                    onNavigate={setActiveTab} 
                    isDarkMode={isDarkMode} 
                    toggleTheme={toggleTheme} 
                    profileType={profileType}
                    onSwitchProfile={(type) => {
                      setProfileType(type);
                      setActiveTab(Tab.Home);
                    }}
                  />
                )}
                
                {activeTab === Tab.ToolsHome && <ToolsHome activeHome={activeHome} homes={homes} onSelectHome={setActiveHome} onNavigate={setActiveTab} />}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* FAB Overlay Blur */}
        <AnimatePresence>
          {fabOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setFabOpen(false)}
              className="absolute inset-0 z-[150] bg-black/40 blur-overlay"
            />
          )}
        </AnimatePresence>

        {/* FAB Menu - Compact Action Sheet Style */}
        <AnimatePresence>
          {fabOpen && (
            <motion.div
              initial={{ y: 100, opacity: 0, scale: 0.9 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 100, opacity: 0, scale: 0.9 }}
              className="absolute bottom-32 left-8 right-8 z-[160] liquid-glass-heavy rounded-[3rem] p-6 border-white/10 shadow-2xl flex flex-col gap-2"
            >
              {(isProvider ? PROVIDER_FAB : HOMEOWNER_FAB).map((item, i) => (
                <motion.button
                  key={item.label}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  onClick={item.action}
                  className="w-full flex items-center gap-4 p-4 rounded-2xl bg-white/[0.03] hover:bg-white/[0.08] transition-all border border-transparent hover:border-white/5 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-homebase/10 text-homebase flex items-center justify-center shadow-inner group-hover:scale-110 transition-transform">
                    {item.icon}
                  </div>
                  <span className="text-main font-black text-xs uppercase tracking-[0.2em] italic">{item.label}</span>
                  <div className="flex-1" />
                  <ChevronRight size={14} className="text-dim/20" />
                </motion.button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Global Overlays */}
        <AnimatePresence>
           {activeTab === Tab.SurvivalKit && <SurvivalKit activeHome={activeHome} onBack={() => setActiveTab(Tab.ToolsHome)} />}
           {activeTab === Tab.HomeHealth && <HomeHealthScore activeHome={activeHome} onBack={() => setActiveTab(Tab.ToolsHome)} />}
           {activeTab === Tab.HouseFax && <HouseFaxLedger activeHome={activeHome} onBack={() => setActiveTab(Tab.ToolsHome)} />}
           {activeTab === Tab.BudgetSavings && <BudgetSavings activeHome={activeHome} onBack={() => setActiveTab(Tab.ToolsHome)} />}
           {activeTab === Tab.Onboarding && <OnboardingFlow onComplete={() => setActiveTab(Tab.Home)} onExit={() => setActiveTab(Tab.More)} />}
        </AnimatePresence>

        {/* Floating Dock Area */}
        <div className={`absolute bottom-8 left-8 right-8 transition-all duration-700 ${isSubViewActive ? 'translate-y-40 opacity-0' : 'z-[100]'}`}>
          <div className="relative">
            <nav className="glass-dock rounded-[2.8rem] px-7 py-3 flex items-center justify-between border-white/5 relative z-10 shadow-2xl premium-glow">
              <TabButton active={activeTab === Tab.Home} icon={<HomeIcon size={24} />} label="HOME" onClick={() => {setActiveTab(Tab.Home); setFabOpen(false);}} />
              <TabButton active={activeTab === Tab.Explore} icon={isProvider ? <Calendar size={24} /> : <Search size={24} />} label={isProvider ? "SCHEDULE" : "FIND"} onClick={() => {setActiveTab(Tab.Explore); setFabOpen(false);}} />
              
              {/* Centered FAB Trigger */}
              <div className="relative -top-1">
                <motion.button
                  whileTap={{ scale: 0.92 }}
                  onClick={() => setFabOpen(!fabOpen)}
                  className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-500 fab-glow border-[3px] border-surface ${
                    fabOpen ? 'bg-white text-black rotate-45' : 'bg-homebase text-white'
                  }`}
                >
                  {fabOpen ? <X size={24} strokeWidth={3} /> : <Plus size={30} strokeWidth={3} />}
                </motion.button>
              </div>

              <TabButton active={activeTab === Tab.Manage} icon={isProvider ? <DollarSign size={24} /> : <Calendar size={24} />} label={isProvider ? "MONEY" : "ORDERS"} onClick={() => {setActiveTab(Tab.Manage); setFabOpen(false);}} />
              <TabButton active={[Tab.More, Tab.ToolsHome, Tab.Onboarding].includes(activeTab)} icon={<LayoutGrid size={24} />} label="MORE" onClick={() => {setActiveTab(Tab.More); setFabOpen(false);}} />
            </nav>
          </div>
        </div>

        <AIChat isOpen={aiOpen} onClose={() => setAiOpen(false)} isDarkMode={isDarkMode} />
      </div>
    </div>
  );
};

const TabButton: React.FC<{ active: boolean; icon: React.ReactNode; label: string; onClick: () => void }> = ({ active, icon, label, onClick }) => (
  <button 
    onClick={onClick}
    className={`flex flex-col items-center gap-1 transition-all duration-300 px-1 ${
      active ? 'text-homebase' : 'text-dim opacity-40 hover:opacity-100'
    }`}
  >
    <div className="transition-transform duration-300">{icon}</div>
    <span className={`text-[8px] font-black uppercase tracking-widest leading-none transition-all ${active ? 'opacity-100' : 'opacity-0 scale-75'}`}>
      {label}
    </span>
  </button>
);

export default App;
