
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronDown, Check, Sparkles as SparkleIcon, Home, Briefcase, ChevronRight, TrendingUp } from 'lucide-react';
import { HomeProfile, ProfileType } from '../types';

export const SuccessSparkle: React.FC<{ active: boolean }> = ({ active }) => (
  <AnimatePresence>
    {active && (
      <div className="absolute inset-0 pointer-events-none flex items-center justify-center overflow-hidden z-[500]">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ scale: 0, opacity: 1, x: 0, y: 0 }}
            animate={{ 
              scale: [0, 1.2, 0], 
              opacity: [0, 1, 0],
              x: (Math.random() - 0.5) * 300,
              y: (Math.random() - 0.5) * 300,
              rotate: Math.random() * 360 
            }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="absolute"
          >
            <SparkleIcon size={Math.random() * 20 + 10} className="text-homebase" fill="currentColor" />
          </motion.div>
        ))}
      </div>
    )}
  </AnimatePresence>
);

export const GlassCard: React.FC<{
  children: React.ReactNode;
  className?: string;
  animate?: boolean;
  onClick?: () => void;
  index?: number;
}> = ({ children, className = '', animate = true, onClick, index = 0 }) => (
  <motion.div
    initial={animate ? { opacity: 0, y: 15 } : false}
    whileInView={animate ? { opacity: 1, y: 0 } : false}
    whileTap={onClick ? { scale: 0.985 } : undefined}
    viewport={{ once: true }}
    transition={{ type: 'spring', damping: 25, stiffness: 200, delay: animate ? index * 0.03 : 0 }}
    onClick={onClick}
    className={`liquid-glass rounded-4xl p-6 relative overflow-hidden ${className}`}
  >
    <div className="absolute inset-0 shimmer opacity-20 pointer-events-none" />
    {children}
  </motion.div>
);

export const GlassButton: React.FC<{
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'outline';
  className?: string;
  disabled?: boolean;
}> = ({ children, onClick, variant = 'primary', className = '', disabled }) => (
  <motion.button
    whileTap={!disabled ? { scale: 0.97 } : undefined}
    onClick={onClick}
    disabled={disabled}
    className={`w-full py-4.5 rounded-2xl font-black flex items-center justify-center gap-2 transition-all relative overflow-hidden ${
      disabled ? 'opacity-30 grayscale cursor-not-allowed' : ''
    } ${
      variant === 'primary' 
        ? 'bg-homebase text-white shadow-lg fab-glow' 
        : variant === 'secondary'
        ? 'bg-white/[0.04] text-main border border-white/[0.03]'
        : variant === 'outline'
        ? 'bg-transparent border border-white/10 text-main'
        : 'text-dim'
    } ${className}`}
  >
    <span className="relative z-10 flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] italic">{children}</span>
  </motion.button>
);

export const StatusPill: React.FC<{ status: string }> = ({ status }) => {
  const getColors = () => {
    switch (status.toUpperCase()) {
      case 'UPCOMING': case 'SCHEDULED': return 'bg-homebase/10 text-homebase border-homebase/10';
      case 'IN PROGRESS': return 'bg-orange-500/10 text-orange-400 border-orange-500/10';
      case 'UNPAID': return 'bg-red-500/10 text-red-400 border-red-500/10';
      default: return 'bg-white/[0.04] text-dim border-white/5';
    }
  };
  return (
    <span className={`px-2.5 py-1 rounded-lg text-[8px] font-black uppercase tracking-widest border ${getColors()}`}>
      {status}
    </span>
  );
};

export const Chip: React.FC<{
  label: string;
  active: boolean;
  onClick: () => void;
}> = ({ label, active, onClick }) => (
  <motion.button
    whileTap={{ scale: 0.96 }}
    onClick={onClick}
    className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
      active 
        ? 'bg-homebase text-white shadow-lg' 
        : 'bg-white/[0.03] text-dim border border-white/[0.02]'
    }`}
  >
    {label}
  </motion.button>
);

export const MetricCard: React.FC<{
  label: string;
  value: string;
  icon: React.ReactNode;
  trend?: string;
  index: number;
}> = ({ label, value, icon, trend, index }) => (
  <GlassCard index={index} className="flex flex-col justify-between h-40 border-white/[0.02]">
    <div className="flex items-center justify-between">
      <div className="p-3 rounded-2xl bg-white/[0.02] text-homebase/80">
        {icon}
      </div>
      {trend && (
        <div className="flex items-center gap-1 text-homebase font-black text-[10px] italic">
          <TrendingUp size={12} /> {trend}
        </div>
      )}
    </div>
    <div>
      <h2 className="text-3xl font-black text-main leading-none italic tracking-tighter mb-2">{value}</h2>
      <p className="text-dim text-[8px] font-black uppercase tracking-[0.25em] opacity-30">{label}</p>
    </div>
  </GlassCard>
);

export const AttentionCard: React.FC<{
  title: string;
  subtitle: string;
  status: string;
}> = ({ title, subtitle, status }) => (
  <div className="min-w-[260px] p-6 rounded-[2.5rem] bg-white/[0.02] border border-white/[0.02] flex flex-col justify-between h-36">
    <div>
      <p className="text-dim text-[8px] font-black uppercase tracking-[0.2em] opacity-30 mb-2">{title}</p>
      <p className="text-main font-bold text-base leading-tight italic tracking-tight">{subtitle}</p>
    </div>
    <div className="flex">
      <StatusPill status={status} />
    </div>
  </div>
);

export const RevenueChart: React.FC = () => (
  <div className="w-full h-40 flex items-end justify-between gap-1.5 px-2">
    {[30, 15, 90, 40, 50, 45, 42].map((h, i) => (
      <div key={i} className="flex-1 flex flex-col items-center gap-3">
        <motion.div 
          initial={{ height: 0 }}
          animate={{ height: `${h}%` }}
          transition={{ duration: 1.2, delay: i * 0.1, ease: "circOut" }}
          className={`w-full max-w-[24px] rounded-t-xl ${h > 60 ? 'bg-homebase' : 'bg-homebase/30'}`}
        />
        <span className="text-[9px] font-black text-dim uppercase opacity-20">{"MTWTFSS"[i]}</span>
      </div>
    ))}
  </div>
);

export const AccountCard: React.FC<{
  name: string;
  email: string;
  profileType: ProfileType;
  onClick: () => void;
}> = ({ name, email, profileType, onClick }) => (
  <motion.div
    whileTap={{ scale: 0.985 }}
    onClick={onClick}
    className="liquid-glass rounded-5xl p-6 relative overflow-hidden group cursor-pointer premium-glow border-white/[0.02]"
  >
    <div className="flex items-center gap-5 relative z-10">
      <div className="w-16 h-16 rounded-full p-0.5 bg-homebase/5 overflow-hidden border border-homebase/10 shadow-inner">
        <img src="https://picsum.photos/100/100?0" className="w-full h-full rounded-full object-cover" alt="Avatar" />
      </div>
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <h3 className="text-main font-bold text-xl italic tracking-tighter leading-none">{name}</h3>
          <ChevronRight size={16} className="text-dim/20 group-hover:text-homebase transition-all" />
        </div>
        <p className="text-dim text-xs font-medium mt-1 mb-2 opacity-30">{email}</p>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-homebase/10 text-homebase text-[8px] font-black tracking-widest uppercase italic">
          {profileType === ProfileType.Homeowner ? <Home size={10} /> : <Briefcase size={10} />}
          {profileType}
        </div>
      </div>
    </div>
  </motion.div>
);

export const ProfileOption: React.FC<{
  type: ProfileType;
  description: string;
  active: boolean;
  status?: string;
  onClick: () => void;
}> = ({ type, description, active, status, onClick }) => (
  <motion.button
    whileTap={active ? undefined : { scale: 0.975 }}
    onClick={onClick}
    className={`w-full text-left p-6 rounded-[2.5rem] border transition-all flex items-center justify-between group relative overflow-hidden ${
      active 
        ? 'bg-homebase/5 border-homebase/20' 
        : 'bg-white/[0.01] border-transparent'
    }`}
  >
    <div className="flex items-center gap-5">
      <div className={`w-14 h-14 rounded-3xl flex items-center justify-center transition-all ${
        active ? 'bg-homebase text-white shadow-lg' : 'bg-white/[0.03] text-dim'
      }`}>
        {type === ProfileType.Homeowner ? <Home size={24} /> : <Briefcase size={24} />}
      </div>
      <div>
        <h4 className={`text-lg font-black italic tracking-tighter mb-1 ${active ? 'text-main' : 'text-dim group-hover:text-main'}`}>
          {type}
        </h4>
        <p className="text-dim text-[11px] font-medium leading-tight max-w-[180px] opacity-30">{description}</p>
      </div>
    </div>
    <div className={`w-6 h-6 rounded-full border flex items-center justify-center transition-all ${
      active ? 'bg-homebase border-homebase' : 'border-white/10'
    }`}>
      {active && <Check size={12} className="text-white" strokeWidth={3} />}
    </div>
  </motion.button>
);

export const GlassSheet: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  height?: string;
}> = ({ isOpen, onClose, title, subtitle, children, height = 'h-[85%]' }) => (
  <AnimatePresence>
    {isOpen && (
      <>
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 z-[200] bg-black/70 blur-overlay"
        />
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 28, stiffness: 220 }}
          className={`fixed bottom-0 left-0 right-0 z-[201] ${height} liquid-glass-heavy rounded-t-[3.5rem] flex flex-col mx-auto max-w-[430px]`}
        >
          <div className="w-10 h-1 bg-white/20 rounded-full mx-auto mt-5 mb-1 opacity-10" />
          <div className="px-10 py-8">
            {title && <h3 className="text-3xl font-black text-main italic tracking-tighter leading-none mb-2">{title}</h3>}
            {subtitle && <p className="text-dim text-sm font-medium leading-relaxed opacity-30">{subtitle}</p>}
          </div>
          <div className="flex-1 overflow-y-auto px-10 pb-32 no-scrollbar">
            {children}
          </div>
          <motion.button whileTap={{ scale: 0.9 }} onClick={onClose} className="absolute top-6 right-8 p-3 rounded-full bg-white/[0.04] text-dim">
            <X size={20} />
          </motion.button>
        </motion.div>
      </>
    )}
  </AnimatePresence>
);

export const GlassHeader: React.FC<{
  children: React.ReactNode;
  className?: string;
}> = ({ children, className = '' }) => (
  <header className={`px-7 py-6 shrink-0 z-50 ${className}`}>
    {children}
  </header>
);

export const HomeSelector: React.FC<{
  homes: HomeProfile[];
  activeHome: HomeProfile;
  onSelect: (h: HomeProfile) => void;
}> = ({ homes, activeHome, onSelect }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="relative">
      <motion.button
        whileTap={{ scale: 0.96 }}
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 bg-white/[0.03] border border-white/[0.02] rounded-2xl"
      >
        <span className="text-[10px] font-black uppercase tracking-widest text-main italic">{activeHome.nickname}</span>
        <ChevronDown size={14} className="text-dim opacity-30" />
      </motion.button>
      <AnimatePresence>
        {isOpen && (
          <>
            <div className="fixed inset-0 z-[100]" onClick={() => setIsOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute top-full right-0 mt-3 w-48 bg-surface border border-white/10 rounded-3xl shadow-2xl z-[101] overflow-hidden backdrop-blur-3xl"
            >
              {homes.map(home => (
                <button
                  key={home.id}
                  onClick={() => { onSelect(home); setIsOpen(false); }}
                  className="w-full px-5 py-4 text-left hover:bg-white/[0.05] transition-colors flex items-center justify-between"
                >
                  <span className="text-xs font-bold text-main">{home.nickname}</span>
                  {home.id === activeHome.id && <Check size={14} className="text-homebase" />}
                </button>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

// Fixed: Exported GlassListRow component
export const GlassListRow: React.FC<{
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  trailing?: React.ReactNode;
  onClick?: () => void;
  className?: string;
}> = ({ title, subtitle, icon, trailing, onClick, className = '' }) => (
  <motion.button
    whileTap={onClick ? { scale: 0.98 } : undefined}
    onClick={onClick}
    className={`w-full flex items-center justify-between p-5 rounded-2xl bg-white/[0.02] border border-white/[0.04] hover:bg-white/[0.04] transition-all group ${className}`}
  >
    <div className="flex items-center gap-4">
      {icon && (
        <div className="w-10 h-10 rounded-xl bg-white/[0.02] flex items-center justify-center text-homebase border border-white/[0.04] shadow-inner">
          {icon}
        </div>
      )}
      <div className="text-left">
        <p className="text-main font-bold text-sm italic leading-none">{title}</p>
        {subtitle && <p className="text-dim text-[10px] font-medium mt-1.5 opacity-30">{subtitle}</p>}
      </div>
    </div>
    {trailing && <div className="text-dim">{trailing}</div>}
  </motion.button>
);

// Fixed: Exported PremiumBadge component
export const PremiumBadge: React.FC<{ label: string }> = ({ label }) => (
  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-homebase/10 text-homebase border border-homebase/20 shadow-sm">
    <SparkleIcon size={10} fill="currentColor" />
    <span className="text-[8px] font-black uppercase tracking-widest italic">{label}</span>
  </div>
);

// Fixed: Exported SocialShareModal component
export const SocialShareModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  title: string;
  subtitle: string;
  stats: { label: string; value: string }[];
}> = ({ isOpen, onClose, title, subtitle, stats }) => (
  <GlassSheet isOpen={isOpen} onClose={onClose} title="Share Achievement" height="h-[60%]">
    <div className="space-y-8 pt-4">
      <div className="p-8 rounded-[3rem] bg-gradient-to-br from-homebase/20 via-surface to-transparent border border-homebase/20 relative overflow-hidden shadow-2xl">
         <div className="absolute top-0 right-0 p-6 opacity-10">
            <SparkleIcon size={40} className="text-homebase" />
         </div>
         <div className="relative z-10 text-center">
            <h4 className="text-dim text-[10px] font-black uppercase tracking-[0.4em] mb-4">{title}</h4>
            <h3 className="text-3xl font-black text-main italic tracking-tighter leading-none mb-8">{subtitle}</h3>
            <div className="grid grid-cols-3 gap-4">
               {stats.map((s, i) => (
                 <div key={i} className="flex flex-col items-center">
                    <span className="text-main font-black text-xl italic">{s.value}</span>
                    <span className="text-[8px] font-bold text-dim uppercase tracking-widest mt-1 opacity-40">{s.label}</span>
                 </div>
               ))}
            </div>
         </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
         <GlassButton variant="secondary" className="h-16">Download Image</GlassButton>
         <GlassButton className="h-16">Copy Link</GlassButton>
      </div>
    </div>
  </GlassSheet>
);
