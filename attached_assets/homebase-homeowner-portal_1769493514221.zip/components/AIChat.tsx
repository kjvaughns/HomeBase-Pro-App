import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Sparkles, Image, Check, ChevronRight, Star, ExternalLink, Loader2 } from 'lucide-react';
import { GlassButton } from './Shared';
import { GoogleGenAI } from "@google/genai";

interface AIChatProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode?: boolean;
}

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  links?: { title: string; url: string }[];
}

const AIChat: React.FC<AIChatProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Hello! I'm your property intelligence assistant. I can help you find verified specialists nearby using live Google Maps data. What can I help you with today?" }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const getUserLocation = (): Promise<{ latitude: number, longitude: number } | null> => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve(null);
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
        () => resolve(null)
      );
    });
  };

  const handleSend = async (textOverride?: string) => {
    const text = textOverride || inputValue;
    if (!text.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', text };
    setMessages(prev => [...prev, userMsg]);
    setInputValue('');
    setIsLoading(true);

    try {
      const location = await getUserLocation();
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: text,
        config: {
          systemInstruction: "You are HomeBase AI, a premium property management assistant. Use Google Maps to find real, local service providers (plumbers, electricians, etc.) based on the user's location. Provide specific business names and explain why they are good matches. Always be professional and concise.",
          tools: [{ googleSearch: {} }, { googleMaps: {} }],
          toolConfig: location ? {
            retrievalConfig: {
              latLng: {
                latitude: location.latitude,
                longitude: location.longitude
              }
            }
          } : undefined
        },
      });

      const groundingLinks: { title: string; url: string }[] = [];
      const metadata = response.candidates?.[0]?.groundingMetadata;
      
      if (metadata?.groundingChunks) {
        metadata.groundingChunks.forEach((chunk: any) => {
          if (chunk.maps?.uri) {
            groundingLinks.push({
              title: chunk.maps.title || "View on Maps",
              url: chunk.maps.uri
            });
          } else if (chunk.web?.uri) {
            groundingLinks.push({
              title: chunk.web.title || "Learn More",
              url: chunk.web.uri
            });
          }
        });
      }

      const modelMsg: ChatMessage = {
        role: 'model',
        text: response.text || "I'm sorry, I couldn't find any information on that. Try being more specific about the service you need.",
        links: groundingLinks.length > 0 ? groundingLinks : undefined
      };

      setMessages(prev => [...prev, modelMsg]);
    } catch (error) {
      console.error("AI Chat Error:", error);
      setMessages(prev => [...prev, { role: 'model', text: "I'm having trouble connecting to the property intelligence network. Please try again in a moment." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          className="absolute inset-0 z-[200] flex flex-col bg-app overflow-hidden"
        >
          {/* Header Area */}
          <div className="relative flex items-center justify-between px-8 pt-16 pb-7 border-b border-main/10 bg-surface/80 backdrop-blur-3xl shrink-0">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-homebase rounded-2xl shadow-xl shadow-homebase/40">
                <Sparkles size={20} className="text-white" fill="currentColor" />
              </div>
              <div>
                <h2 className="text-xl font-black text-main leading-none italic tracking-tight">Intelligence Assistant</h2>
                <div className="flex items-center gap-2 mt-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-homebase animate-pulse" />
                  <span className="text-homebase text-[10px] font-black uppercase tracking-[0.2em]">Live Grounding Active</span>
                </div>
              </div>
            </div>
            <motion.button 
              whileTap={{ scale: 0.9 }} 
              onClick={onClose} 
              className="p-3 rounded-full bg-main/5 text-dim hover:bg-main/10 transition-colors shadow-sm"
            >
              <X size={20} />
            </motion.button>
          </div>

          {/* Discussion View */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-7 pt-9 space-y-7 no-scrollbar pb-12">
            {messages.map((msg, i) => (
              <motion.div 
                key={i} 
                initial={{ opacity: 0, y: 15, scale: 0.98 }} 
                animate={{ opacity: 1, y: 0, scale: 1 }}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`max-w-[88%] p-6 rounded-[2rem] ${
                  msg.role === 'user' 
                    ? 'bg-homebase text-white rounded-br-none shadow-2xl shadow-homebase/20 border border-white/10' 
                    : 'liquid-glass rounded-bl-none border-main/10 shadow-xl'
                }`}>
                  <p className={`text-[14px] leading-relaxed ${msg.role === 'user' ? 'font-black italic tracking-tight' : 'text-main font-medium'}`}>
                    {msg.text}
                  </p>
                  
                  {msg.links && msg.links.length > 0 && (
                    <div className="mt-5 pt-5 border-t border-main/10 space-y-2.5">
                      <p className="text-[9px] font-black uppercase tracking-[0.3em] text-homebase mb-3">Grounding Sources</p>
                      {msg.links.map((link, li) => (
                        <a 
                          key={li} 
                          href={link.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center justify-between p-4 rounded-2xl bg-main/5 border border-main/10 hover:bg-main/10 transition-all group"
                        >
                          <span className="text-[12px] font-black text-main truncate pr-4 italic">{link.title}</span>
                          <ExternalLink size={14} className="text-homebase shrink-0 group-hover:scale-110 transition-transform" />
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
            
            {isLoading && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
                <div className="liquid-glass rounded-3xl rounded-bl-none p-5 flex items-center gap-3 shadow-md">
                  <Loader2 size={16} className="text-homebase animate-spin" />
                  <span className="text-[10px] font-black text-dim uppercase tracking-[0.2em]">Synchronizing Data...</span>
                </div>
              </motion.div>
            )}
          </div>

          {/* Tactile Interaction Bar */}
          <div className="px-7 pt-6 pb-32 border-t border-main/10 bg-surface/95 backdrop-blur-3xl relative z-10 shadow-[0_-20px_50px_rgba(0,0,0,0.1)] shrink-0">
            <div className="space-y-6">
              {!isLoading && messages.length < 3 && (
                <div className="flex flex-wrap gap-2.5">
                  {[
                    "Local specialists",
                    "Emergency plumbers",
                    "AC repair search"
                  ].map(suggestion => (
                    <button
                      key={suggestion}
                      onClick={() => handleSend(suggestion)}
                      className="px-5 py-2.5 rounded-full bg-main/5 border border-main/10 text-main text-[10px] font-black uppercase tracking-widest italic hover:bg-homebase hover:text-white hover:border-homebase transition-all shadow-sm"
                    >
                      {suggestion}
                    </button>
                  ))}
                </div>
              )}
              
              <div className="flex items-center gap-4">
                <div className="flex-1 relative">
                  <input 
                    type="text" 
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Describe your property issue..." 
                    className="w-full ios-search-bg border border-main/10 rounded-2xl py-4.5 px-6 text-main font-bold focus:outline-none focus:border-homebase/50 text-[14px] transition-all placeholder:text-main/20 shadow-inner"
                  />
                  <motion.button 
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleSend()}
                    disabled={isLoading || !inputValue.trim()}
                    className={`absolute right-3 top-1/2 -translate-y-1/2 p-2.5 rounded-xl transition-all ${
                      inputValue.trim() ? 'bg-homebase text-white shadow-xl shadow-homebase/30' : 'text-dim opacity-30'
                    }`}
                  >
                    <Send size={20} strokeWidth={3} />
                  </motion.button>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default AIChat;