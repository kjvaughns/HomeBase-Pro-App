
import React from 'react';
import { motion } from 'framer-motion';
import { Bell, Sun, DollarSign, Briefcase, Users, Calendar, ChevronRight, ArrowRight } from 'lucide-react';
import { GlassCard, StatusPill, MetricCard, AttentionCard } from '../components/Shared';

interface ProviderHomeProps {
  onOpenAI: () => void;
  onNavigate: (tab: any) => void;
}

const ATTENTION = [
  { id: '1', title: 'PAYMENTS', subtitle: 'Unpaid Invoice #1024', status: 'UNPAID' },
  { id: '2', title: 'LOGISTICS', subtitle: 'Confirm Appointment', status: 'UPCOMING' }
];

const METRICS = [
  { label: 'REVENUE MTD', value: '$12,450', icon: <DollarSign size={20} />, trend: '+14%' },
  { label: 'JOBS DONE', value: '38', icon: <Briefcase size={20} />, trend: '+8%' },
  { label: 'CLIENTS', value: '112', icon: <Users size={20} /> },
  { label: 'ACTIVE', value: '14', icon: <Calendar size={20} /> }
];

const ProviderHome: React.FC<ProviderHomeProps> = ({ onNavigate }) => {
  return (
    <div className="absolute inset-0 flex flex-col gap-10 pb-48 overflow-y-auto no-scrollbar pt-14 bg-app">
      <section className="px-7 flex items-center justify-between shrink-0">
        <div>
          <h1 className="text-3xl font-black text-main leading-none italic tracking-tighter mb-2">Good Morning</h1>
          <p className="text-homebase text-[10px] font-black uppercase tracking-[0.3em] opacity-40 italic">CLEAN & CO. LLC</p>
        </div>
        <div className="flex gap-2.5">
          <motion.button whileTap={{ scale: 0.92 }} className="w-12 h-12 rounded-2xl bg-white/[0.03] flex items-center justify-center text-main border border-white/[0.02]">
            <Bell size={20} />
          </motion.button>
        </div>
      </section>

      <section className="shrink-0 overflow-visible">
        <div className="flex gap-4 overflow-x-auto px-7 no-scrollbar">
          {ATTENTION.map(item => (
            <AttentionCard key={item.id} title={item.title} subtitle={item.subtitle} status={item.status} />
          ))}
        </div>
      </section>

      <section className="px-7 shrink-0 grid grid-cols-2 gap-4">
        {METRICS.map((stat, i) => (
          <MetricCard key={i} index={i} label={stat.label} value={stat.value} icon={stat.icon} trend={stat.trend} />
        ))}
      </section>

      <section className="px-7 space-y-6 pb-12">
        <div className="flex items-center justify-between px-2">
          <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] opacity-30">LIVE SCHEDULE</h3>
          <button className="text-homebase text-[10px] font-black uppercase tracking-widest italic flex items-center gap-1.5">
            Full View <ArrowRight size={14} />
          </button>
        </div>
        
        <GlassCard className="p-6 border-white/[0.02] flex items-center gap-5">
           <div className="w-16 h-16 bg-white/[0.03] rounded-3xl flex flex-col items-center justify-center border border-white/[0.05] shadow-inner">
              <span className="text-main font-black text-lg italic tracking-tighter">09:00</span>
           </div>
           <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-main font-bold text-lg leading-none italic">Sarah Miller</h4>
                <span className="text-homebase text-[11px] font-black italic">$180</span>
              </div>
              <p className="text-dim text-[11px] font-medium opacity-30">Deep Clean • SF Heights</p>
              <div className="flex mt-3">
                <StatusPill status="IN PROGRESS" />
              </div>
           </div>
        </GlassCard>
      </section>
    </div>
  );
};

export default ProviderHome;
