
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HeartPulse, ChevronLeft, X, Activity, Droplets, Zap, ShieldCheck, Thermometer, ArrowRight, Sparkles, Share2 } from 'lucide-react';
import { GlassCard, GlassHeader, GlassButton, StatusPill, SuccessSparkle, PremiumBadge, SocialShareModal } from '../components/Shared';
import { HomeProfile } from '../types';

interface HomeHealthProps {
  onBack: () => void;
  activeHome: HomeProfile;
}

const HomeHealthScore: React.FC<HomeHealthProps> = ({ onBack, activeHome }) => {
  const [step, setStep] = useState(0); // 0: Intro, 1: Assessment, 2: Results, 3: History
  const [score, setScore] = useState(0);
  const [isSharing, setIsSharing] = useState(false);
  const targetScore = 85;

  useEffect(() => {
    if (step === 2) {
      const interval = setInterval(() => {
        setScore(prev => {
          if (prev < targetScore) return prev + 1;
          clearInterval(interval);
          return targetScore;
        });
      }, 20);
      return () => clearInterval(interval);
    } else {
      setScore(0);
    }
  }, [step]);

  if (step === 0) {
    return (
      <div className="absolute inset-0 z-[110] bg-app flex flex-col items-center justify-center p-8 text-center">
        <div className="absolute top-12 left-6 pt-4">
           <motion.button whileTap={{ scale: 0.9 }} onClick={onBack} className="p-2 bg-main/5 rounded-full text-dim">
             <ChevronLeft size={20} />
           </motion.button>
        </div>
        <motion.div 
          animate={{ scale: [1, 1.1, 1] }} 
          transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          className="w-24 h-24 bg-red-400/10 rounded-full border-2 border-red-400 flex items-center justify-center mb-8 shadow-xl relative"
        >
          <HeartPulse size={48} className="text-red-400" />
          <motion.div 
            animate={{ opacity: [0, 0.3, 0], scale: [1, 1.5, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute inset-0 bg-red-400 rounded-full"
          />
        </motion.div>
        <h1 className="text-4xl font-black text-main mb-4 tracking-tighter italic leading-none">Home Health<br/>Diagnostic</h1>
        <p className="text-dim mb-12 max-w-[280px] text-sm font-medium">Quantify your property's vitality using AI-driven telemetry and historical maintenance data.</p>
        <div className="w-full space-y-4">
           <GlassButton onClick={() => setStep(1)}>Run New Assessment</GlassButton>
           <button onClick={() => setStep(3)} className="text-dim text-[10px] font-black uppercase tracking-[0.3em] hover:text-homebase transition-colors py-2">Audit History</button>
        </div>
      </div>
    );
  }

  if (step === 1) {
    return (
      <div className="absolute inset-0 z-[110] bg-app flex flex-col">
        <GlassHeader className="bg-transparent border-0 flex items-center justify-between pt-8">
           <motion.button whileTap={{ scale: 0.9 }} onClick={() => setStep(0)} className="p-2 bg-main/5 rounded-full text-dim"><ChevronLeft size={20} /></motion.button>
           <h3 className="text-xs font-black uppercase tracking-[0.2em] text-main">System Checkup</h3>
           <div className="w-10" />
        </GlassHeader>
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-8 no-scrollbar">
           <div className="space-y-1">
             <h3 className="text-3xl font-black text-main leading-none tracking-tighter italic">Current Vitality</h3>
             <p className="text-dim text-sm font-medium italic">Calibration via HomeBase sensors</p>
           </div>
           
           <div className="space-y-6">
              <div className="space-y-4">
                <label className="text-dim text-[10px] font-black uppercase tracking-widest ml-2">Observed Symptoms</label>
                <div className="flex flex-wrap gap-2">
                  {['Leaking Faucet', 'Slow Drain', 'AC Noise', 'Dim Lights', 'Cracks'].map((s, i) => (
                    <motion.button 
                      initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: i * 0.1 }}
                      whileTap={{ scale: 0.9 }} key={s} 
                      className="px-4 py-2 rounded-xl bg-main/5 border border-main/10 text-[10px] font-bold text-dim hover:border-homebase hover:bg-homebase/10 hover:text-homebase transition-all shadow-sm"
                    >
                      {s}
                    </motion.button>
                  ))}
                </div>
              </div>

              <div className="space-y-4 pt-6 border-t border-main/5">
                <label className="text-dim text-[10px] font-black uppercase tracking-widest ml-2">Routine Maintenance</label>
                <div className="space-y-3">
                   {['Regular filter swaps', 'Annual roof checks', 'Smoke alarm tests'].map((q, i) => (
                     <motion.div 
                        initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }}
                        key={q} className="flex items-center justify-between p-4 liquid-glass rounded-2xl shadow-sm"
                     >
                        <span className="text-main font-bold text-sm italic">{q}</span>
                        <div className="w-12 h-7 bg-homebase rounded-full p-1 flex justify-end shadow-inner">
                           <div className="w-5 h-5 bg-white rounded-full shadow-lg" />
                        </div>
                     </motion.div>
                   ))}
                </div>
              </div>
           </div>
        </div>
        <div className="p-6 pt-4 pb-12 bg-surface/80 backdrop-blur-2xl border-t border-main/5">
           <GlassButton onClick={() => setStep(2)}>Generate Health Report</GlassButton>
        </div>
      </div>
    );
  }

  if (step === 2) {
    return (
      <div className="absolute inset-0 z-[110] bg-app flex flex-col overflow-hidden">
        <SuccessSparkle active={score === targetScore} />
        <SocialShareModal 
           isOpen={isSharing} 
           onClose={() => setIsSharing(false)} 
           title="My Home Health Score"
           subtitle={activeHome.nickname}
           stats={[
             { label: 'Overall Score', value: `${score}/100` },
             { label: 'Safety Rating', value: 'Excellent' },
             { label: 'Efficiency', value: '81%' }
           ]}
        />
        
        <GlassHeader className="bg-transparent border-0 flex items-center justify-between pt-8">
           <motion.button whileTap={{ scale: 0.9 }} onClick={() => setStep(0)} className="p-2 bg-main/5 rounded-full text-dim"><X size={20} /></motion.button>
           <h3 className="text-xs font-black uppercase tracking-[0.2em] text-main">Results Card</h3>
           <motion.button whileTap={{ scale: 0.9 }} onClick={() => setIsSharing(true)} className="p-2 bg-homebase/10 rounded-full text-homebase border border-homebase/20"><Share2 size={20} /></motion.button>
        </GlassHeader>
        
        <div className="flex-1 overflow-y-auto px-6 py-4 no-scrollbar">
           <div className="flex flex-col items-center justify-center py-10 mb-8 relative">
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute -top-4 z-20"
              >
                <PremiumBadge label="Premium Property" />
              </motion.div>
              
              <div className="relative flex items-center justify-center">
                 <div className="absolute inset-0 bg-homebase/10 blur-[80px] rounded-full" />
                 <svg className="w-64 h-64 -rotate-90 relative z-10">
                    <circle cx="128" cy="128" r="110" stroke="var(--inner-highlight)" strokeWidth="18" fill="transparent" />
                    <motion.circle 
                      cx="128" cy="128" r="110" 
                      stroke="#0FAF6E" strokeWidth="18" 
                      fill="transparent" 
                      strokeDasharray="691"
                      initial={{ strokeDashoffset: 691 }}
                      animate={{ strokeDashoffset: 691 - (targetScore/100 * 691) }}
                      transition={{ duration: 2.5, ease: [0.22, 1, 0.36, 1], delay: 0.3 }}
                      strokeLinecap="round"
                      className="drop-shadow-[0_0_12px_rgba(15,175,110,0.4)]"
                    />
                 </svg>
                 <div className="absolute inset-0 flex flex-col items-center justify-center z-20">
                    <motion.span 
                      key={score}
                      initial={{ scale: 0.5, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="text-8xl font-black text-main italic tracking-tighter"
                    >
                      {score}
                    </motion.span>
                    <motion.div 
                      initial={{ y: 10, opacity: 0 }}
                      animate={{ y: 0, opacity: score === targetScore ? 1 : 0 }}
                      className="flex flex-col items-center"
                    >
                      <span className="text-[10px] font-black text-homebase uppercase tracking-[0.4em] leading-none">Vitality Index</span>
                      <div className="mt-2 flex gap-1">
                        {[1,2,3,4,5].map(i => <Sparkles key={i} size={8} className="text-homebase" fill="currentColor" />)}
                      </div>
                    </motion.div>
                 </div>
              </div>
           </div>

           <div className="grid grid-cols-2 gap-4 mb-10">
              {[
                { label: 'Safety', val: 92, icon: <ShieldCheck size={14} className="text-homebase" />, color: 'from-homebase/20' },
                { label: 'Water', val: 78, icon: <Droplets size={14} className="text-blue-400" />, color: 'from-blue-400/20' },
                { label: 'Energy', val: 81, icon: <Zap size={14} className="text-yellow-500" />, color: 'from-yellow-500/20' },
                { label: 'System', val: 88, icon: <Activity size={14} className="text-red-400" />, color: 'from-red-400/20' },
              ].map((pillar, i) => (
                <GlassCard key={pillar.label} index={i} className={`p-6 border-main/5 bg-gradient-to-br ${pillar.color} to-transparent relative overflow-hidden shadow-md`}>
                   <div className="relative z-10">
                     <div className="flex items-center gap-2 mb-3">
                       {pillar.icon}
                       <span className="text-dim text-[9px] font-black uppercase tracking-widest">{pillar.label}</span>
                     </div>
                     <div className="flex items-end justify-between">
                       <span className="text-3xl font-black text-main italic">{pillar.val}</span>
                       <span className="text-[8px] font-bold text-dim uppercase">Pct</span>
                     </div>
                   </div>
                </GlassCard>
              ))}
           </div>

           <div className="space-y-4 mb-32">
              <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] ml-2">Smart Insights</h3>
              <GlassCard className="p-6 border-homebase/20 bg-homebase/5 shadow-xl">
                 <div className="flex justify-between items-start mb-4">
                    <h4 className="text-main font-black text-xl tracking-tight leading-none italic">Market Comparison</h4>
                    <PremiumBadge label="Top 5%" />
                 </div>
                 <p className="text-dim text-sm leading-relaxed mb-6 font-medium">"Alex, {activeHome.nickname} is currently outperforming most properties in San Francisco. Keeping your score above 80 adds significant resale protection."</p>
                 <GlassButton onClick={() => setIsSharing(true)} variant="secondary" className="h-12 border-main/10 text-[10px] uppercase tracking-widest font-black">Share Achievement</GlassButton>
              </GlassCard>
           </div>
        </div>
      </div>
    );
  }

  // History Screen
  return (
    <div className="absolute inset-0 z-[110] bg-app flex flex-col">
       <GlassHeader className="bg-transparent border-0 flex items-center gap-4 pt-8">
          <motion.button whileTap={{ scale: 0.9 }} onClick={() => setStep(0)} className="p-2 bg-main/5 rounded-full text-dim"><ChevronLeft size={20} /></motion.button>
          <h2 className="text-lg font-black text-main italic tracking-tight">Audit Logs</h2>
       </GlassHeader>
       <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 no-scrollbar pb-32">
          {[
            { date: 'Today, Oct 24', score: 85, status: 'Premium' },
            { date: 'Jul 15, 2023', score: 81, status: 'Optimal' },
            { date: 'Jan 10, 2023', score: 76, status: 'Stable' },
          ].map((h, i) => (
            <GlassCard key={i} index={i} className="p-6 flex items-center justify-between border-main/5 shadow-md">
               <div className="flex items-center gap-6">
                  <div className="w-16 h-16 bg-main/5 rounded-[1.5rem] flex items-center justify-center text-3xl font-black text-homebase border border-main/10 shadow-inner italic">
                    {h.score}
                  </div>
                  <div>
                    <p className="text-main font-bold text-base italic">{h.date}</p>
                    <p className="text-homebase text-[10px] font-black uppercase tracking-[0.2em]">{h.status}</p>
                  </div>
               </div>
               <ArrowRight size={20} className="text-dim/40" />
            </GlassCard>
          ))}
       </div>
    </div>
  );
};

export default HomeHealthScore;
