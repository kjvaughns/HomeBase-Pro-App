
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, X, Calendar, MapPin, Check, Sparkles, Clock, DollarSign, Camera, ArrowRight } from 'lucide-react';
import { GlassButton, GlassCard, GlassHeader, GlassListRow } from '../components/Shared';
import { Provider, Service } from '../types';

interface BookingFlowProps {
  provider: Provider;
  onClose: () => void;
  onComplete: () => void;
}

const STEPS = ['Select Service', 'Details', 'Clarify', 'Schedule', 'Confirm'];

const BookingFlow: React.FC<BookingFlowProps> = ({ provider, onClose, onComplete }) => {
  const [step, setStep] = useState(0);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);

  const nextStep = () => {
    if (step === STEPS.length - 1) {
      setShowSuccess(true);
    } else {
      setStep(prev => prev + 1);
    }
  };

  const prevStep = () => setStep(prev => Math.max(0, prev - 1));

  if (showSuccess) {
    return (
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        className="absolute inset-0 z-[110] bg-app flex flex-col items-center justify-center p-8 text-center"
      >
        <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} className="w-24 h-24 bg-homebase rounded-full flex items-center justify-center mb-8 shadow-[0_0_50px_rgba(15,175,110,0.4)]">
          <Check size={48} className="text-white" />
        </motion.div>
        <h2 className="text-3xl font-black text-main mb-4 italic tracking-tighter">Booking Confirmed!</h2>
        <p className="text-dim mb-12 font-medium leading-relaxed">Your appointment with <span className="text-main font-bold italic">{provider.name}</span> has been successfully scheduled. We've sent the details to your email.</p>
        <div className="w-full space-y-4 px-4">
          <GlassButton onClick={() => { onComplete(); onClose(); }} className="h-16 italic tracking-widest shadow-xl">View Appointment</GlassButton>
          <GlassButton variant="secondary" onClick={() => { onComplete(); onClose(); }} className="h-16 border-main/10 text-main italic">Add to Calendar</GlassButton>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="absolute inset-0 z-[110] bg-app flex flex-col">
      <GlassHeader className="flex items-center justify-between border-b-0 pt-12 bg-transparent">
        <button onClick={step === 0 ? onClose : prevStep} className="p-2 rounded-full bg-main/5 text-dim hover:text-main transition-colors">
          {step === 0 ? <X size={20} /> : <ChevronLeft size={20} />}
        </button>
        <div className="flex-1 px-8">
          <div className="flex gap-1.5 items-center justify-center mb-1 bg-main/5 p-1 rounded-full">
             {STEPS.map((_, i) => (
               <div key={i} className={`h-1 rounded-full flex-1 transition-all duration-500 ${i <= step ? 'bg-homebase shadow-[0_0_8px_rgba(15,175,110,0.5)]' : 'bg-transparent'}`} />
             ))}
          </div>
          <p className="text-[9px] font-black uppercase text-center text-dim tracking-[0.2em] mt-3">{STEPS[step]}</p>
        </div>
        <div className="w-10" />
      </GlassHeader>

      <div className="flex-1 overflow-y-auto px-6 py-6 no-scrollbar pb-40">
        <AnimatePresence mode="wait">
          {step === 0 && (
            <motion.div key="step0" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }} className="space-y-8">
              <div className="text-center space-y-2">
                <h3 className="text-3xl font-black text-main italic tracking-tighter leading-none">Job Request</h3>
                <p className="text-dim text-sm font-medium">Select the specific services needed.</p>
              </div>
              <div className="space-y-4">
                {(provider.serviceDetails || []).map((s) => (
                  <GlassCard 
                    key={s.id} 
                    className={`p-5 border-2 transition-all shadow-md ${selectedServices.includes(s.id) ? 'border-homebase bg-homebase/10' : 'border-main/5 hover:border-main/20'}`}
                    onClick={() => {
                      setSelectedServices(prev => prev.includes(s.id) ? prev.filter(id => id !== s.id) : [...prev, s.id]);
                    }}
                  >
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-black text-main text-base italic leading-tight">{s.name}</h4>
                        <div className="flex items-center gap-3 text-dim text-[10px] font-bold uppercase tracking-widest mt-2">
                          <span className="flex items-center gap-1"><Clock size={12} className="text-homebase" /> {s.duration}</span>
                          <span className="flex items-center gap-1"><DollarSign size={12} className="text-homebase" /> {s.price}</span>
                        </div>
                      </div>
                      <div className={`w-7 h-7 rounded-xl border-2 flex items-center justify-center transition-all ${selectedServices.includes(s.id) ? 'bg-homebase border-homebase shadow-lg shadow-homebase/20' : 'border-main/20'}`}>
                        {selectedServices.includes(s.id) && <Check size={16} className="text-white" strokeWidth={3} />}
                      </div>
                    </div>
                  </GlassCard>
                ))}
              </div>
            </motion.div>
          )}

          {step === 1 && (
            <motion.div key="step1" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
              <div className="text-center space-y-2">
                <h3 className="text-3xl font-black text-main italic tracking-tighter">Diagnostic Intel</h3>
                <p className="text-dim text-sm font-medium">Brief description of the problem site.</p>
              </div>
              <div className="space-y-6">
                <div className="space-y-3 px-2">
                  <label className="text-dim text-[10px] font-black uppercase tracking-[0.2em] ml-2">Job Description</label>
                  <textarea 
                    placeholder="E.g. The kitchen sink is leaking heavily from the main pipe..."
                    className="w-full bg-main/5 border border-main/10 rounded-[2rem] p-6 text-sm text-main font-medium focus:border-homebase transition-all min-h-[160px] outline-none shadow-inner"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <motion.button 
                    whileTap={{ scale: 0.95 }}
                    className="aspect-square bg-main/5 border-2 border-dashed border-main/10 rounded-[2rem] flex flex-col items-center justify-center gap-3 text-dim hover:bg-main/10 hover:text-homebase transition-all shadow-sm"
                  >
                    <div className="w-12 h-12 rounded-2xl bg-main/5 flex items-center justify-center"><Camera size={28} /></div>
                    <span className="text-[10px] font-black uppercase tracking-widest">Add Media</span>
                  </motion.button>
                  <div className="flex-1" />
                </div>
              </div>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div key="step2" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="space-y-6">
              <div className="liquid-glass p-8 rounded-[3rem] border-homebase/30 bg-homebase/5 relative overflow-hidden shadow-2xl">
                <div className="absolute top-0 right-0 p-6 opacity-30">
                   <Sparkles className="text-homebase" size={32} />
                </div>
                <div className="flex items-center gap-2 mb-6">
                  <span className="w-2 h-2 rounded-full bg-homebase animate-pulse" />
                  <h3 className="text-[10px] font-black uppercase tracking-[0.3em] text-homebase">Live AI Refinement</h3>
                </div>
                <div className="space-y-6 mb-10">
                  <div className="bg-main/5 rounded-[2rem] rounded-bl-none p-6 text-main font-medium text-sm leading-relaxed border border-main/5 shadow-inner">
                    "I noticed you mentioned a 'heavy leak'. Is this causing any flooding currently, or is it contained to the cabinet? This helps me refine the priority score."
                  </div>
                  <div className="flex gap-3">
                    <button className="flex-1 py-4 rounded-2xl bg-homebase text-white text-xs font-black uppercase tracking-widest shadow-lg shadow-homebase/20 italic">Flood Risk</button>
                    <button className="flex-1 py-4 rounded-2xl bg-main/5 border border-main/10 text-main text-xs font-black uppercase tracking-widest italic">Contained</button>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-6 border-t border-main/10">
                  <p className="text-dim text-[10px] font-black uppercase tracking-widest">Refined Estimate</p>
                  <span className="text-homebase font-black text-2xl italic tracking-tighter leading-none">$150 - $220</span>
                </div>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div key="step3" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-8">
              <div className="text-center space-y-2">
                <h3 className="text-3xl font-black text-main italic tracking-tighter">Availability</h3>
                <p className="text-dim text-sm font-medium">Slots synced with {provider.name}</p>
              </div>
              <div className="space-y-10">
                <div className="liquid-glass p-6 rounded-[2.5rem] border-main/10 shadow-xl shadow-main/5">
                   <div className="grid grid-cols-7 gap-1 text-center mb-6">
                     {['M','T','W','T','F','S','S'].map((d, i) => <span key={i} className="text-[10px] font-black text-dim/40 uppercase tracking-widest">{d}</span>)}
                     {[...Array(28)].map((_, i) => (
                       <button key={i} className={`aspect-square flex items-center justify-center rounded-xl text-xs font-black transition-all ${i === 23 ? 'bg-homebase text-white shadow-lg shadow-homebase/20 italic' : 'text-main hover:bg-main/5'}`}>
                         {i + 1}
                       </button>
                     ))}
                   </div>
                </div>
                <div className="px-2">
                  <h4 className="text-dim text-[10px] font-black uppercase tracking-[0.2em] mb-4 ml-4">Available Times</h4>
                  <div className="grid grid-cols-3 gap-3">
                    {['9:00 AM', '11:00 AM', '1:30 PM', '3:00 PM', '4:30 PM'].map((t, i) => (
                      <button key={i} className={`py-4 rounded-2xl border font-black text-[10px] uppercase tracking-widest transition-all shadow-sm ${i === 1 ? 'border-homebase bg-homebase text-white italic shadow-lg shadow-homebase/20' : 'border-main/10 text-dim bg-main/5 hover:border-main/30'}`}>
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div key="step4" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
               <div className="text-center space-y-2">
                <h3 className="text-3xl font-black text-main italic tracking-tighter">Operational Check</h3>
                <p className="text-dim text-sm font-medium">Finalizing job specifications.</p>
              </div>
              <GlassCard className="p-8 space-y-8 border-homebase/10 shadow-2xl bg-gradient-to-br from-homebase/5 via-surface to-transparent">
                <div className="flex gap-5 items-center">
                  <div className="w-16 h-16 rounded-[1.5rem] border border-main/10 shadow-lg overflow-hidden bg-surface">
                    <img src={provider.logo} className="w-full h-full object-cover" alt="Pro" />
                  </div>
                  <div>
                    <h4 className="text-main font-black text-xl italic tracking-tight">{provider.name}</h4>
                    <p className="text-homebase text-[10px] font-black uppercase tracking-widest">Emergency Leak Specialist</p>
                  </div>
                </div>
                <div className="space-y-5 pt-4 border-t border-main/5">
                   <div className="flex items-center gap-4 text-main">
                      <div className="w-10 h-10 rounded-xl bg-main/5 flex items-center justify-center text-homebase shadow-inner"><Calendar size={18} /></div>
                      <span className="text-sm font-bold italic">Tomorrow, Oct 24 @ 11:00 AM</span>
                   </div>
                   <div className="flex items-center gap-4 text-main">
                      <div className="w-10 h-10 rounded-xl bg-main/5 flex items-center justify-center text-homebase shadow-inner"><MapPin size={18} /></div>
                      <span className="text-sm font-bold italic truncate">123 Emerald Heights, SF</span>
                   </div>
                </div>
                <div className="pt-6 border-t border-main/10 flex items-center justify-between">
                  <span className="text-dim text-[10px] font-black uppercase tracking-[0.2em]">Estimate</span>
                  <span className="text-main font-black text-3xl italic tracking-tighter leading-none">$150 - $220</span>
                </div>
              </GlassCard>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="absolute bottom-0 inset-x-0 p-6 pt-4 pb-32 bg-surface/90 backdrop-blur-3xl border-t border-main/5">
        <GlassButton 
          disabled={step === 0 && selectedServices.length === 0}
          onClick={nextStep} 
          className="shadow-[0_0_30px_rgba(15,175,110,0.3)] h-16 text-lg italic tracking-widest"
        >
          {step === STEPS.length - 1 ? 'Dispatch Pro' : 'Continue'}
          <ArrowRight size={22} className="ml-1" />
        </GlassButton>
      </div>
    </div>
  );
};

export default BookingFlow;
