
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  User, CreditCard, LogOut, ChevronRight, 
  Moon, Sun, Globe, ShieldCheck, HeartPulse, FileText, 
  PiggyBank, Settings, LogOut as LogOutIcon, MoreHorizontal
} from 'lucide-react';
import { GlassCard, AccountCard, GlassSheet, ProfileOption, GlassButton } from '../components/Shared';
import { Tab, ProfileType } from '../types';

interface MoreProps {
  onNavigate: (tab: Tab) => void;
  isDarkMode?: boolean;
  toggleTheme?: () => void;
  profileType: ProfileType;
  onSwitchProfile: (type: ProfileType) => void;
}

const More: React.FC<MoreProps> = ({ onNavigate, isDarkMode, toggleTheme, profileType, onSwitchProfile }) => {
  const [isSwitcherOpen, setIsSwitcherOpen] = useState(false);

  const TOOLS = [
    { id: Tab.SurvivalKit, title: 'Survival Kit', icon: <ShieldCheck size={22} className="text-homebase" /> },
    { id: Tab.HomeHealth, title: 'Health Score', icon: <HeartPulse size={22} className="text-red-500" /> },
    { id: Tab.HouseFax, title: 'HouseFax', icon: <FileText size={22} className="text-blue-500" /> },
    { id: Tab.BudgetSavings, title: 'Budget', icon: <PiggyBank size={22} className="text-emerald-500" /> },
  ];

  return (
    <div className="absolute inset-0 flex flex-col gap-10 pb-48 pt-16 overflow-y-auto no-scrollbar bg-app">
      {/* Account Section */}
      <section className="px-7 shrink-0">
        <h4 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] mb-4 ml-2 opacity-30">PERSONAL HUB</h4>
        <AccountCard 
          name={profileType === ProfileType.Homeowner ? "Alex Rivera" : "Clean & Co LLC"} 
          email="alex.rivera@example.com" 
          profileType={profileType}
          onClick={() => setIsSwitcherOpen(true)}
        />
      </section>

      {/* Tools Grid (Homeowner only) */}
      {profileType === ProfileType.Homeowner && (
        <section className="px-7 shrink-0">
          <h4 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] mb-4 ml-2 opacity-30">INFRASTRUCTURE</h4>
          <div className="grid grid-cols-4 gap-3">
             {TOOLS.map((tool, i) => (
               <GlassCard key={i} onClick={() => onNavigate(tool.id)} className="p-0 aspect-square flex items-center justify-center border-white/[0.02] bg-white/[0.01]">
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-2xl bg-white/[0.02] flex items-center justify-center mb-1 mx-auto shadow-inner border border-white/[0.03]">
                       {tool.icon}
                    </div>
                  </div>
               </GlassCard>
             ))}
          </div>
        </section>
      )}

      {/* Settings Sections */}
      <section className="px-7 shrink-0 space-y-4">
        <h4 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] ml-2 opacity-30">SYSTEM SETTINGS</h4>
        <div className="bg-white/[0.02] rounded-[2.5rem] border border-white/[0.02] overflow-hidden">
          {[
            { icon: <User size={18} />, label: 'Profile Information' },
            { icon: <CreditCard size={18} />, label: 'Payments & Billing' },
            { icon: isDarkMode ? <Moon size={18} /> : <Sun size={18} />, label: 'Appearance', action: toggleTheme, toggle: true },
            { icon: <Globe size={18} />, label: 'Language & Locale' }
          ].map((item, i, arr) => (
            <button 
              key={i} 
              onClick={item.action}
              className={`w-full flex items-center justify-between p-6 hover:bg-white/[0.03] transition-all ${i !== arr.length - 1 ? 'border-b border-white/[0.02]' : ''}`}
            >
              <div className="flex items-center gap-5">
                <div className="p-3.5 rounded-2xl bg-white/[0.02] text-dim opacity-40 border border-white/[0.02]">
                  {item.icon}
                </div>
                <span className="text-main font-bold text-base italic leading-none">{item.label}</span>
              </div>
              {item.toggle ? (
                <div className={`w-11 h-6 rounded-full p-1 flex transition-all ${!isDarkMode ? 'bg-homebase justify-end' : 'bg-white/10 justify-start'}`}>
                  <div className="w-4 h-4 bg-white rounded-full shadow-lg" />
                </div>
              ) : (
                <ChevronRight size={16} className="text-dim opacity-10" />
              )}
            </button>
          ))}
        </div>
      </section>

      {/* Logout */}
      <section className="px-7 pb-12 shrink-0">
        <GlassButton variant="outline" className="border-red-500/10 text-red-500/60 hover:text-red-500 hover:bg-red-500/5 h-16">
          <LogOutIcon size={18} className="mr-2" /> Log Out
        </GlassButton>
        <p className="text-center text-dim/10 text-[9px] mt-10 font-black uppercase tracking-[0.4em]">HomeBase SF Build v5.0.1</p>
      </section>

      {/* Switcher */}
      <GlassSheet isOpen={isSwitcherOpen} onClose={() => setIsSwitcherOpen(false)} title="Identity Hub" height="h-[45%]">
        <div className="space-y-4 pt-4">
          <ProfileOption type={ProfileType.Homeowner} description="Control properties and health." active={profileType === ProfileType.Homeowner} onClick={() => { onSwitchProfile(ProfileType.Homeowner); setIsSwitcherOpen(false); }} />
          <ProfileOption type={ProfileType.Provider} description="Control business and revenue." active={profileType === ProfileType.Provider} onClick={() => { onSwitchProfile(ProfileType.Provider); setIsSwitcherOpen(false); }} />
        </div>
      </GlassSheet>
    </div>
  );
};

export default More;
