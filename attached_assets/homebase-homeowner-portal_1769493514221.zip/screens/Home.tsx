
import React from 'react';
import { motion } from 'framer-motion';
import { 
  Bell, Sun, Moon, Sparkles, Wind, Droplets, Zap, 
  ChevronRight, ArrowRight, CheckCircle2, Scan, 
  ShieldAlert, History
} from 'lucide-react';
import { GlassCard, StatusPill } from '../components/Shared';
import { Tab } from '../types';

interface HomeProps {
  onNavigate: (tab: Tab) => void;
  onOpenAI: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const CATEGORIES = [
  { label: 'HVAC', icon: <Wind size={16} /> },
  { label: 'PLUMBING', icon: <Droplets size={16} /> },
  { label: 'ELECTRICAL', icon: <Zap size={16} /> },
  { label: 'HANDYMAN', icon: <History size={16} /> },
];

const WORK_ORDERS = [
  {
    id: '1',
    name: 'Eco-Clear Plumbing',
    service: 'DRAIN CLEANING',
    time: 'TOMORROW @ 10:00 AM',
    img: 'https://picsum.photos/80/80?10',
    status: 'UPCOMING'
  },
  {
    id: '2',
    name: 'Zap It Electric',
    service: 'PANEL TEST',
    time: 'OCT 28 @ 2:00 PM',
    img: 'https://picsum.photos/80/80?11',
    status: 'UPCOMING'
  }
];

const Home: React.FC<HomeProps> = ({ onNavigate, onOpenAI, isDarkMode, toggleTheme }) => {
  return (
    <div className="absolute inset-0 flex flex-col gap-6 pb-48 overflow-y-auto no-scrollbar pt-14 bg-app">
      
      {/* 1. PORTFOLIO HEADER */}
      <section className="px-7 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full border-2 border-homebase/10 p-0.5">
            <img src="https://picsum.photos/100/100?0" className="w-full h-full rounded-full object-cover" alt="Profile" />
          </div>
          <div>
            <p className="text-dim text-[10px] font-black uppercase tracking-[0.2em] opacity-30">PORTFOLIO</p>
            <h1 className="text-2xl font-black text-main italic tracking-tight leading-none">San Francisco</h1>
          </div>
        </div>
        <div className="flex gap-3">
          <motion.button 
            whileTap={{ scale: 0.92 }} 
            onClick={toggleTheme}
            className="w-12 h-12 rounded-2xl bg-white/[0.02] border border-white/5 flex items-center justify-center text-main"
          >
            {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
          </motion.button>
          <motion.button 
            whileTap={{ scale: 0.92 }} 
            className="w-12 h-12 rounded-2xl bg-white/[0.02] border border-white/5 flex items-center justify-center text-main relative"
          >
            <Bell size={20} />
            <span className="absolute top-3.5 right-3.5 w-2 h-2 bg-red-500 rounded-full border-2 border-surface" />
          </motion.button>
        </div>
      </section>

      {/* 2. ASK HOMEBASE AI CARD */}
      <section className="px-7 shrink-0">
        <motion.div 
          whileTap={{ scale: 0.98 }}
          onClick={onOpenAI}
          className="liquid-glass rounded-[2rem] p-6 flex items-center justify-between border-homebase/10 premium-glow bg-homebase/5"
        >
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 bg-homebase rounded-2xl flex items-center justify-center text-white shadow-lg shadow-homebase/20">
              <Sparkles size={24} fill="currentColor" />
            </div>
            <div>
              <h2 className="text-lg font-black text-main italic tracking-tight leading-none">Ask HomeBase AI</h2>
              <p className="text-dim text-[9px] font-black uppercase tracking-[0.15em] mt-1.5 opacity-30">DIAGNOSE ISSUES INSTANTLY</p>
            </div>
          </div>
          <ChevronRight size={18} className="text-homebase opacity-40" strokeWidth={3} />
        </motion.div>
      </section>

      {/* 3. HORIZONTAL CATEGORIES */}
      <section className="shrink-0 -mt-2">
        <div className="flex gap-2 overflow-x-auto px-7 no-scrollbar">
          {CATEGORIES.map(cat => (
            <button key={cat.label} className="flex items-center gap-2.5 px-6 py-3.5 rounded-full border border-white/5 bg-white/[0.02] whitespace-nowrap hover:bg-white/[0.05] transition-all">
              <span className="text-homebase/40">{cat.icon}</span>
              <span className="text-main font-black text-[10px] uppercase tracking-[0.2em]">{cat.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* 4. WORK ORDERS SECTION */}
      <section className="px-7 space-y-4">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] opacity-30">WORK ORDERS</h3>
          <button className="text-homebase text-[10px] font-black uppercase tracking-widest flex items-center gap-1 italic opacity-60">
            HISTORY <ArrowRight size={12} />
          </button>
        </div>
        
        <div className="space-y-3">
          {WORK_ORDERS.map(order => (
            <GlassCard key={order.id} className="p-5 flex items-center justify-between border-white/5 bg-white/[0.01]">
              <div className="flex items-center gap-4">
                <img src={order.img} className="w-14 h-14 rounded-2xl object-cover border border-white/5" alt="Pro" />
                <div>
                  <h4 className="text-main font-bold italic tracking-tight">{order.name}</h4>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-dim text-[9px] font-black uppercase tracking-widest opacity-20">{order.service}</span>
                    <span className="text-homebase text-[9px] font-black uppercase tracking-widest italic">{order.time}</span>
                  </div>
                </div>
              </div>
              <StatusPill status={order.status} />
            </GlassCard>
          ))}
        </div>
      </section>

      {/* 5. AI ASSESSMENT HUB */}
      <section className="px-7 space-y-4 pb-12">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <CheckCircle2 size={16} className="text-homebase opacity-40" />
            <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] opacity-30">AI ASSESSMENT</h3>
          </div>
          <button className="px-5 py-2.5 bg-homebase/10 rounded-full border border-homebase/10 text-homebase flex items-center gap-2">
            <Scan size={12} />
            <span className="text-[10px] font-black uppercase tracking-widest italic">SCAN LIVE</span>
          </button>
        </div>

        <div className="flex gap-4 overflow-x-auto no-scrollbar py-2">
          {/* Assessment Item 1 */}
          <div className="min-w-[170px] liquid-glass p-5 rounded-[2rem] border-white/5 bg-white/[0.01]">
            <div className="w-12 h-12 bg-white/[0.02] rounded-2xl flex items-center justify-center text-homebase mb-4 border border-white/5 shadow-inner">
              <Wind size={20} />
            </div>
            <h4 className="text-main font-bold italic tracking-tight mb-2">HVAC Filter</h4>
            <span className="px-3 py-1 bg-red-500/5 text-red-500 rounded-lg text-[8px] font-black uppercase tracking-[0.2em] border border-red-500/10">HIGH</span>
          </div>

          {/* Assessment Item 2 */}
          <div className="min-w-[170px] liquid-glass p-5 rounded-[2rem] border-white/5 bg-white/[0.01]">
            <div className="w-12 h-12 bg-white/[0.02] rounded-2xl flex items-center justify-center text-orange-400 mb-4 border border-white/5 shadow-inner">
              <ShieldAlert size={20} />
            </div>
            <h4 className="text-main font-bold italic tracking-tight mb-2">Roof Check</h4>
            <span className="px-3 py-1 bg-orange-400/5 text-orange-400 rounded-lg text-[8px] font-black uppercase tracking-[0.2em] border border-orange-400/10">MED</span>
          </div>

          {/* Full Scan Action */}
          <div className="min-w-[130px] rounded-[2rem] border border-homebase/10 bg-homebase/5 flex flex-col items-center justify-center gap-2 group hover:bg-homebase/10 transition-all">
            <Sparkles size={20} className="text-homebase" />
            <span className="text-homebase text-[9px] font-black uppercase tracking-[0.2em] text-center">FULL SCAN</span>
          </div>
        </div>
      </section>

      <div className="h-20 shrink-0" />
    </div>
  );
};

export default Home;
