
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, ChevronLeft, Sparkles, Sliders, Settings, Download, Share2, Check, ArrowRight, Wind, Droplets, X, Plus, Zap } from 'lucide-react';
import { GlassCard, GlassHeader, GlassButton, StatusPill, SuccessSparkle, PremiumBadge, SocialShareModal } from '../components/Shared';
import { Tab, HomeProfile } from '../types';

interface SurvivalKitProps {
  onBack: () => void;
  activeHome: HomeProfile;
}

const SurvivalKit: React.FC<SurvivalKitProps> = ({ onBack, activeHome }) => {
  const [step, setStep] = useState(0); 
  const [useProfile, setUseProfile] = useState(true);
  const [activeTab, setActiveTab] = useState<'Summary' | 'Audit' | 'Export'>('Summary');
  const [showSparkles, setShowSparkles] = useState(false);
  const [isSharing, setIsSharing] = useState(false);

  const next = () => {
    if (step === 3) {
      setStep(4);
      setTimeout(() => setStep(5), 2500);
    } else {
      setStep(s => s + 1);
    }
  };
  const prev = () => setStep(s => s - 1);

  const handleAddToPlan = () => {
    setShowSparkles(true);
    setTimeout(() => {
      setShowSparkles(false);
      onBack();
    }, 1500);
  };

  if (step === 0) {
    return (
      <div className="absolute inset-0 z-[110] bg-app flex flex-col overflow-hidden">
        <GlassHeader className="bg-transparent border-0 flex items-center gap-4 pt-12">
          <motion.button whileTap={{ scale: 0.9 }} onClick={onBack} className="p-2 bg-main/5 rounded-full text-dim hover:text-main transition-colors">
            <ChevronLeft size={20} />
          </motion.button>
          <h2 className="text-lg font-black text-main tracking-tight italic">Survival Blueprint</h2>
        </GlassHeader>
        <div className="flex-1 px-8 flex flex-col items-center justify-center text-center space-y-10">
          <motion.div 
            animate={{ 
              boxShadow: ["0 0 0px rgba(15,175,110,0)", "0 0 40px rgba(15,175,110,0.3)", "0 0 0px rgba(15,175,110,0)"],
              scale: [1, 1.05, 1]
            }}
            transition={{ duration: 4, repeat: Infinity }}
            className="w-32 h-32 bg-homebase/10 rounded-[3rem] border-2 border-homebase flex items-center justify-center relative shadow-xl"
          >
            <ShieldCheck size={64} className="text-homebase" />
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
              className="absolute -inset-4 border border-dashed border-homebase/20 rounded-[3.5rem]" 
            />
          </motion.div>
          <div>
            <h1 className="text-4xl font-black text-main mb-4 tracking-tighter leading-none italic">Maintenance<br/>Passport</h1>
            <p className="text-dim text-base leading-relaxed max-w-[260px] mx-auto font-medium">Create a professional-grade health plan for <span className="text-main font-black italic underline decoration-homebase/50">{activeHome.nickname}</span>.</p>
          </div>
          <div className="w-full space-y-4 pt-8">
            <motion.div whileTap={{ scale: 0.98 }} className="flex items-center justify-between p-5 bg-main/5 border border-main/10 rounded-3xl shadow-sm">
              <div className="text-left">
                <p className="text-main font-bold text-sm italic">Sync Home Profile</p>
                <p className="text-dim text-[9px] uppercase font-black tracking-widest mt-1">Telemetry connection</p>
              </div>
              <button 
                onClick={() => setUseProfile(!useProfile)}
                className={`w-14 h-8 rounded-full transition-all flex items-center px-1.5 ${useProfile ? 'bg-homebase shadow-lg shadow-homebase/20' : 'bg-main/10'}`}
              >
                <motion.div 
                  animate={{ x: useProfile ? 24 : 0 }}
                  className="w-5 h-5 bg-white rounded-full shadow-md" 
                />
              </button>
            </motion.div>
            <GlassButton onClick={next} className="h-16 text-lg tracking-widest italic">Begin Diagnostic</GlassButton>
          </div>
        </div>
      </div>
    );
  }

  if (step === 4) {
    return (
      <div className="absolute inset-0 z-[120] bg-app flex flex-col items-center justify-center text-center p-12">
        <div className="w-full max-w-[200px] h-[3px] bg-main/10 rounded-full relative overflow-hidden mb-12 shadow-inner">
           <motion.div 
             initial={{ x: '-100%' }}
             animate={{ x: '100%' }}
             transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
             className="absolute inset-0 bg-homebase shadow-[0_0_15px_rgba(15,175,110,0.8)]"
           />
        </div>
        <motion.div
          animate={{ scale: [1, 1.05, 1], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 3, repeat: Infinity }}
          className="space-y-4"
        >
          <h2 className="text-2xl font-black text-main italic tracking-tighter leading-none">Profiling {activeHome.nickname}</h2>
          <p className="text-dim text-[10px] font-black uppercase tracking-[0.4em]">Optimizing Safety Matrix</p>
        </motion.div>
        <motion.div 
          initial={{ top: '0%' }} animate={{ top: '100%' }} transition={{ duration: 2.5, ease: "linear" }}
          className="fixed left-0 right-0 h-[25vh] bg-gradient-to-b from-transparent via-homebase/10 to-transparent pointer-events-none z-[130] border-t border-homebase/50"
        />
      </div>
    );
  }

  if (step < 4) {
    const steps = ['Foundation', 'Heartbeat', 'Strategy'];
    return (
      <div className="absolute inset-0 z-[110] bg-app flex flex-col">
        <GlassHeader className="bg-transparent border-0 flex flex-col gap-4 pt-12">
          <div className="flex items-center justify-between">
            <motion.button whileTap={{ scale: 0.9 }} onClick={prev} className="p-2 bg-main/5 rounded-full text-dim">
              <ChevronLeft size={20} />
            </motion.button>
            <div className="flex-1 px-8">
              <div className="flex gap-1.5 h-1 shadow-inner rounded-full bg-main/5">
                {[1, 2, 3].map(i => (
                  <div key={i} className={`flex-1 rounded-full transition-all duration-700 ${i <= step ? 'bg-homebase shadow-[0_0_10px_rgba(15,175,110,0.5)]' : 'bg-transparent'}`} />
                ))}
              </div>
              <p className="text-[9px] font-black uppercase text-center text-dim tracking-[0.2em] mt-3">{steps[step - 1]}</p>
            </div>
            <div className="w-10" />
          </div>
        </GlassHeader>
        <div className="flex-1 overflow-y-auto px-8 py-10 space-y-10 no-scrollbar">
          {step === 1 && (
            <motion.div key="kit-step-1" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
              <div className="space-y-2 text-center">
                <h3 className="text-4xl font-black text-main leading-tight tracking-tighter italic">Vital Specs</h3>
                <p className="text-dim text-sm font-medium">Verify your property baseline.</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-3 px-1">
                  <label className="text-dim text-[9px] font-black uppercase tracking-[0.2em] ml-2">Area Code</label>
                  <input type="text" defaultValue="94105" className="w-full bg-main/5 border border-main/10 rounded-3xl p-5 text-main font-black text-sm text-center focus:border-homebase outline-none shadow-inner" />
                </div>
                <div className="space-y-3 px-1">
                  <label className="text-dim text-[9px] font-black uppercase tracking-[0.2em] ml-2">Footprint</label>
                  <input type="text" defaultValue={activeHome.sqft.toLocaleString()} className="w-full bg-main/5 border border-main/10 rounded-3xl p-5 text-main font-black text-sm text-center focus:border-homebase outline-none shadow-inner" />
                </div>
              </div>
            </motion.div>
          )}
          {/* Steps 2-3 similar text updates */}
        </div>
        <div className="p-6 pt-4 pb-12 bg-surface/80 backdrop-blur-2xl border-t border-main/5">
          <GlassButton onClick={next} className="h-16 text-lg tracking-widest italic shadow-xl">
            {step === 3 ? 'Generate Blueprint' : 'Next Step'}
            <ArrowRight size={20} className="ml-2" />
          </GlassButton>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 z-[110] bg-app flex flex-col">
       <SocialShareModal 
           isOpen={isSharing} onClose={() => setIsSharing(false)} 
           title="My Survival Blueprint" subtitle={activeHome.nickname}
           stats={[
             { label: 'Annual Tasks', value: '42' },
             { label: 'Priority Risk', value: 'High' },
             { label: 'Savings Index', value: '88%' }
           ]}
        />
       <GlassHeader className="bg-transparent border-0 flex items-center justify-between pt-12">
          <motion.button whileTap={{ scale: 0.9 }} onClick={onBack} className="p-2 bg-main/5 rounded-full text-dim"><X size={20} /></motion.button>
          <div className="flex flex-col items-center">
             <motion.h2 initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="text-base font-black text-main tracking-tight italic">The Blueprint</motion.h2>
             <p className="text-homebase text-[8px] font-black uppercase tracking-[0.3em] mt-1">{activeHome.nickname}</p>
          </div>
          <motion.button whileTap={{ scale: 0.9 }} onClick={() => setIsSharing(true)} className="p-2 bg-homebase/10 rounded-full text-homebase border border-homebase/20"><Share2 size={18} /></motion.button>
       </GlassHeader>

       <div className="px-8 py-4">
         <div className="p-1.5 rounded-[1.5rem] bg-main/5 border border-main/5 flex gap-1 shadow-inner">
            {(['Summary', 'Audit', 'Export'] as const).map(t => (
              <button key={t} onClick={() => setActiveTab(t)} className={`flex-1 py-3 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] transition-all relative ${activeTab === t ? 'text-white' : 'text-dim'}`}>
                <span className="relative z-10">{t}</span>
                {activeTab === t && <motion.div layoutId="kit-tab-premium" className="absolute inset-0 bg-homebase rounded-2xl shadow-md" />}
              </button>
            ))}
         </div>
       </div>

       <div className="flex-1 overflow-y-auto px-8 py-6 no-scrollbar pb-40">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-8">
             <div className="grid grid-cols-2 gap-5">
                <GlassCard className="p-8 border-main/5 bg-gradient-to-br from-homebase/10 via-surface to-transparent shadow-xl relative overflow-hidden">
                   <div className="absolute -right-4 -bottom-4 opacity-5 rotate-12"><ShieldCheck size={80} className="text-homebase" /></div>
                   <p className="text-dim text-[9px] font-black uppercase tracking-[0.3em] mb-2">Cycle Tasks</p>
                   <h4 className="text-5xl font-black text-main italic tracking-tighter">42</h4>
                   <div className="mt-4"><PremiumBadge label="Verified" /></div>
                </GlassCard>
                <GlassCard className="p-8 border-main/5 bg-gradient-to-br from-surface to-transparent shadow-xl">
                   <p className="text-dim text-[9px] font-black uppercase tracking-[0.3em] mb-2">Efficiency</p>
                   <h4 className="text-3xl font-black text-main italic tracking-tighter">Premium</h4>
                   <div className="mt-6 flex items-center gap-1">
                     <span className="text-homebase font-black text-xs">88%</span>
                     <span className="text-dim/30 text-[8px] font-bold uppercase">Savings</span>
                   </div>
                </GlassCard>
             </div>

             <div className="space-y-4">
                <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] ml-2">High Priority</h3>
                <GlassCard className="p-8 border-homebase/30 bg-homebase/5 relative overflow-hidden group shadow-2xl">
                   <div className="absolute top-0 right-0 p-6 opacity-40"><Zap className="text-homebase" size={40} /></div>
                   <div className="relative z-10">
                     <h4 className="text-main font-black text-2xl mb-2 leading-tight tracking-tighter italic">Air Quality<br/>Compromised</h4>
                     <p className="text-dim text-sm mb-10 leading-relaxed max-w-[180px] font-medium">Filter efficiency reached critical threshold. Swap within <span className="text-main font-bold">7 days</span>.</p>
                     <GlassButton onClick={() => {}} className="h-14 rounded-[1.5rem] text-[10px] uppercase tracking-[0.2em] font-black shadow-lg">Schedule Fix</GlassButton>
                   </div>
                </GlassCard>
             </div>
          </motion.div>
       </div>

       <div className="p-8 pt-4 pb-12 bg-surface/90 backdrop-blur-3xl border-t border-main/5 relative">
          <SuccessSparkle active={showSparkles} />
          <GlassButton onClick={handleAddToPlan} className="h-16 text-lg italic tracking-widest shadow-[0_0_50px_rgba(15,175,110,0.3)]">Confirm Blueprint</GlassButton>
       </div>
    </div>
  );
};

export default SurvivalKit;
