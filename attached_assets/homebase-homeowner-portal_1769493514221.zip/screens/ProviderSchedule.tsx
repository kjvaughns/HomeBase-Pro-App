
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, ChevronRight, ChevronLeft, Navigation, CheckCircle2 } from 'lucide-react';
import { GlassCard, StatusPill } from '../components/Shared';

type ScheduleView = 'List' | 'Day' | 'Week';

const ProviderSchedule: React.FC = () => {
  const [view, setView] = useState<ScheduleView>('List');

  const JOBS = [
    { id: '1', client: 'Sarah Miller', service: 'Deep Clean', time: '09:00 AM', status: 'IN PROGRESS', address: '123 Pine St, SF' },
    { id: '2', client: 'TechStart Office', service: 'Maintenance', time: '11:30 AM', status: 'SCHEDULED', address: '400 Market St, SF' },
  ];

  return (
    <div className="absolute inset-0 flex flex-col gap-8 pb-48 overflow-y-auto no-scrollbar pt-16 bg-app px-7">
      <header className="shrink-0 flex items-center justify-between">
        <h1 className="text-3xl font-black text-main leading-none italic tracking-tighter">Schedule</h1>
        <div className="flex items-center gap-3 bg-white/[0.03] px-4 py-2 rounded-2xl border border-white/[0.02]">
          <ChevronLeft size={16} className="text-dim opacity-30" />
          <span className="text-[10px] font-black text-main uppercase tracking-widest italic">Wed, Dec 17</span>
          <ChevronRight size={16} className="text-dim opacity-30" />
        </div>
      </header>

      <section className="shrink-0">
        <div className="p-1.5 rounded-[1.8rem] bg-white/[0.03] border border-white/[0.02] flex gap-1 shadow-inner relative overflow-hidden">
          {(['List', 'Day', 'Week'] as ScheduleView[]).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`flex-1 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest relative z-10 transition-all ${
                view === v ? 'text-main' : 'text-dim opacity-30 hover:opacity-100'
              }`}
            >
              {v}
              {view === v && (
                <motion.div layoutId="sched-tab" className="absolute inset-0 bg-surface rounded-2xl shadow-xl border border-white/5 -z-10" />
              )}
            </button>
          ))}
        </div>
      </section>

      <section className="flex-1 space-y-6 pb-12">
        <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] ml-2 opacity-30">TODAY'S WORKLOAD</h3>
        {JOBS.map((job) => (
          <GlassCard key={job.id} className="p-6 border-white/[0.02] group">
            <div className="flex justify-between items-start mb-6">
              <div className="flex gap-5">
                <div className="text-center">
                  <span className="text-main font-black text-lg leading-none italic">{job.time.split(' ')[0]}</span>
                  <p className="text-dim text-[9px] font-black uppercase tracking-widest mt-1 opacity-30">{job.time.split(' ')[1]}</p>
                </div>
                <div>
                  <h4 className="text-main font-extrabold text-xl leading-none italic tracking-tight group-hover:text-homebase transition-colors">{job.client}</h4>
                  <p className="text-homebase text-[11px] font-bold mt-2 italic tracking-tight">{job.service}</p>
                  <div className="flex items-center gap-1.5 text-dim mt-2 opacity-30">
                    <MapPin size={10} />
                    <span className="text-[10px] font-medium truncate max-w-[150px]">{job.address}</span>
                  </div>
                </div>
              </div>
              <StatusPill status={job.status} />
            </div>
            
            <div className="grid grid-cols-2 gap-3 pt-6 border-t border-white/[0.02]">
              <button className="flex items-center justify-center gap-2 py-3 rounded-2xl bg-white/[0.02] text-dim text-[10px] font-black uppercase tracking-widest hover:text-main transition-all border border-white/[0.03]">
                <Navigation size={14} /> Route
              </button>
              <button className="flex items-center justify-center gap-2 py-3 rounded-2xl bg-white/[0.02] text-dim text-[10px] font-black uppercase tracking-widest hover:text-main transition-all border border-white/[0.03]">
                <CheckCircle2 size={14} /> Complete
              </button>
            </div>
          </GlassCard>
        ))}
      </section>
    </div>
  );
};

export default ProviderSchedule;
