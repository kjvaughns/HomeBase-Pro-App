
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, ChevronLeft, Search, Plus, Sliders, LayoutGrid, Clock, Package, History as HistoryIcon, ShieldCheck, ChevronRight, X, Image as ImageIcon, Camera, Trash2, ChevronDown } from 'lucide-react';
import { GlassCard, GlassHeader, GlassButton, StatusPill, GlassSheet, GlassListRow, SuccessSparkle } from '../components/Shared';
import { HomeProfile, Asset, Consumable } from '../types';

interface HouseFaxProps {
  onBack: () => void;
  activeHome: HomeProfile;
}

const MOCK_ASSETS: Asset[] = [
  { id: 'a1', name: 'LG Kitchen Fridge', location: 'Kitchen', installDate: 'Oct 2021', warrantyStatus: 'Active', category: 'Appliances' },
  { id: 'a2', name: 'Nest Gen 3 HVAC', location: 'Hallway', installDate: 'Jan 2019', warrantyStatus: 'Expired', category: 'HVAC' },
  { id: 'a3', name: 'Smart Panel Pro', location: 'Garage', installDate: 'Mar 2023', warrantyStatus: 'Active', category: 'Electrical' },
];

const MOCK_CONSUMABLES: Consumable[] = [
  { id: 'c1', name: 'MERV 13 Air Filter', nextDue: 'Nov 15, 2023', recurrence: 'Quarterly' },
  { id: 'c2', name: 'Water Filter RPWF', nextDue: 'Dec 01, 2023', recurrence: 'Every 6 Months' },
];

const HouseFaxLedger: React.FC<HouseFaxProps> = ({ onBack, activeHome }) => {
  const [activeTab, setActiveTab] = useState<'Assets' | 'Consumables' | 'History' | 'Docs'>('Assets');
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null);
  const [showAddAsset, setShowAddAsset] = useState(false);
  const [showSparkles, setShowSparkles] = useState(false);

  const handleSaveAsset = () => {
    setShowAddAsset(false);
    setShowSparkles(true);
    setTimeout(() => setShowSparkles(false), 2000);
  };

  return (
    <div className="absolute inset-0 z-[110] bg-app flex flex-col">
      <SuccessSparkle active={showSparkles} />
      <GlassHeader className="bg-transparent border-0 flex items-center justify-between pt-8">
        <motion.button whileTap={{ scale: 0.9 }} onClick={onBack} className="p-2 bg-main/5 rounded-full text-dim"><ChevronLeft size={20} /></motion.button>
        <div className="flex flex-col items-center">
           <h2 className="text-base font-black text-main leading-none tracking-tighter italic">HouseFax Ledger</h2>
           <p className="text-homebase text-[9px] font-black uppercase tracking-[0.2em] mt-1">Property OS</p>
        </div>
        <div className="w-10" />
      </GlassHeader>

      <div className="px-6 py-4">
         <div className="flex gap-1 overflow-x-auto no-scrollbar py-2 -mx-2 px-2">
            {(['Assets', 'Consumables', 'History', 'Docs'] as const).map(t => (
              <button
                key={t}
                onClick={() => setActiveTab(t)}
                className={`flex-shrink-0 px-6 py-2.5 rounded-xl text-[10px] font-black transition-all relative border uppercase tracking-[0.2em] ${
                  activeTab === t ? 'text-homebase border-homebase/30' : 'text-dim border-main/5 hover:text-main'
                }`}
              >
                <span className="relative z-10">{t}</span>
                {activeTab === t && (
                  <motion.div layoutId="ledger-tab" className="absolute inset-0 bg-homebase/10 rounded-xl" />
                )}
              </button>
            ))}
         </div>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 no-scrollbar">
         <AnimatePresence mode="wait">
            {activeTab === 'Assets' && (
              <motion.div key="assets" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
                <div className="flex gap-3">
                  <div className="flex-1 relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-dim/60" size={16} />
                    <input type="text" placeholder="Search components..." className="w-full bg-main/5 border border-main/10 rounded-2xl py-4 pl-12 pr-4 text-sm text-main focus:border-homebase outline-none transition-colors font-medium placeholder:text-dim/40 shadow-inner" />
                  </div>
                  <motion.button whileTap={{ scale: 0.9 }} className="p-4 bg-main/5 border border-main/10 rounded-2xl text-main/60 shadow-sm"><Sliders size={20} /></motion.button>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between px-2">
                    <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.2em]">Tracked Components</h3>
                    <motion.button whileTap={{ scale: 0.9 }} onClick={() => setShowAddAsset(true)} className="flex items-center gap-1.5 text-homebase font-black text-[10px] uppercase tracking-widest"><Plus size={14} /> Add New</motion.button>
                  </div>
                  {MOCK_ASSETS.map((asset, i) => (
                    <GlassCard key={asset.id} index={i} className="p-5 border-main/5 hover:border-homebase/20 transition-all group shadow-md" onClick={() => setSelectedAsset(asset)}>
                       <div className="flex justify-between items-start mb-3">
                          <div>
                             <h4 className="text-main font-black text-lg leading-none tracking-tight mb-1 group-hover:text-homebase transition-colors italic">{asset.name}</h4>
                             <p className="text-dim text-[10px] font-bold uppercase tracking-widest">{asset.location} • {asset.installDate}</p>
                          </div>
                          <StatusPill status={asset.warrantyStatus} />
                       </div>
                       <div className="flex items-center justify-between pt-4 border-t border-main/5">
                          <span className="text-dim/40 text-[10px] font-black uppercase tracking-[0.2em]">{asset.category}</span>
                          <ChevronRight size={18} className="text-dim/20 group-hover:text-homebase transition-colors" />
                       </div>
                    </GlassCard>
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'Consumables' && (
              <motion.div key="consumables" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="space-y-6">
                 <GlassCard className="p-8 bg-gradient-to-br from-homebase/10 via-surface to-transparent border-homebase/20 flex items-center justify-between relative overflow-hidden group shadow-xl">
                    <div className="absolute -right-6 -top-6 w-24 h-24 bg-homebase/10 blur-[30px] rounded-full group-hover:scale-150 transition-transform duration-1000" />
                    <div className="relative z-10">
                       <h3 className="text-main font-black text-2xl leading-none italic tracking-tighter mb-1">Status: OK</h3>
                       <p className="text-homebase text-[10px] font-black uppercase tracking-[0.2em]">Inventory Balanced</p>
                    </div>
                    <div className="w-16 h-16 bg-homebase rounded-[1.5rem] flex items-center justify-center shadow-lg shadow-homebase/20">
                       <Package className="text-white" size={32} />
                    </div>
                 </GlassCard>

                 <div className="space-y-4">
                    {MOCK_CONSUMABLES.map((c, i) => (
                      <GlassCard key={c.id} index={i} className="p-5 flex items-center justify-between border-main/5 shadow-sm">
                         <div className="flex gap-4">
                            <div className="w-12 h-12 bg-main/5 rounded-2xl flex items-center justify-center border border-main/5 shadow-inner"><LayoutGrid size={24} className="text-homebase" /></div>
                            <div>
                               <p className="text-main font-bold text-sm italic">{c.name}</p>
                               <p className="text-dim text-[10px] font-bold uppercase tracking-widest mt-1">Next: <span className="text-homebase">{c.nextDue}</span></p>
                            </div>
                         </div>
                         <motion.button whileTap={{ scale: 0.9 }} className="px-5 py-2.5 rounded-xl bg-main/5 border border-main/10 text-[10px] font-black uppercase tracking-widest text-dim hover:text-main hover:bg-main/10 transition-colors shadow-sm">Stash</motion.button>
                      </GlassCard>
                    ))}
                 </div>
              </motion.div>
            )}
         </AnimatePresence>
      </div>

      <GlassSheet isOpen={!!selectedAsset} onClose={() => setSelectedAsset(null)} title="Component Details">
        {selectedAsset && (
          <div className="space-y-10 pt-6">
             <div className="flex items-center gap-6">
                <motion.div 
                  initial={{ rotate: -20, scale: 0.5 }}
                  animate={{ rotate: 0, scale: 1 }}
                  className="w-24 h-24 bg-main/5 rounded-[2.2rem] border border-main/10 flex items-center justify-center shadow-inner"
                >
                   <Package size={44} className="text-homebase" />
                </motion.div>
                <div>
                   <h3 className="text-3xl font-black text-main italic tracking-tighter leading-none">{selectedAsset.name}</h3>
                   <div className="flex items-center gap-2 mt-3">
                      <StatusPill status={selectedAsset.warrantyStatus} />
                      <span className="text-dim text-[10px] font-black uppercase tracking-widest">{selectedAsset.category}</span>
                   </div>
                </div>
             </div>
             
             <div className="space-y-4">
                <GlassListRow title="Location" subtitle={selectedAsset.location} icon={<LayoutGrid size={20} className="text-homebase" />} />
                <GlassListRow title="Install Date" subtitle={selectedAsset.installDate} icon={<Clock size={20} className="text-blue-400" />} />
                <GlassListRow title="Warranty" subtitle="Active Coverage" icon={<ShieldCheck size={20} className="text-emerald-500" />} />
             </div>

             <div className="grid grid-cols-2 gap-4">
                <motion.button whileTap={{ scale: 0.9 }} className="py-5 bg-main/5 border border-main/10 rounded-2xl text-[10px] font-black uppercase tracking-widest text-main/70 shadow-sm">Manual</motion.button>
                <motion.button whileTap={{ scale: 0.9 }} className="py-5 bg-main/5 border border-main/10 rounded-2xl text-[10px] font-black uppercase tracking-widest text-main/70 shadow-sm">History</motion.button>
             </div>

             <GlassButton onClick={() => {}}>Schedule Maintenance</GlassButton>
             
             <button className="w-full flex items-center justify-center gap-2 text-red-500/40 font-black text-[10px] uppercase tracking-[0.3em] py-4 hover:text-red-500 transition-colors">
                <Trash2 size={14} /> Remove Component
             </button>
          </div>
        )}
      </GlassSheet>
    </div>
  );
};

export default HouseFaxLedger;
