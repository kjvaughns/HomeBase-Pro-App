
import React from 'react';
import { motion } from 'framer-motion';
import { Star, MapPin, ShieldCheck, Clock, ArrowLeft, Heart, Share2, ChevronRight, MessageCircle } from 'lucide-react';
import { GlassCard, GlassButton, GlassListRow } from '../components/Shared';
import { Provider } from '../types';

interface ProviderProfileProps {
  provider: Provider;
  onBack: () => void;
  onBook: () => void;
}

const ProviderProfile: React.FC<ProviderProfileProps> = ({ provider, onBack, onBook }) => {
  return (
    <div className="absolute inset-0 z-[110] bg-app flex flex-col overflow-hidden">
      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar">
        {/* Hero Section */}
        <div className="relative h-80 w-full">
          <img src={provider.heroImage} className="w-full h-full object-cover" alt="Hero" />
          <div className="absolute inset-0 bg-gradient-to-t from-surface via-surface/40 to-transparent" />
          
          {/* Header Actions */}
          <div className="absolute top-12 inset-x-0 px-6 flex justify-between">
            <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface/40 backdrop-blur-md border border-main/10 flex items-center justify-center text-main">
              <ArrowLeft size={20} />
            </button>
            <div className="flex gap-3">
              <button className="w-10 h-10 rounded-full bg-surface/40 backdrop-blur-md border border-main/10 flex items-center justify-center text-main">
                <Share2 size={18} />
              </button>
              <button className="w-10 h-10 rounded-full bg-surface/40 backdrop-blur-md border border-main/10 flex items-center justify-center text-main">
                <Heart size={18} />
              </button>
            </div>
          </div>

          {/* Business Logo & Info Overlay */}
          <div className="absolute bottom-6 inset-x-6">
            <div className="flex items-end gap-4">
              <div className="w-24 h-24 rounded-[2rem] border-4 border-surface shadow-2xl overflow-hidden bg-surface">
                <img src={provider.logo} className="w-full h-full object-cover" alt="Logo" />
              </div>
              <div className="flex-1 mb-2">
                <div className="flex items-center gap-2 mb-1">
                  <ShieldCheck size={14} className="text-homebase" />
                  <span className="text-homebase text-[10px] font-black uppercase tracking-widest">Verified Pro</span>
                </div>
                <h1 className="text-3xl font-black text-main leading-tight italic tracking-tighter">{provider.name}</h1>
              </div>
            </div>
          </div>
        </div>

        {/* Details Content */}
        <div className="px-6 py-8 space-y-8">
          {/* Stats Bar */}
          <div className="flex gap-4">
            <div className="flex-1 liquid-glass p-4 rounded-2xl flex flex-col items-center border-main/5 shadow-md">
              <div className="flex items-center gap-1 text-yellow-500 mb-1">
                <Star size={16} fill="currentColor" />
                <span className="text-main font-black italic">{provider.rating}</span>
              </div>
              <p className="text-dim text-[10px] uppercase font-black tracking-widest">{provider.reviewCount} Reviews</p>
            </div>
            <div className="flex-1 liquid-glass p-4 rounded-2xl flex flex-col items-center border-main/5 shadow-md">
              <MapPin size={16} className="text-homebase mb-1" />
              <span className="text-main font-black italic">{provider.distance}</span>
              <p className="text-dim text-[10px] uppercase font-black tracking-widest">Distance</p>
            </div>
            <div className="flex-1 liquid-glass p-4 rounded-2xl flex flex-col items-center border-main/5 shadow-md">
              <Clock size={16} className="text-blue-400 mb-1" />
              <span className="text-main font-black italic">24h</span>
              <p className="text-dim text-[10px] uppercase font-black tracking-widest">Support</p>
            </div>
          </div>

          {/* About */}
          <section>
            <h3 className="text-lg font-black text-main mb-3 italic tracking-tight uppercase text-[10px] tracking-[0.3em] text-dim ml-2">About the Business</h3>
            <GlassCard className="p-6 border-main/5">
              <p className="text-dim text-sm leading-relaxed font-medium">
                {provider.about || 'A premium provider dedicated to excellence in home maintenance and specialized repairs. We prioritize efficiency and property integrity for every job.'}
              </p>
            </GlassCard>
          </section>

          {/* Services */}
          <section>
            <div className="flex items-center justify-between mb-4 ml-2">
              <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em]">Our Services</h3>
              <button className="text-homebase text-xs font-black italic uppercase tracking-widest">View full list</button>
            </div>
            <div className="space-y-3">
              {provider.serviceDetails?.map((service) => (
                <GlassListRow 
                  key={service.id}
                  title={service.name}
                  subtitle={service.duration}
                  trailing={<span className="text-main font-black text-sm italic">{service.price}</span>}
                  onClick={onBook}
                  className="bg-main/5 border-main/5 shadow-sm"
                />
              )) || provider.services?.map((s, i) => (
                <GlassListRow key={i} title={s} onClick={onBook} trailing={<ChevronRight size={18} className="text-dim/30" />} className="bg-main/5" />
              ))}
            </div>
          </section>

          {/* Reviews Preview */}
          <section>
            <div className="flex items-center justify-between mb-4 ml-2">
              <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em]">Recent Reviews</h3>
              <button className="text-homebase text-xs font-black italic uppercase tracking-widest">Read all</button>
            </div>
            <GlassCard className="p-6 border-main/5 shadow-md">
              <div className="flex items-center gap-3 mb-4">
                <img src="https://picsum.photos/40/40?5" className="w-10 h-10 rounded-full border border-main/10 shadow-sm" alt="Reviewer" />
                <div>
                  <p className="text-main font-black text-sm italic">James Wilson</p>
                  <div className="flex text-yellow-500 gap-0.5">
                    {[1,2,3,4,5].map(i => <Star key={i} size={8} fill="currentColor" />)}
                  </div>
                </div>
              </div>
              <p className="text-dim text-sm italic leading-relaxed font-medium">"Master Flow lived up to their name. Fixed our bursting pipe within 30 minutes of arrival. Highly professional and cleaned up afterwards!"</p>
            </GlassCard>
          </section>

          {/* Portfolio */}
          <section className="pb-48">
            <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] mb-4 ml-2">Past Work</h3>
            <div className="grid grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(i => (
                <img key={i} src={`https://picsum.photos/200/200?w=${i + 20}`} className="w-full aspect-square object-cover rounded-[2rem] border border-main/10 shadow-lg" alt="Work" />
              ))}
            </div>
          </section>
        </div>
      </div>

      {/* Sticky Bottom Booking Bar */}
      <div className="absolute bottom-0 inset-x-0 p-6 pt-4 pb-32 bg-surface/90 backdrop-blur-3xl border-t border-main/5 flex gap-4">
        <button className="p-4 rounded-2xl bg-main/5 border border-main/10 text-main hover:bg-main/10 transition-colors shadow-sm">
          <MessageCircle size={24} />
        </button>
        <GlassButton onClick={onBook} className="flex-1 shadow-[0_0_30px_rgba(15,175,110,0.3)] italic tracking-widest">
          Schedule Service
        </GlassButton>
      </div>
    </div>
  );
};

export default ProviderProfile;
