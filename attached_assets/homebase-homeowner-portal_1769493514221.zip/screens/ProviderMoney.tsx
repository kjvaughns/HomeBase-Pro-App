
import React from 'react';
import { motion } from 'framer-motion';
import { Wallet, CreditCard, History, FileText, ChevronRight, TrendingUp } from 'lucide-react';
import { GlassCard, RevenueChart, GlassButton } from '../components/Shared';

const ProviderMoney: React.FC = () => {
  return (
    <div className="absolute inset-0 flex flex-col gap-10 pb-48 overflow-y-auto no-scrollbar pt-16 bg-app px-7">
      <header className="shrink-0">
        <h1 className="text-3xl font-black text-main leading-none italic tracking-tighter mb-2">Money Hub</h1>
        <p className="text-homebase text-[10px] font-black uppercase tracking-[0.3em] opacity-40">FINANCIAL ENGINE</p>
      </header>

      {/* Balance Card */}
      <section className="shrink-0">
        <GlassCard className="p-8 border-white/[0.02] bg-white/[0.01] premium-glow">
          <div className="flex items-center justify-between mb-8">
            <div>
              <p className="text-dim text-[10px] font-bold uppercase tracking-widest opacity-30 mb-2">Net Balance</p>
              <h2 className="text-5xl font-black text-main italic tracking-tighter leading-none">$14,250.00</h2>
            </div>
            <div className="p-4 rounded-3xl bg-white/[0.02] text-homebase/40">
              <Wallet size={32} />
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <GlassButton className="h-14 italic tracking-widest shadow-2xl">Payout</GlassButton>
            <GlassButton variant="secondary" className="h-14 italic tracking-widest border-white/[0.02]">Invoice</GlassButton>
          </div>
        </GlassCard>
      </section>

      {/* Revenue Chart */}
      <section className="shrink-0 space-y-6">
        <div className="flex items-center justify-between px-2">
           <h3 className="text-main font-extrabold text-xl italic tracking-tight leading-none">Revenue</h3>
           <div className="flex items-center gap-1.5 px-3 py-1 bg-homebase/10 rounded-xl text-homebase font-black text-[10px] italic">
             <TrendingUp size={14} /> +12%
           </div>
        </div>
        <GlassCard className="p-8 border-white/[0.02]">
           <RevenueChart />
        </GlassCard>
      </section>

      {/* Quick Links */}
      <section className="shrink-0 pb-12">
        <div className="bg-white/[0.02] rounded-[2.5rem] border border-white/[0.02] overflow-hidden">
          {[
            { label: 'Payment Methods', icon: <CreditCard size={18} />, desc: 'Banks and cards' },
            { label: 'Activity Logs', icon: <History size={18} />, desc: 'Full audit history' },
            { label: 'Tax Center', icon: <FileText size={18} />, desc: 'Download documents' },
          ].map((item, i, arr) => (
            <motion.button
              key={i}
              whileTap={{ scale: 0.985 }}
              className={`w-full flex items-center justify-between p-6 hover:bg-white/[0.04] transition-all group ${i !== arr.length - 1 ? 'border-b border-white/[0.02]' : ''}`}
            >
              <div className="flex items-center gap-5">
                <div className="p-3.5 rounded-2xl bg-white/[0.02] text-dim opacity-30 border border-white/[0.02]">
                  {item.icon}
                </div>
                <div className="text-left">
                  <p className="text-main font-bold text-base italic leading-none">{item.label}</p>
                  <p className="text-dim text-[11px] font-medium mt-1.5 opacity-20">{item.desc}</p>
                </div>
              </div>
              <ChevronRight size={16} className="text-dim opacity-10" />
            </motion.button>
          ))}
        </div>
      </section>
    </div>
  );
};

export default ProviderMoney;
