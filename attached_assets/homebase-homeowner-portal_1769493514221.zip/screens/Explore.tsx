
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, SlidersHorizontal, Star, MapPin, Heart, Sparkles, ChevronRight } from 'lucide-react';
import { GlassCard, Chip, GlassButton } from '../components/Shared';
import { Provider } from '../types';

const MOCK_PROVIDERS: Provider[] = [
  { 
    id: '1', 
    name: 'Master Flow Plumbing', 
    rating: 4.9, 
    reviewCount: 128, 
    distance: '1.2 mi', 
    tags: ['Residential', 'Emergency'], 
    logo: 'https://picsum.photos/60/60?10',
    heroImage: 'https://picsum.photos/400/200?10',
    about: 'Master Flow has been the leading plumbing service in the Bay Area for over 15 years.',
    serviceDetails: [
      { id: 's1', name: 'Emergency Leak Repair', duration: '1-2 hrs', price: 'From $150' }
    ]
  },
  { 
    id: '2', 
    name: 'Bright Arc Electric', 
    rating: 4.7, 
    reviewCount: 89, 
    distance: '2.5 mi', 
    tags: ['Wiring', 'EV Charging'], 
    logo: 'https://picsum.photos/60/60?11',
    heroImage: 'https://picsum.photos/400/200?11'
  },
  { 
    id: '3', 
    name: 'Pure Air HVAC', 
    rating: 4.8, 
    reviewCount: 215, 
    distance: '0.8 mi', 
    tags: ['AC Repair', 'Heat Pumps'], 
    logo: 'https://picsum.photos/60/60?12',
    heroImage: 'https://picsum.photos/400/200?12'
  }
];

const CATEGORIES = ['All', 'HVAC', 'Plumbing', 'Electrical'];

const Explore: React.FC<{ 
  onOpenAI: () => void; 
  onSelectProvider: (p: Provider) => void;
}> = ({ onOpenAI, onSelectProvider }) => {
  const [activeCat, setActiveCat] = useState('All');

  return (
    <div className="absolute inset-0 flex flex-col gap-8 pb-48 overflow-y-auto no-scrollbar pt-16 bg-app">
      {/* Search Header */}
      <section className="px-7 sticky top-0 z-40 bg-app/80 backdrop-blur-2xl pb-4 border-b border-white/[0.03] shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-dim opacity-30" size={18} />
            <input 
              type="text" 
              placeholder="Search specialists..." 
              className="w-full ios-search-bg rounded-[1.5rem] py-4 pl-14 pr-6 text-sm text-main font-bold focus:outline-none focus:border-homebase/40 placeholder:text-dim/20"
            />
          </div>
          <motion.button whileTap={{ scale: 0.94 }} className="w-14 h-14 rounded-2xl bg-white/[0.03] flex items-center justify-center text-main border border-white/[0.02]">
            <SlidersHorizontal size={20} />
          </motion.button>
        </div>
      </section>

      {/* AI Intelligence Card */}
      <section className="px-7 shrink-0">
        <motion.button 
          whileTap={{ scale: 0.98 }}
          onClick={onOpenAI}
          className="w-full flex items-center justify-between p-6 rounded-6xl bg-homebase/5 border border-homebase/10 premium-glow group"
        >
          <div className="flex items-center gap-5 text-left">
            <div className="bg-homebase w-12 h-12 rounded-2xl shadow-lg flex items-center justify-center text-white">
              <Sparkles size={22} fill="currentColor" />
            </div>
            <div>
              <p className="text-main font-black text-lg italic tracking-tighter leading-none">Smart Match AI</p>
              <p className="text-dim font-bold text-[9px] uppercase tracking-widest mt-1.5 opacity-30">Live Intelligence Active</p>
            </div>
          </div>
          <ChevronRight className="text-homebase opacity-30 group-hover:opacity-100 transition-opacity" size={20} />
        </motion.button>
      </section>

      {/* Categories */}
      <section className="px-7 shrink-0">
        <div className="flex gap-2.5 overflow-x-auto no-scrollbar">
          {CATEGORIES.map(cat => (
            <Chip key={cat} label={cat} active={activeCat === cat} onClick={() => setActiveCat(cat)} />
          ))}
        </div>
      </section>

      {/* Specialist List */}
      <section className="px-7 space-y-6 pb-12">
        <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] ml-2 opacity-30">AVAILABLE PROS</h3>
        {MOCK_PROVIDERS.map((pro, i) => (
          <GlassCard key={pro.id} index={i} className="p-0 border-white/[0.02]" onClick={() => onSelectProvider(pro)}>
            <div className="p-6">
              <div className="flex gap-6 mb-6">
                <div className="relative shrink-0">
                  <img src={pro.logo} className="w-20 h-20 rounded-5xl object-cover bg-white/[0.02] border border-white/[0.03]" alt={pro.name} />
                  <div className="absolute -bottom-1.5 -right-1.5 bg-homebase text-white px-2 py-1 rounded-xl border-4 border-surface flex items-center gap-1 shadow-lg">
                    <Star size={10} fill="currentColor" />
                    <span className="text-[10px] font-black italic">{pro.rating}</span>
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h4 className="font-black text-main text-xl leading-none italic tracking-tighter">{pro.name}</h4>
                    <motion.button whileTap={{ scale: 0.8 }}><Heart size={20} className="text-dim opacity-20 hover:text-red-500 hover:opacity-100" /></motion.button>
                  </div>
                  <div className="flex items-center gap-4 mt-3">
                    <div className="flex items-center gap-1.5"><MapPin size={12} className="text-homebase opacity-40" /><span className="text-dim text-[11px] font-bold">{pro.distance}</span></div>
                    <span className="text-dim text-[10px] font-black uppercase tracking-widest opacity-20">{pro.reviewCount} REVIEWS</span>
                  </div>
                  <div className="flex gap-2 mt-4">
                    {pro.tags?.slice(0, 2).map(tag => (
                      <span key={tag} className="px-3 py-1 rounded-lg bg-white/[0.03] text-dim text-[9px] font-black uppercase tracking-widest border border-white/[0.02]">{tag}</span>
                    ))}
                  </div>
                </div>
              </div>
              <GlassButton onClick={() => onSelectProvider(pro)} variant="secondary" className="border-white/[0.02]">Select Specialist</GlassButton>
            </div>
          </GlassCard>
        ))}
      </section>
    </div>
  );
};

export default Explore;
