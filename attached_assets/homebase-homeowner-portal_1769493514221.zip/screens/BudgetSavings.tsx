
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PiggyBank, ChevronLeft, Sparkles as SparkleIcon, PieChart, TrendingDown, DollarSign, ArrowRight, Zap, Droplets, Wind, ShieldCheck, Check, Share2 } from 'lucide-react';
import { GlassCard, GlassHeader, GlassButton, StatusPill, SuccessSparkle, PremiumBadge, SocialShareModal } from '../components/Shared';
import { HomeProfile } from '../types';

interface BudgetSavingsProps {
  onBack: () => void;
  activeHome: HomeProfile;
}

const BudgetSavings: React.FC<BudgetSavingsProps> = ({ onBack, activeHome }) => {
  const [step, setStep] = useState(0); 
  const [revealed, setRevealed] = useState(false);
  const [savingsCount, setSavingsCount] = useState(0);
  const [isSharing, setIsSharing] = useState(false);

  useEffect(() => {
    if (step === 2) {
      setTimeout(() => setRevealed(true), 800);
      const interval = setInterval(() => {
        setSavingsCount(prev => {
          if (prev < 245) return prev + 5;
          clearInterval(interval);
          return 245;
        });
      }, 15);
      return () => clearInterval(interval);
    } else {
      setRevealed(false);
      setSavingsCount(0);
    }
  }, [step]);

  if (step === 0) {
    return (
      <div className="absolute inset-0 z-[110] bg-app flex flex-col items-center justify-center p-8 text-center overflow-hidden">
        <div className="absolute top-12 left-6 pt-4">
           <motion.button whileTap={{ scale: 0.9 }} onClick={onBack} className="p-2 bg-main/5 rounded-full text-dim"><ChevronLeft size={20} /></motion.button>
        </div>
        <motion.div animate={{ y: [0, -20, 0] }} transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }} className="absolute top-[20%] left-[15%] text-homebase/10 blur-[1px]"><DollarSign size={40} /></motion.div>
        <motion.div 
          initial={{ scale: 0 }} animate={{ scale: 1 }}
          className="w-24 h-24 bg-emerald-400/10 rounded-full border-2 border-emerald-400 flex items-center justify-center mb-8 shadow-xl relative"
        >
          <PiggyBank size={48} className="text-emerald-500" />
          <motion.div animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.6, 0.3] }} transition={{ duration: 3, repeat: Infinity }} className="absolute inset-0 bg-emerald-400/10 rounded-full" />
        </motion.div>
        <h1 className="text-4xl font-black text-main mb-4 italic tracking-tighter leading-none">Wealth &<br/>Maintenance</h1>
        <p className="text-dim mb-12 max-w-[280px] leading-relaxed text-sm font-medium">Optimize property cash flow. We'll identify the perfect monthly reserve to protect your investment.</p>
        <GlassButton onClick={() => setStep(1)}>Build Strategy</GlassButton>
      </div>
    );
  }

  if (step === 1) {
    return (
      <div className="absolute inset-0 z-[110] bg-app flex flex-col">
        <GlassHeader className="bg-transparent border-0 flex items-center justify-between pt-8">
           <motion.button whileTap={{ scale: 0.9 }} onClick={() => setStep(0)} className="p-2 bg-main/5 rounded-full text-dim"><ChevronLeft size={20} /></motion.button>
           <h3 className="text-xs font-black uppercase tracking-[0.2em] text-main">Strategy Lab</h3>
           <div className="w-10" />
        </GlassHeader>
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-10 no-scrollbar">
           <div className="space-y-1">
              <h3 className="text-3xl font-black text-main leading-tight tracking-tighter italic">Investment Level</h3>
              <p className="text-dim text-sm font-medium">Select your savings aggression profile.</p>
           </div>
           
           <div className="space-y-8">
              <div className="grid grid-cols-3 gap-3">
                {['Lean', 'Standard', 'Proactive'].map((l, i) => (
                  <motion.button 
                    key={l} whileTap={{ scale: 0.95 }}
                    className={`py-6 rounded-3xl border font-black text-[10px] uppercase tracking-widest transition-all ${l === 'Standard' ? 'border-homebase bg-homebase/10 text-homebase shadow-md' : 'border-main/5 bg-main/5 text-dim'}`}
                  >
                    {l}
                  </motion.button>
                ))}
              </div>
              <div className="bg-main/5 p-5 rounded-3xl border border-main/10 shadow-inner">
                <p className="text-dim text-[10px] text-center italic leading-relaxed">"Standard" ensures coverage for all critical systems and emergency buffers.</p>
              </div>
           </div>
        </div>
        <div className="p-6 pt-4 pb-12 bg-surface/80 backdrop-blur-2xl border-t border-main/5">
           <GlassButton onClick={() => setStep(2)}>Generate Target</GlassButton>
        </div>
      </div>
    );
  }

  return (
    <div className="absolute inset-0 z-[110] bg-app flex flex-col overflow-hidden">
        <SocialShareModal 
           isOpen={isSharing} onClose={() => setIsSharing(false)} 
           title="My Home Wealth" subtitle={activeHome.nickname}
           stats={[
             { label: 'Monthly Reserve', value: `$${savingsCount}` },
             { label: 'Yearly Savings', value: '$2,200' },
             { label: 'Strategy', value: 'Standard' }
           ]}
        />
        <GlassHeader className="bg-transparent border-0 flex items-center justify-between pt-8">
           <motion.button whileTap={{ scale: 0.9 }} onClick={() => setStep(0)} className="p-2 bg-main/5 rounded-full text-dim"><ChevronLeft size={20} /></motion.button>
           <h3 className="text-xs font-black uppercase tracking-[0.2em] text-main">Wealth Vault</h3>
           <motion.button whileTap={{ scale: 0.9 }} onClick={() => setIsSharing(true)} className="p-2 bg-homebase/10 rounded-full text-homebase border border-homebase/20"><Share2 size={20} /></motion.button>
        </GlassHeader>
        
        <div className="flex-1 overflow-y-auto px-6 py-4 no-scrollbar pb-32">
           <div className="flex flex-col items-center mb-12">
                <GlassCard className="w-full p-12 border-homebase/20 bg-gradient-to-br from-homebase/10 via-surface to-transparent relative overflow-hidden group shadow-2xl">
                   <SuccessSparkle active={revealed} />
                   <div className="relative z-10 text-center">
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: revealed ? 1 : 0 }} className="mb-4 flex justify-center"><PremiumBadge label="Target Reserve" /></motion.div>
                      <p className="text-dim text-[10px] font-black uppercase tracking-[0.4em] mb-4 leading-none">Optimal Monthly Allocation</p>
                      <div className="flex items-center justify-center gap-1">
                        <span className="text-dim text-3xl font-black italic mt-6">$</span>
                        <motion.h2 className="text-8xl font-black text-main italic tracking-tighter">{savingsCount}</motion.h2>
                      </div>
                      <motion.p initial={{ opacity: 0 }} animate={{ opacity: revealed ? 1 : 0 }} className="text-homebase text-lg font-black mt-4 italic">$180 - $310 Range</motion.p>
                   </div>
                </GlassCard>
           </div>

           <div className="space-y-6">
              <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] ml-2">Estimated Spend Profile</h3>
              <div className="space-y-4">
                 {[
                   { cat: 'HVAC Unit', cost: '$450', icon: <Wind size={14} />, color: 'bg-blue-400' },
                   { cat: 'Water Systems', cost: '$320', icon: <Droplets size={14} />, color: 'bg-homebase' },
                 ].map((item, i) => (
                   <GlassCard key={item.cat} index={i} className="p-6 flex items-center justify-between border-main/5 shadow-md">
                      <div className="flex items-center gap-5">
                         <div className={`p-3 rounded-[1.25rem] ${item.color} bg-opacity-10 text-opacity-100 border border-main/5 shadow-inner`}>{item.icon}</div>
                         <span className="text-main font-black text-base italic">{item.cat}</span>
                      </div>
                      <span className="text-main font-black text-xl italic">{item.cost}</span>
                   </GlassCard>
                 ))}
              </div>
           </div>

           <div className="mt-12 space-y-4">
              <div className="flex items-center gap-2 ml-2">
                 <TrendingDown className="text-homebase" size={16} />
                 <h3 className="text-main font-black text-xs uppercase tracking-[0.3em] italic">ROI Potential</h3>
              </div>
              <GlassCard className="p-8 border-homebase/30 bg-homebase/5 relative group overflow-hidden shadow-2xl">
                 <div className="absolute top-0 right-0 p-6 opacity-30"><SparkleIcon className="text-homebase" size={32} /></div>
                 <div className="flex flex-col mb-8">
                    <span className="text-homebase font-black text-sm italic mb-1">+$2,200 Annual ROI</span>
                    <h4 className="text-main font-black text-3xl tracking-tighter leading-none italic">Insulation<br/>Optimization</h4>
                 </div>
                 <p className="text-dim text-xs mb-10 leading-relaxed font-medium">Your current attic thermal rating is <span className="text-red-500 font-bold">R-22</span>. Upgrading to R-38 adds significant value.</p>
                 <div className="flex gap-4">
                    <button className="flex-1 py-4 rounded-[1.5rem] bg-main/5 border border-main/10 text-main font-black text-[10px] uppercase tracking-[0.2em] shadow-sm">Details</button>
                    <button className="flex-1 py-4 rounded-[1.5rem] bg-homebase text-white font-black text-[10px] uppercase tracking-[0.2em] shadow-lg shadow-homebase/20">Get Quote</button>
                 </div>
              </GlassCard>
           </div>
        </div>
        <div className="p-6 pt-4 pb-12 bg-surface/90 backdrop-blur-2xl border-t border-main/5">
           <motion.button whileTap={{ scale: 0.95 }} className="w-full py-5 rounded-[2rem] bg-main/5 border border-main/10 text-main font-black text-[10px] uppercase tracking-[0.3em] flex items-center justify-center gap-3 shadow-md">
              <SparkleIcon size={18} className="text-homebase" />
              Download Wealth Audit
           </motion.button>
        </div>
    </div>
  );
};

export default BudgetSavings;
