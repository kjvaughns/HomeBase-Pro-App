
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Home as HomeIcon, MapPin, Settings, Plus, Calendar, ArrowRight, MessageCircle } from 'lucide-react';
import { GlassCard, StatusPill, GlassButton } from '../components/Shared';
import { HomeProfile, Tab } from '../types';

type ManageView = 'Appointments' | 'Homes' | 'Favorites';

const MOCK_APPOINTMENTS = [
  {
    id: 'apt-1',
    providerName: 'Master Flow Plumbing',
    service: 'Leak Repair',
    date: 'OCT 24',
    time: '11:00 AM',
    status: 'UPCOMING',
    logo: 'https://picsum.photos/60/60?10'
  }
];

interface ManageProps {
  homes: HomeProfile[];
  onAddHome: (h: HomeProfile) => void;
  onUpdateHome: (h: HomeProfile) => void;
  onDeleteHome: (id: string) => void;
  onNavigate: (tab: Tab) => void;
  onOpenAI: () => void;
}

const Manage: React.FC<ManageProps> = ({ homes, onNavigate }) => {
  const [view, setView] = useState<ManageView>('Appointments');

  return (
    <div className="absolute inset-0 flex flex-col bg-app overflow-y-auto no-scrollbar pb-48 pt-16">
      <section className="px-7 sticky top-0 z-40 bg-app/80 backdrop-blur-2xl pb-6 border-b border-white/[0.03] shrink-0">
        <h2 className="text-3xl font-black text-main italic tracking-tighter mb-6">Manage</h2>
        <div className="p-1.5 rounded-[1.8rem] bg-white/[0.03] border border-white/[0.02] flex gap-1 shadow-inner relative overflow-hidden">
          {(['Appointments', 'Homes', 'Favorites'] as ManageView[]).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`flex-1 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest relative z-10 transition-all ${
                view === v ? 'text-main' : 'text-dim opacity-30 hover:opacity-100'
              }`}
            >
              {v}
              {view === v && (
                <motion.div layoutId="manage-tab" className="absolute inset-0 bg-surface rounded-2xl shadow-xl border border-white/5 -z-10" />
              )}
            </button>
          ))}
        </div>
      </section>

      <div className="px-7 pt-6 shrink-0">
        <AnimatePresence mode="wait">
          {view === 'Appointments' && (
            <motion.div key="apt" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
              {MOCK_APPOINTMENTS.map(apt => (
                <GlassCard key={apt.id} className="border-white/[0.02]">
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex gap-4">
                      <img src={apt.logo} className="w-14 h-14 rounded-2xl border border-white/[0.05]" alt="pro" />
                      <div>
                        <h4 className="text-main font-bold text-lg leading-none italic">{apt.providerName}</h4>
                        <p className="text-dim text-[11px] font-bold uppercase tracking-widest mt-1.5 opacity-30">{apt.service}</p>
                      </div>
                    </div>
                    <StatusPill status={apt.status} />
                  </div>
                  <div className="bg-white/[0.02] rounded-2xl p-4 flex items-center justify-between border border-white/[0.02] mb-6">
                    <div className="flex items-center gap-3">
                      <Calendar size={14} className="text-homebase opacity-40" />
                      <span className="text-main font-black text-xs italic">{apt.date} @ {apt.time}</span>
                    </div>
                    <ArrowRight size={14} className="text-dim opacity-20" />
                  </div>
                  <div className="flex gap-3">
                    <GlassButton variant="secondary" className="flex-1 border-white/[0.02] h-12"><MessageCircle size={14} className="mr-2" />Chat</GlassButton>
                    <GlassButton variant="secondary" className="flex-1 border-white/[0.02] h-12">Reschedule</GlassButton>
                  </div>
                </GlassCard>
              ))}
            </motion.div>
          )}

          {view === 'Homes' && (
            <motion.div key="homes" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
              <div className="flex items-center justify-between px-2">
                <h3 className="text-dim text-[10px] font-black uppercase tracking-[0.3em] opacity-30">PORTFOLIO</h3>
                <button className="text-homebase text-[10px] font-black uppercase tracking-widest italic flex items-center gap-1.5">
                  <Plus size={14} /> Add Home
                </button>
              </div>
              {homes.map(home => (
                <GlassCard key={home.id} className="p-0 border-white/[0.02] group">
                  <div className="relative h-40 overflow-hidden">
                    <img src={home.image} className="w-full h-full object-cover opacity-50 transition-transform duration-700 group-hover:scale-110" alt="home" />
                    <div className="absolute inset-0 bg-gradient-to-t from-surface to-transparent" />
                    <div className="absolute bottom-6 left-6 right-6">
                      <h4 className="text-main font-black text-2xl italic tracking-tighter leading-none mb-2">{home.nickname}</h4>
                      <p className="text-dim text-[10px] font-bold uppercase tracking-widest opacity-60 flex items-center gap-1.5"><MapPin size={10} className="text-homebase" /> {home.address}</p>
                    </div>
                  </div>
                  <div className="p-6 pt-4 flex items-center justify-between">
                    <div className="flex-1 pr-12">
                      <div className="w-full bg-white/[0.05] h-1 rounded-full overflow-hidden">
                        <div className="h-full bg-homebase" style={{ width: `${home.profileStrength}%` }} />
                      </div>
                      <p className="text-[8px] font-black text-dim uppercase tracking-widest mt-2 opacity-30">Health: {home.profileStrength}%</p>
                    </div>
                    <motion.button whileTap={{ scale: 0.9 }} className="p-3 bg-white/[0.02] rounded-xl text-dim opacity-30 border border-white/[0.05]">
                      <Settings size={18} />
                    </motion.button>
                  </div>
                </GlassCard>
              ))}
            </motion.div>
          )}

          {view === 'Favorites' && (
            <div key="fav" className="py-20 text-center text-dim opacity-20 italic font-medium">No favorites saved yet.</div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default Manage;
