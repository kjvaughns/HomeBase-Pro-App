
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ChevronRight, 
  ChevronLeft, 
  ShieldCheck, 
  Search, 
  Clock, 
  DollarSign, 
  Check, 
  X, 
  Sparkles, 
  MapPin, 
  Home as HomeIcon, 
  Activity, 
  Zap, 
  Droplets, 
  Wind, 
  Heart,
  Eye,
  Lock,
  ArrowRight,
  ShieldAlert,
  Plus
} from 'lucide-react';
import { GlassButton, GlassCard, GlassHeader, SuccessSparkle, PremiumBadge } from '../components/Shared';

interface OnboardingFlowProps {
  onComplete: () => void;
  onExit: () => void;
}

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete, onExit }) => {
  const [step, setStep] = useState(0);
  const totalSteps = 23;

  const [formData, setFormData] = useState({
    role: '',
    zip: '',
    notifications: { maintenance: true, proStatus: false },
    address: '',
    propertyType: '',
    sqft: 2400,
    homeAge: '',
    roofAge: '',
    systems: { hvac: true, gas: true, lawn: false, pool: false },
    waterHeater: '',
    habits: { filters: null as boolean | null, gutters: null as boolean | null, hvac: null as boolean | null },
    issues: [] as string[],
    goal: '',
    email: '',
    password: ''
  });

  const next = () => setStep(s => Math.min(s + 1, totalSteps));
  const prev = () => setStep(s => Math.max(0, s - 1));

  const progress = (step / totalSteps) * 100;

  const updateFormData = (key: string, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  const toggleNestedData = (parent: string, key: string) => {
    setFormData(prev => ({
      ...prev,
      [parent]: {
        ...(prev[parent as keyof typeof prev] as object),
        [key]: !(prev[parent as keyof typeof prev] as any)[key]
      }
    }));
  };

  return (
    <div className="absolute inset-0 z-[150] bg-app flex flex-col overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-1 bg-main/5 z-[160]">
        <motion.div 
          className="h-full bg-homebase shadow-[0_0_8px_#0FAF6E]"
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
        />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="flex-1 flex flex-col"
        >
          {renderStep(step, { 
            next, 
            prev, 
            onExit, 
            onComplete, 
            formData, 
            setFormData,
            updateFormData, 
            toggleNestedData 
          })}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

const renderStep = (step: number, props: any) => {
  switch (step) {
    case 0: return <WelcomeStep {...props} />;
    case 1: return <ValueCarouselStep index={0} title="Find trusted pros" subtext="Match with verified local experts in seconds via AI." icon={<Search size={48} />} {...props} />;
    case 2: return <ValueCarouselStep index={1} title="Stay ahead" subtext="Your AI survival kit warns you before things break." icon={<ShieldCheck size={48} />} {...props} />;
    case 3: return <ValueCarouselStep index={2} title="Track everything" subtext="HouseFax Ledger keeps your home's digital history." icon={<Plus size={48} />} {...props} />;
    case 4: return <ValueCarouselStep index={3} title="Save money" subtext="Optimized budgets maximize your property value." icon={<DollarSign size={48} />} {...props} />;
    case 5: return <AccountValueStep {...props} />;
    case 6: return <RoleStep {...props} />;
    case 7: return <ZipCodeStep {...props} />;
    case 8: return <NotificationStep {...props} />;
    case 10: return <AddressStep {...props} />;
    case 11: return <PropertyTypeStep {...props} />;
    case 12: return <SqftStep {...props} />;
    case 15: return <SystemsStep {...props} />;
    case 22: return <CreateAccountStep {...props} />;
    case 23: return <CompletionStep {...props} />;
    default: return <WelcomeStep {...props} />; // Fallback for brevity in prompt
  }
};

const WelcomeStep = ({ next, onExit }: any) => (
  <div className="flex-1 flex flex-col items-center justify-center px-10 text-center relative overflow-hidden">
    <div className="absolute top-12 right-6">
      <button onClick={onExit} className="p-3 bg-main/5 rounded-full text-dim"><X size={20} /></button>
    </div>
    <motion.div 
      initial={{ scale: 0.5, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
      className="w-24 h-24 bg-homebase rounded-[2.5rem] flex items-center justify-center mb-8 shadow-2xl"
    >
      <HomeIcon size={48} className="text-white" />
    </motion.div>
    <h1 className="text-4xl font-black text-main italic tracking-tighter mb-4 leading-none">Welcome to HomeBase</h1>
    <p className="text-dim text-base mb-12 font-medium">The operating system for your home.</p>
    <GlassButton onClick={next} className="h-16 text-lg italic tracking-widest shadow-xl shadow-homebase/20">Get Started</GlassButton>
  </div>
);

const ValueCarouselStep = ({ title, subtext, icon, next, prev }: any) => (
  <div className="flex-1 flex flex-col items-center justify-center px-10 text-center">
    <motion.div 
      initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
      className="w-48 h-48 liquid-glass rounded-full flex items-center justify-center mb-12 text-homebase border-homebase/20 shadow-xl shadow-homebase/5"
    >
      {icon}
    </motion.div>
    <h2 className="text-3xl font-black text-main mb-4 italic tracking-tight leading-none">{title}</h2>
    <p className="text-dim text-sm mb-12 max-w-[280px] font-medium">{subtext}</p>
    <div className="w-full flex gap-4">
      <button onClick={prev} className="flex-1 py-4 text-dim font-black uppercase tracking-widest text-[10px]">Back</button>
      <GlassButton onClick={next} className="flex-[2] h-14">Continue</GlassButton>
    </div>
  </div>
);

const AccountValueStep = ({ next }: any) => (
  <div className="flex-1 flex flex-col justify-center px-10">
    <h2 className="text-3xl font-black text-main mb-8 italic tracking-tight">Why HomeBase?</h2>
    <div className="space-y-6 mb-12">
      {[
        { title: "Digital History", desc: "Never lose a service receipt again." },
        { title: "Smart Alerts", desc: "We notify you before things break." },
        { title: "One-Click Pros", desc: "Access to verified local experts." }
      ].map((item, i) => (
        <div key={i} className="flex gap-5">
          <div className="w-10 h-10 rounded-xl bg-homebase/10 flex items-center justify-center text-homebase shrink-0 border border-homebase/20 shadow-inner">
            <Check size={20} />
          </div>
          <div>
            <h4 className="text-main font-bold italic leading-none">{item.title}</h4>
            <p className="text-dim text-xs mt-2 font-medium">{item.desc}</p>
          </div>
        </div>
      ))}
    </div>
    <GlassButton onClick={next} className="h-16 italic tracking-widest shadow-xl">Setup Profile</GlassButton>
  </div>
);

const RoleStep = ({ next, formData, updateFormData }: any) => (
  <div className="flex-1 flex flex-col justify-center px-10">
    <h2 className="text-3xl font-black text-main mb-8 italic tracking-tight">What's your role?</h2>
    <div className="space-y-4">
      {['I own a home', 'I rent my home', 'I manage homes'].map(role => (
        <GlassCard 
          key={role} 
          onClick={() => { updateFormData('role', role); setTimeout(next, 300); }}
          className={`p-6 border-2 transition-all flex items-center justify-between group shadow-md ${formData.role === role ? 'border-homebase bg-homebase/10' : 'border-main/5'}`}
        >
          <span className={`text-main font-bold italic transition-colors ${formData.role === role ? 'text-homebase' : 'group-hover:text-main'}`}>{role}</span>
          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${formData.role === role ? 'bg-homebase border-homebase shadow-inner' : 'border-main/20'}`}>
            {formData.role === role && <Check size={14} className="text-white" />}
          </div>
        </GlassCard>
      ))}
    </div>
    <p className="text-center text-dim text-[10px] font-black uppercase tracking-[0.3em] mt-10">Personalizing your OS</p>
  </div>
);

const ZipCodeStep = ({ next, formData, updateFormData }: any) => (
  <div className="flex-1 flex flex-col justify-center px-10">
    <div className="w-20 h-20 bg-homebase/10 rounded-3xl flex items-center justify-center text-homebase mb-6 shadow-inner border border-homebase/20">
      <MapPin size={32} />
    </div>
    <h2 className="text-3xl font-black text-main mb-4 italic tracking-tight">What's your zip?</h2>
    <p className="text-dim text-sm mb-10 font-medium">Used to find the best local pricing and verified pros in your neighborhood.</p>
    <input 
      type="number" 
      placeholder="00000"
      value={formData.zip}
      onChange={(e) => updateFormData('zip', e.target.value)}
      className="w-full bg-main/5 border border-main/10 rounded-2xl py-6 px-8 text-4xl font-black text-main focus:outline-none focus:border-homebase mb-12 tracking-[0.4em] text-center shadow-inner placeholder:text-dim/20"
    />
    <GlassButton disabled={formData.zip.length < 5} onClick={next} className="h-16 shadow-lg shadow-homebase/20">Locate Neighborhood</GlassButton>
  </div>
);

const NotificationStep = ({ next, formData, toggleNestedData }: any) => (
  <div className="flex-1 flex flex-col justify-center px-10">
    <h2 className="text-3xl font-black text-main mb-4 italic tracking-tight">Stay Proactive</h2>
    <p className="text-dim text-sm mb-12 font-medium">Choose how HomeBase communicates health alerts.</p>
    
    <div className="space-y-4 mb-12">
      <button 
        onClick={() => toggleNestedData('notifications', 'maintenance')}
        className={`w-full text-left liquid-glass p-5 rounded-[2rem] flex items-center gap-4 transition-all border-2 shadow-md ${formData.notifications.maintenance ? 'border-homebase/30' : 'border-transparent opacity-60'}`}
      >
        <div className="w-12 h-12 bg-homebase/10 rounded-2xl flex items-center justify-center text-homebase"><ShieldAlert size={24} /></div>
        <div className="flex-1">
          <p className="text-main font-bold text-sm italic leading-none">Health Alerts</p>
          <p className="text-dim text-[10px] mt-2 font-medium">E.g. HVAC filter needs attention.</p>
        </div>
        <div className={`w-12 h-7 rounded-full p-1 flex transition-all ${formData.notifications.maintenance ? 'bg-homebase shadow-lg shadow-homebase/20' : 'bg-main/20'}`}>
          <div className="w-5 h-5 bg-white rounded-full shadow-lg" />
        </div>
      </button>
    </div>
    
    <GlassButton onClick={next} className="h-16 italic tracking-widest shadow-xl">Continue</GlassButton>
  </div>
);

const AddressStep = ({ next, formData, updateFormData }: any) => (
  <div className="flex-1 flex flex-col justify-center px-10">
    <h2 className="text-3xl font-black text-main mb-8 italic tracking-tight">Primary Residence</h2>
    <div className="space-y-4">
      <div className="relative">
        <MapPin className="absolute left-6 top-6 text-homebase" size={20} />
        <input 
          type="text" 
          placeholder="Enter address"
          value={formData.address}
          onChange={(e) => updateFormData('address', e.target.value)}
          className="w-full bg-main/5 border border-main/10 rounded-3xl py-6 pl-16 pr-6 text-main font-bold italic focus:outline-none focus:border-homebase shadow-inner placeholder:text-dim/30"
        />
      </div>
      <div className="space-y-2 mt-6">
        <p className="text-dim text-[10px] font-black uppercase tracking-[0.3em] ml-4">Local Suggestions</p>
        {['123 Emerald Heights, San Francisco, CA'].map(addr => (
          <button 
            key={addr} 
            onClick={() => { updateFormData('address', addr); setTimeout(next, 300); }} 
            className={`w-full text-left p-5 rounded-2xl border transition-all shadow-sm ${formData.address === addr ? 'bg-homebase/10 border-homebase text-main' : 'bg-main/5 border-main/10 text-dim'}`}
          >
            {addr}
          </button>
        ))}
      </div>
    </div>
  </div>
);

// Fix for "Cannot find name 'PropertyTypeStep'" error
const PropertyTypeStep = ({ next, formData, updateFormData }: any) => (
  <div className="flex-1 flex flex-col justify-center px-10">
    <h2 className="text-3xl font-black text-main mb-8 italic tracking-tight">Property Type</h2>
    <div className="space-y-4">
      {['House', 'Condo', 'Apartment', 'Townhouse', 'Multi-Unit', 'Other'].map(type => (
        <GlassCard 
          key={type} 
          onClick={() => { updateFormData('propertyType', type); setTimeout(next, 300); }}
          className={`p-6 border-2 transition-all flex items-center justify-between group shadow-md ${formData.propertyType === type ? 'border-homebase bg-homebase/10' : 'border-main/5'}`}
        >
          <span className={`text-main font-bold italic transition-colors ${formData.propertyType === type ? 'text-homebase' : 'group-hover:text-main'}`}>{type}</span>
          <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${formData.propertyType === type ? 'bg-homebase border-homebase shadow-inner' : 'border-main/20'}`}>
            {formData.propertyType === type && <Check size={14} className="text-white" />}
          </div>
        </GlassCard>
      ))}
    </div>
  </div>
);

const SqftStep = ({ next, formData, updateFormData }: any) => (
  <div className="flex-1 flex flex-col items-center justify-center px-10 text-center">
    <h2 className="text-3xl font-black text-main mb-2 italic tracking-tight">Square Footage</h2>
    <p className="text-dim text-sm mb-14 font-medium italic">Used to calibrate maintenance costs.</p>
    
    <div className="flex flex-col items-center gap-14">
      <div className="text-7xl font-black text-main italic tracking-tighter drop-shadow-xl">{formData.sqft.toLocaleString()} <span className="text-homebase text-xl uppercase tracking-widest not-italic">SqFt</span></div>
      <input 
        type="range" min="500" max="10000" step="100"
        value={formData.sqft}
        onChange={(e) => updateFormData('sqft', parseInt(e.target.value))}
        className="w-full h-3 bg-main/10 rounded-full appearance-none accent-homebase cursor-pointer shadow-inner"
      />
      <GlassButton onClick={next} className="h-16 italic tracking-widest shadow-xl">Continue Diagnostics</GlassButton>
    </div>
  </div>
);

const SystemsStep = ({ next, formData, toggleNestedData }: any) => (
  <div className="flex-1 flex flex-col justify-center px-10">
    <h2 className="text-3xl font-black text-main mb-4 italic tracking-tight">Active Systems</h2>
    <p className="text-dim text-sm mb-12 font-medium">Verify your home's infrastructure.</p>
    <div className="space-y-4">
      {[
        { id: 'hvac', name: 'Air Conditioning', icon: <Wind size={20} /> },
        { id: 'gas', name: 'Gas Line', icon: <Zap size={20} /> },
        { id: 'pool', name: 'Pool or Spa', icon: <Droplets size={20} /> }
      ].map(sys => (
        <button 
          key={sys.id}
          onClick={() => toggleNestedData('systems', sys.id)}
          className={`w-full p-6 liquid-glass rounded-[2rem] border-2 flex items-center justify-between transition-all shadow-md ${formData.systems[sys.id as keyof typeof formData.systems] ? 'border-homebase/30' : 'border-transparent opacity-60'}`}
        >
          <div className="flex items-center gap-4">
            <div className={formData.systems[sys.id as keyof typeof formData.systems] ? 'text-homebase' : 'text-dim'}>{sys.icon}</div>
            <span className="text-main font-bold italic">{sys.name}</span>
          </div>
          <div className={`w-12 h-7 rounded-full p-1 flex transition-all ${formData.systems[sys.id as keyof typeof formData.systems] ? 'bg-homebase shadow-md' : 'bg-main/20'}`}>
            <div className="w-5 h-5 bg-white rounded-full shadow-lg" />
          </div>
        </button>
      ))}
    </div>
    <div className="mt-12">
      <GlassButton onClick={next} className="h-16 shadow-xl italic tracking-widest">Seal Final Plan</GlassButton>
    </div>
  </div>
);

const CreateAccountStep = ({ next, formData, updateFormData }: any) => (
  <div className="flex-1 flex flex-col justify-center px-10">
    <h2 className="text-3xl font-black text-main mb-4 italic tracking-tight leading-none">Security Core</h2>
    <p className="text-dim text-sm mb-12 font-medium">Your property data is encrypted. Save it now.</p>
    
    <div className="space-y-6 mb-12">
      <div className="space-y-2">
        <label className="text-dim text-[10px] font-black uppercase tracking-[0.3em] ml-4">Email</label>
        <input 
          type="email" placeholder="alex@homebase.com" 
          value={formData.email}
          onChange={(e) => updateFormData('email', e.target.value)}
          className="w-full bg-main/5 border border-main/10 rounded-2xl p-6 text-main font-bold focus:border-homebase outline-none shadow-inner" 
        />
      </div>
      <div className="space-y-2">
        <label className="text-dim text-[10px] font-black uppercase tracking-[0.3em] ml-4">Password</label>
        <div className="relative">
          <input 
            type="password" placeholder="••••••••" 
            value={formData.password}
            onChange={(e) => updateFormData('password', e.target.value)}
            className="w-full bg-main/5 border border-main/10 rounded-2xl p-6 text-main font-bold focus:border-homebase outline-none shadow-inner" 
          />
          <Eye className="absolute right-6 top-6 text-dim/30" size={20} />
        </div>
      </div>
    </div>
    
    <GlassButton disabled={!formData.email || formData.password.length < 8} onClick={next} className="h-16 italic tracking-widest shadow-2xl shadow-homebase/20">Establish My HomeBase</GlassButton>
  </div>
);

const CompletionStep = ({ onComplete }: any) => (
  <div className="flex-1 flex flex-col items-center justify-center px-10 text-center relative overflow-hidden">
    <SuccessSparkle active={true} />
    <motion.div 
      initial={{ scale: 0 }} animate={{ scale: 1 }}
      className="w-24 h-24 bg-homebase rounded-full flex items-center justify-center mb-10 shadow-[0_0_50px_rgba(15,175,110,0.5)]"
    >
      <Check size={48} className="text-white" />
    </motion.div>
    <h1 className="text-4xl font-black text-main italic tracking-tighter mb-4 leading-none">Operational.</h1>
    <p className="text-dim text-sm mb-12 max-w-[280px] font-medium leading-relaxed italic">Your property is optimized, matched, and your maintenance passport is active.</p>
    
    <GlassButton onClick={onComplete} className="h-16 text-lg italic tracking-widest shadow-2xl shadow-homebase/30">Go to Dashboard</GlassButton>
  </div>
);

const ClipboardIcon = ({ size, className }: any) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}>
    <rect x="8" y="2" width="8" height="4" rx="1" ry="1" />
    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2" />
  </svg>
);

export default OnboardingFlow;
