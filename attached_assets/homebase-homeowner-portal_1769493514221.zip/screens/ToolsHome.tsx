
import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, HeartPulse, FileText, PiggyBank, ArrowRight, Home as HomeIcon } from 'lucide-react';
import { GlassCard, HomeSelector, GlassHeader } from '../components/Shared';
import { Tab, HomeProfile } from '../types';

interface ToolsHomeProps {
  onNavigate: (tab: Tab) => void;
  activeHome: HomeProfile;
  homes: HomeProfile[];
  onSelectHome: (h: HomeProfile) => void;
}

const TOOLS = [
  { 
    id: Tab.SurvivalKit, 
    title: 'Survival Kit', 
    desc: 'Personalized maintenance plan.', 
    icon: <ShieldCheck size={24} className="text-homebase" />,
    lastRun: '2 days ago'
  },
  { 
    id: Tab.HomeHealth, 
    title: 'Health Score', 
    desc: 'Assess your home systems.', 
    icon: <HeartPulse size={24} className="text-red-400" />,
    lastRun: 'Oct 20'
  },
  { 
    id: Tab.HouseFax, 
    title: 'HouseFax Ledger', 
    desc: 'Your home operating system.', 
    icon: <FileText size={24} className="text-blue-400" />,
    lastRun: 'Active'
  },
  { 
    id: Tab.BudgetSavings, 
    title: 'Budget & Savings', 
    desc: 'Optimize maintenance spend.', 
    icon: <PiggyBank size={24} className="text-emerald-400" />,
    lastRun: 'Not run'
  }
];

const ToolsHome: React.FC<ToolsHomeProps> = ({ onNavigate, activeHome, homes, onSelectHome }) => {
  return (
    <div className="absolute inset-0 flex flex-col bg-app">
      <GlassHeader className="flex items-center justify-between border-b-0 bg-transparent pt-12 overflow-visible relative z-50 shrink-0">
        <div className="flex items-center gap-2">
          <div className="p-2 bg-homebase/10 rounded-xl border border-homebase/20">
            <HomeIcon size={18} className="text-homebase" />
          </div>
          <h2 className="text-xl font-black text-main italic tracking-tight">Home Tools</h2>
        </div>
        <HomeSelector homes={homes} activeHome={activeHome} onSelect={onSelectHome} />
      </GlassHeader>

      <div className="flex-1 overflow-y-auto px-6 pt-4 pb-32 no-scrollbar">
        <div className="mb-8 shrink-0">
          <p className="text-main font-bold text-2xl mb-1 tracking-tight italic">Empower your home.</p>
          <p className="text-dim text-sm">Professional grade tools for homeowners.</p>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-8 shrink-0">
          {TOOLS.map((tool, i) => (
            <motion.div
              key={tool.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.1 }}
            >
              <GlassCard 
                onClick={() => onNavigate(tool.id)}
                className="h-44 flex flex-col justify-between border-main/5 hover:border-homebase/30 transition-colors shadow-lg"
              >
                <div className="flex justify-between items-start">
                  <div className="p-3 bg-main/5 rounded-2xl border border-main/5">
                    {tool.icon}
                  </div>
                  <span className="px-2 py-0.5 rounded-lg bg-homebase text-white text-[9px] font-bold uppercase tracking-widest">Global</span>
                </div>
                <div>
                  <h3 className="text-main font-bold text-sm mb-1">{tool.title}</h3>
                  <p className="text-dim text-[10px] leading-tight mb-2 line-clamp-2">{tool.desc}</p>
                  <div className="flex items-center justify-between border-t border-main/5 pt-2">
                    <span className="text-dim/60 text-[9px] uppercase font-bold tracking-tighter">{tool.lastRun}</span>
                    <ArrowRight size={14} className="text-homebase" />
                  </div>
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>

        <div className="space-y-4 shrink-0">
          <h3 className="text-dim text-[10px] font-black uppercase tracking-widest ml-2">Recent Activities</h3>
          <GlassCard className="p-4 border-main/5">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-homebase/10 rounded-2xl flex items-center justify-center border border-homebase/20">
                <ShieldCheck size={20} className="text-homebase" />
              </div>
              <div className="flex-1">
                <p className="text-main font-bold text-sm">Survival Kit Generated</p>
                <p className="text-dim text-xs">Main House • Oct 22, 2023</p>
              </div>
              <button className="text-homebase text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-homebase/5 transition-colors">View</button>
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};

export default ToolsHome;
