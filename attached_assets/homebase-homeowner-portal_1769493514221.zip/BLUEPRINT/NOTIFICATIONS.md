# Notification Strategy

## Types
1. **Maintenance Alerts:** "Time to change the MERV 13 filter at Main House."
2. **Booking Updates:** "Master Flow Plumbing is on the way!"
3. **Health Warnings:** "Your Home Health Score dropped to 72. Action required."

## Payload Structure
```json
{
  "to": "user_push_token",
  "title": "HomeBase AI Alert",
  "body": "Critical: HVAC Filter reached end-of-life.",
  "data": { "home_id": "...", "tool": "SurvivalKit" }
}
```

## Quiet Hours
- No non-critical maintenance alerts between 9 PM and 8 AM.
