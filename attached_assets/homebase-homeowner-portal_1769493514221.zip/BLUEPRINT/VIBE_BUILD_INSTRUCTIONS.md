
# Vibe Build Instructions

## Profile Switcher Implementation
1. **Account Card:** Ensure the "Account" section in the More tab uses the shrunken Glass card style.
2. **Sheet Transitions:** Use `framer-motion` for the bottom-up entry. Ensure the background dimming is high-contrast.
3. **Switch Logic:** When a switch is confirmed, trigger a global state update. Show a success toast or sparkle for positive reinforcement.
4. **Provider Intro:** The "Become a Service Provider" screen must use the 3-bullet benefit layout with a heavy premium shadow on the primary CTA.

## Dashboard Layout
1. **Home Hero:** The "Ask HomeBase AI" bar must be horizontally shrunken to leave room for content below.
2. **Priority Order:** Top (Header) -> Hero (AI Bar) -> Middle (Work Orders) -> Bottom (Assessment Row).
