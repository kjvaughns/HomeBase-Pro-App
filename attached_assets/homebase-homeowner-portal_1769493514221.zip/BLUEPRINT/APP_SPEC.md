
# Application Specification: HomeBase

## 1. Product Summary
HomeBase is a premium, AI-driven home operating system. It features dual-modality support for both Homeowners and Service Providers, unified by a shared architectural core and a high-fidelity Liquid Glass UI.

## 2. Core Flows
### Profile Switching
- **Intentionality:** Switching profiles requires user confirmation via a lightweight sheet.
- **Provider Onboarding:** Homeowners can "Unlock" the provider side via a specific intro flow.
- **State Management:** The application maintains separate contexts for Homeowner data (Properties) and Provider data (Business) while sharing a single Auth session.

## 3. Persona Jobs to be Done (JTBD)
- **The Homeowner (Alex):** "Help me stay ahead of maintenance and find verified pros."
- **The Multi-Tasker (Sam):** "I manage my own home and also run a small plumbing business. I need to switch between roles instantly without logging out."

## 4. Technical Requirements
- **System:** iOS-first Liquid Glass UI.
- **Color:** HomeBase Green #0FAF6E primary accent.
- **Animations:** High-performance spring physics for all sheets and transitions.
- **Privacy:** Data isolation between homeowner assets and provider job logs.
