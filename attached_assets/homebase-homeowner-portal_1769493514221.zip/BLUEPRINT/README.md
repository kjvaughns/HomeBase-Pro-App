
# HomeBase Blueprint

This directory contains the single source of truth for the HomeBase application architecture, data model, and API contract. 

## The Contract
This Blueprint is the implementation-ready specification. Any developer or vibe coding platform must adhere strictly to the patterns defined here. Do not invent new folder structures, naming conventions, or state management patterns.

## Multi-Profile Architecture
HomeBase supports two primary modes:
1. **Homeowner Portal:** Manage properties, assets, and book services.
2. **Provider Portal:** Manage business services, jobs, and payments.

Transitions between these profiles must feel seamless, utilizing the **Liquid Glass** design system for high-fidelity switching.

## Drift Control
If the implementation requires a change to the core logic:
1. **Update the Blueprint first.**
2. Review the changes against the product goals.
3. **Implement the code** to match the updated Blueprint.
