# Edge Functions (Supabase)

## 1. `home-ai-assistant`
- **Purpose:** Process natural language prompts from the "Ask HomeBase AI" UI.
- **Trigger:** HTTP POST.
- **Logic:** Calls Gemini API with home context (assets, zip code) to suggest maintenance or specific pros.

## 2. `calculate-home-health`
- **Purpose:** Nightly or on-demand recalculation of property health scores.
- **Logic:** Weights age of roof, HVAC logs, and recent inspections.
- **Output:** Updates `homes.health_score`.

## 3. `social-card-generator`
- **Purpose:** Renders a high-fidelity 9:16 card using Satori or similar.
- **Auth:** Required.
- **Security:** Signed URL for temporary sharing.

## 4. `booking-notifications`
- **Trigger:** DB Webhook on `appointments` insert/update.
- **Purpose:** Send push notifications via Expo or Email via Resend.
