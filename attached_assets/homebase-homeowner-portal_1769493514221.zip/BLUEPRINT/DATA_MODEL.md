
# Data Model: HomeBase

## Profiles
| Column | Type | Description |
| :--- | :--- | :--- |
| `id` | uuid (PK) | References auth.users |
| `full_name` | text | |
| `email` | text | |
| `active_role` | enum | homeowner, provider |
| `is_provider_setup` | bool | Whether provider onboarding is complete |

## Homes (Homeowner Context)
| Column | Type | Description |
| :--- | :--- | :--- |
| `id` | uuid (PK) | |
| `owner_id` | uuid (FK) | References Profiles |
| `nickname` | text | |
| `health_score` | int | |

## Business (Provider Context)
| Column | Type | Description |
| :--- | :--- | :--- |
| `id` | uuid (PK) | |
| `user_id` | uuid (FK) | References Profiles |
| `business_name` | text | |
| `verified_at` | timestamp | |
| `service_tags` | text[] | |

## Data Access Strategy
- **Isolation:** Homeowner screens query `homes` filtered by `active_role == 'homeowner'`.
- **Switching:** Updating `active_role` triggers a global UI refresh to the respective dashboard.
