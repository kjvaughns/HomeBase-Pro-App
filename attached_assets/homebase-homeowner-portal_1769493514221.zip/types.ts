
export enum Tab {
  // Homeowner Tabs
  Home = 'Home',
  Explore = 'Explore',
  Manage = 'Manage',
  // Provider Tabs
  ProviderHome = 'ProviderHome',
  Schedule = 'Schedule',
  Money = 'Money',
  // Shared / Tools
  More = 'More',
  ToolsHome = 'ToolsHome',
  SurvivalKit = 'SurvivalKit',
  HomeHealth = 'HomeHealth',
  HouseFax = 'HouseFax',
  BudgetSavings = 'BudgetSavings',
  Onboarding = 'Onboarding'
}

export enum ProfileType {
  Homeowner = 'Homeowner',
  Provider = 'Service Provider'
}

export interface HomeSystems {
  hvac: 'Central' | 'Mini Split' | 'Window' | 'None';
  heating: 'Gas' | 'Electric' | 'Other';
  waterHeater: 'Traditional Tank' | 'Tankless' | 'Unknown';
  pool: boolean;
  lawn: boolean;
  electricalPanel?: string;
  plumbingType?: string;
}

export interface HomeHabits {
  filters: boolean | null;
  gutters: boolean | null;
  hvac: boolean | null;
}

export interface BookingPreferences {
  gateCode?: string;
  pets?: string;
  parking?: string;
  preferredTimes: string[];
  shareNotes: boolean;
}

export interface HomeProfile {
  id: string;
  nickname: string;
  address: string;
  zip: string;
  type: 'House' | 'Condo' | 'Apartment' | 'Townhouse' | 'Multi-Unit' | 'Other';
  sqft: number;
  beds: number;
  baths: number;
  yearBuilt: string;
  roofAge: string;
  systems: HomeSystems;
  habits: HomeHabits;
  booking: BookingPreferences;
  issues: string[];
  goal: string;
  image: string;
  profileStrength: number;
}

export interface Service {
  id: string;
  name: string;
  duration: string;
  price: string;
  description?: string;
}

export interface Provider {
  id: string;
  name: string;
  rating: number;
  reviewCount: number;
  services?: string[];
  serviceDetails?: Service[];
  distance: string;
  logo: string;
  heroImage?: string;
  isFavorite?: boolean;
  about?: string;
  portfolio?: string[];
  tags?: string[];
}

export interface Job {
  id: string;
  clientName: string;
  serviceType: string;
  time: string;
  status: 'In Progress' | 'Upcoming' | 'Completed' | 'Cancelled';
  price: string;
}

// Fixed: Added missing Asset interface for HouseFaxLedger
export interface Asset {
  id: string;
  name: string;
  location: string;
  installDate: string;
  warrantyStatus: string;
  category: string;
}

// Fixed: Added missing Consumable interface for HouseFaxLedger
export interface Consumable {
  id: string;
  name: string;
  nextDue: string;
  recurrence: string;
}
